# BizIntel 360 — Deployment Guide

## 1. Hostinger VPS Deployment (Linux, Port 8003)

### Prerequisites
- Hostinger VPS with Ubuntu 22.04+ (or any Debian-based Linux)
- SSH access to your VPS
- Domain pointed to your VPS IP (optional but recommended)

---

### Step 1: SSH into your VPS

```bash
ssh root@YOUR_VPS_IP
```

### Step 2: Install System Dependencies

```bash
# Update system
apt update && apt upgrade -y

# Install Python 3.11+, pip, venv, git, and build tools
apt install -y python3 python3-pip python3-venv git build-essential \
  libffi-dev libssl-dev pkg-config cmake nginx certbot python3-certbot-nginx

# Verify Python version (need 3.10+)
python3 --version
```

### Step 3: Clone the Repository

```bash
cd /opt
git clone https://github.com/YOUR_USERNAME/BIZINTEL-360.git
cd BIZINTEL-360
```

### Step 4: Set Up Backend

```bash
cd /opt/BIZINTEL-360/backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 5: Create .env File

```bash
cp /opt/BIZINTEL-360/.env.example /opt/BIZINTEL-360/.env
nano /opt/BIZINTEL-360/.env
```

Fill in all values:
```env
# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key

# WooCommerce
WOOCOMMERCE_URL=https://your-store.com
WOOCOMMERCE_CONSUMER_KEY=ck_xxx
WOOCOMMERCE_CONSUMER_SECRET=cs_xxx

# WhatsApp (optional)
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_VERIFY_TOKEN=bizintel360_verify

# App
APP_NAME=BizIntel 360
APP_ENV=production
APP_DEBUG=false
APP_PORT=8003
FRONTEND_URL=https://your-frontend-domain.com
```

### Step 6: Test the Server Manually

```bash
cd /opt/BIZINTEL-360/backend
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8003
```

Visit `http://YOUR_VPS_IP:8003/docs` — you should see the Swagger docs.

Press `Ctrl+C` to stop.

### Step 7: Create Systemd Service (Auto-start on Boot)

```bash
cat > /etc/systemd/system/bizintel360.service << 'EOF'
[Unit]
Description=BizIntel 360 Backend API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/BIZINTEL-360/backend
Environment=PATH=/opt/BIZINTEL-360/backend/venv/bin:/usr/bin
ExecStart=/opt/BIZINTEL-360/backend/venv/bin/gunicorn app.main:app \
  --workers 2 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8003 \
  --timeout 120 \
  --access-logfile /opt/BIZINTEL-360/backend/logs/access.log \
  --error-logfile /opt/BIZINTEL-360/backend/logs/error.log
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
```

```bash
# Create logs directory
mkdir -p /opt/BIZINTEL-360/backend/logs

# Enable and start
systemctl daemon-reload
systemctl enable bizintel360
systemctl start bizintel360

# Check status
systemctl status bizintel360

# View logs
journalctl -u bizintel360 -f
```

### Step 8: Configure Nginx Reverse Proxy (Optional but Recommended)

```bash
cat > /etc/nginx/sites-available/bizintel360 << 'EOF'
server {
    listen 80;
    server_name api.yourdomain.com;  # Replace with your domain

    location / {
        proxy_pass http://127.0.0.1:8003;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }
}
EOF

ln -s /etc/nginx/sites-available/bizintel360 /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### Step 9: Enable HTTPS with Let's Encrypt (Free SSL)

```bash
certbot --nginx -d api.yourdomain.com
```

### Step 10: Open Firewall Port

```bash
ufw allow 8003/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### Step 11: Run Initial Data Sync & ML Training

```bash
cd /opt/BIZINTEL-360/backend
source venv/bin/activate

# Sync WooCommerce data
python scripts/sync_woocommerce.py

# Train ML models
python scripts/run_ml_models.py
```

### Step 12: Verify Everything Works

```bash
# Health check
curl http://localhost:8003/health

# API docs
curl http://localhost:8003/docs
```

---

### Updating the Deployment

```bash
cd /opt/BIZINTEL-360
git pull origin main
cd backend
source venv/bin/activate
pip install -r requirements.txt
systemctl restart bizintel360
```

### Useful Commands

```bash
# View live logs
journalctl -u bizintel360 -f

# Restart service
systemctl restart bizintel360

# Stop service
systemctl stop bizintel360

# Run ML models manually
cd /opt/BIZINTEL-360/backend && source venv/bin/activate && python scripts/run_ml_models.py

# Run WooCommerce sync manually
cd /opt/BIZINTEL-360/backend && source venv/bin/activate && python scripts/sync_woocommerce.py
```

---

## 2. WhatsApp Integration (FREE — Educational/Testing)

### Option A: Meta WhatsApp Cloud API (Free Tier — Recommended)

Meta provides a **completely free** test environment for WhatsApp Business API. You get:
- **1,000 free conversations/month** (more than enough for educational use)
- **5 test phone numbers** you can message
- No credit card required for testing

#### Step-by-Step Setup:

**1. Create Meta Developer Account (Free)**
1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Click "Get Started" → Create account (use your Facebook login)
3. Accept developer terms

**2. Create a New App**
1. Click "Create App"
2. Select app type: **Business**
3. App name: `BizIntel 360`
4. Click "Create App"

**3. Add WhatsApp Product**
1. In your app dashboard, click "Add Product"
2. Find **WhatsApp** → Click "Set Up"
3. You'll get a **test phone number** and **temporary access token** automatically

**4. Get Your Credentials**
From WhatsApp → API Setup page:
- **Phone Number ID**: Shown under "From" phone number (e.g., `123456789012345`)
- **Temporary Access Token**: Click "Generate" (valid 24h, but free!)
- For a permanent token: Go to Business Settings → System Users → Generate Token

**5. Add Test Phone Numbers**
1. In WhatsApp → API Setup → "To" section
2. Click "Manage phone number list"
3. Add your personal WhatsApp number
4. You'll receive a verification code on WhatsApp — enter it
5. You can add up to **5 test numbers** for free

**6. Update .env on Your VPS**

```env
WHATSAPP_PHONE_NUMBER_ID=123456789012345
WHATSAPP_ACCESS_TOKEN=EAAxxxxxxx...
WHATSAPP_VERIFY_TOKEN=bizintel360_verify
```

**7. Set Up Webhook**

Your backend must be publicly accessible. On your VPS:

```
Webhook URL: https://api.yourdomain.com/api/whatsapp/webhook
             OR http://YOUR_VPS_IP:8003/api/whatsapp/webhook
Verify Token: bizintel360_verify
```

In Meta Developer Dashboard:
1. Go to WhatsApp → Configuration
2. Click "Edit" under Webhook
3. Enter your Callback URL and Verify Token
4. Click "Verify and Save"
5. Subscribe to: **messages**

**8. Test It!**
Send a WhatsApp message from your test phone to the Meta test number:
- `revenue summary`
- `stock alerts`
- `top products`
- `churn analysis`
- `forecast`

**9. Free Tier Limits**
| Feature | Free Limit |
|---------|-----------|
| Service conversations | 1,000/month |
| Test phone numbers | 5 |
| API calls | Unlimited |
| Duration | Indefinite (no expiry) |

#### Generating a Permanent Access Token (Free)

The temporary token expires in 24h. For a permanent one:

1. Go to [business.facebook.com](https://business.facebook.com) → Business Settings
2. Navigate to: Users → System Users
3. Click "Add" → Name: `BizIntel Bot` → Role: Admin
4. Click "Generate New Token"
5. Select your app (`BizIntel 360`)
6. Grant permission: `whatsapp_business_messaging`, `whatsapp_business_management`
7. Click "Generate Token" — this token **never expires**
8. Copy and paste into your `.env` as `WHATSAPP_ACCESS_TOKEN`

---

### Option B: WhatsApp Web.js (Completely Free, No Meta Account)

If you don't want to use Meta's API at all, you can use the `whatsapp-web.js` library which connects through WhatsApp Web. This is 100% free but:
- Requires a Node.js sidecar process
- Uses your personal WhatsApp number
- Not officially supported by Meta (educational only)
- May break if WhatsApp updates their web client

This option is **not recommended** for production but works for demos.

---

### Supported WhatsApp Commands

| Command | What it does |
|---------|-------------|
| `revenue summary` | Total revenue, orders, avg order value |
| `stock alerts` | Low stock and out-of-stock products |
| `churn analysis` | Top 5 at-risk customers with probability |
| `top products` | Best selling products by revenue |
| `forecast` | Demand predictions for next 30 days |
| `help` | Shows all available commands |

---

## 3. Architecture Overview

```
┌──────────────┐     ┌──────────────────┐     ┌─────────────┐
│   Flutter     │────▶│  FastAPI Backend  │────▶│  Supabase   │
│   Frontend    │     │  (Port 8003)     │     │  Database   │
└──────────────┘     │                  │     │  + Storage  │
                     │  ┌────────────┐  │     └─────────────┘
┌──────────────┐     │  │ ML Models  │  │
│  WhatsApp    │────▶│  │ Prophet    │  │
│  (Webhook)   │     │  │ LightGBM   │  │
└──────────────┘     │  └────────────┘  │
                     │                  │
                     │  ┌────────────┐  │
                     │  │ Scheduler  │  │
                     │  │ WooSync 6h │  │
                     │  │ ML Daily   │  │
                     │  └────────────┘  │
                     └──────────────────┘
```

## 4. Troubleshooting

| Issue | Solution |
|-------|---------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` in venv |
| Port 8003 not accessible | Run `ufw allow 8003/tcp` |
| Service won't start | Check `journalctl -u bizintel360 -f` for errors |
| ML models fail | Ensure numpy/pandas installed; check `python scripts/run_ml_models.py` output |
| WhatsApp webhook fails | Ensure URL is publicly accessible, verify token matches |
| Supabase connection error | Check SUPABASE_URL and SUPABASE_SERVICE_KEY in .env |
| Prophet install fails | `pip install pystan==2.19.1.1` first, then `pip install prophet` |
