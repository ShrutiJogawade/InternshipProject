# BizIntel 360 - Implementation Plan

## Project Architecture

### Backend (FastAPI + Python)
```
backend/
├── Dockerfile
├── requirements.txt
└── app/
    ├── main.py              # FastAPI app with CORS, logging, routers
    ├── config.py             # Pydantic-settings env config
    ├── database.py           # Supabase client (public + admin)
    ├── middleware/
    │   └── auth.py           # JWT auth + role-based access
    ├── models/
    │   └── schemas.py        # Pydantic request/response models
    ├── routers/
    │   ├── auth.py           # Register, login, logout, profile
    │   ├── forecast.py       # Sales forecasting (SKU/category)
    │   ├── churn.py          # Customer churn prediction
    │   ├── inventory.py      # Stock alerts, updates, health
    │   ├── dashboard.py      # KPIs, charts, overview
    │   ├── chat.py           # AI chatbot with intent detection
    │   └── integrations.py   # Shopify/WooCommerce sync
    ├── ml/
    │   ├── forecasting.py    # Prophet + XGBoost hybrid model
    │   └── churn_model.py    # LightGBM + SHAP explainability
    └── services/             # Business logic (extensible)
```

### Frontend (Flutter - Web, Android, iOS)
```
frontend/
├── pubspec.yaml
├── analysis_options.yaml
├── assets/
│   ├── images/
│   └── icons/
└── lib/
    ├── main.dart                    # App entry + Supabase init
    ├── core/
    │   ├── theme/
    │   │   └── app_theme.dart       # Dark theme, colors, gradients
    │   ├── router/
    │   │   └── app_router.dart      # GoRouter with auth guards
    │   ├── services/
    │   │   └── api_service.dart     # REST + Supabase client
    │   └── providers/
    │       ├── auth_provider.dart
    │       ├── dashboard_provider.dart
    │       ├── forecast_provider.dart
    │       ├── churn_provider.dart
    │       ├── inventory_provider.dart
    │       └── chat_provider.dart
    ├── screens/
    │   ├── auth/
    │   │   ├── login_screen.dart
    │   │   └── register_screen.dart
    │   ├── shell/
    │   │   └── app_shell.dart       # Sidebar + bottom nav
    │   ├── dashboard/
    │   │   └── dashboard_screen.dart
    │   ├── forecast/
    │   │   └── forecast_screen.dart
    │   ├── churn/
    │   │   └── churn_screen.dart
    │   ├── inventory/
    │   │   └── inventory_screen.dart
    │   ├── reports/
    │   │   └── reports_screen.dart
    │   ├── chat/
    │   │   └── chat_screen.dart
    │   └── settings/
    │       └── settings_screen.dart
    └── widgets/
        ├── glass_card.dart
        ├── kpi_card.dart
        └── alert_tile.dart
```

### Database (Supabase PostgreSQL)
```
database/
├── schema.sql    # Full schema with RLS policies
└── seed.sql      # Demo data for testing
```

### Infrastructure
```
docker-compose.yml  # Backend + Redis + Celery
.env                # Environment variables
.gitignore
```

## Key Features

| Module          | Status | Description                                    |
|-----------------|--------|------------------------------------------------|
| Auth            | ✅     | Supabase Auth + JWT + RBAC                     |
| Dashboard       | ✅     | KPIs, charts, alerts, top products             |
| Forecasting     | ✅     | Prophet + XGBoost hybrid model                 |
| Churn           | ✅     | LightGBM + SHAP explanations                   |
| Inventory       | ✅     | Stock levels, alerts, health monitoring         |
| AI Chatbot      | ✅     | NL queries, intent detection, markdown output   |
| Integrations    | ✅     | Shopify + WooCommerce connect & sync            |
| Reports         | ✅     | Regional, category, downloadable reports        |
| Settings        | ✅     | Profile, org, notifications, integrations       |

## Tech Stack

- **Backend**: FastAPI, Python 3.11, Pydantic v2
- **Frontend**: Flutter 3.x (Web + Android + iOS)
- **Database**: Supabase (PostgreSQL + Auth + RLS)
- **ML**: Prophet, XGBoost, LightGBM, SHAP
- **State**: Provider pattern
- **Charts**: fl_chart, percent_indicator
- **Routing**: GoRouter with auth guards
- **Styling**: Custom dark theme with glassmorphism

## Getting Started

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
flutter pub get
flutter run -d chrome    # Web
flutter run -d android   # Android
flutter run -d ios       # iOS
```

### Database
1. Create a Supabase project
2. Run `database/schema.sql` in the SQL editor
3. Run `database/seed.sql` for demo data
4. Update `.env` with your credentials
