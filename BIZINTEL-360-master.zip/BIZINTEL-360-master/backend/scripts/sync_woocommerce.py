import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import requests
from datetime import datetime, timezone
from app.database import get_supabase_admin
from app.config import get_settings

settings = get_settings()

def sync_woocommerce():
    """Direct WooCommerce sync - no auth required"""
    supabase = get_supabase_admin()
    
    store_url = settings.WOOCOMMERCE_URL
    consumer_key = settings.WOOCOMMERCE_CONSUMER_KEY
    consumer_secret = settings.WOOCOMMERCE_CONSUMER_SECRET
    
    print(f"\n{'='*60}")
    print(f"  BizIntel 360 - WooCommerce Sync via Requests")
    print(f"  Store: {store_url}")
    print(f"{'='*60}\n")
    
    if not store_url or not consumer_key:
        print("❌ WooCommerce credentials not configured in .env")
        return
    
    auth = (consumer_key, consumer_secret)
    
    # ---- Step 1: Find or create org from WooCommerce store ----
    print("📦 Step 1: Setting up organization...")
    
    # Derive a slug from the store URL
    import re
    domain = store_url.replace("https://", "").replace("http://", "").split("/")[0]
    org_slug = re.sub(r'[^a-z0-9]+', '-', domain.lower()).strip('-')
    org_name = domain
    
    # First check if an org with this platform_store_url already exists
    org_result = supabase.table("organizations").select("*").eq("platform_store_url", store_url).execute()
    
    if not org_result.data:
        # Also check by slug
        org_result = supabase.table("organizations").select("*").eq("slug", org_slug).execute()
    
    if not org_result.data:
        # Check if any org exists at all (e.g. seed data org)
        org_result = supabase.table("organizations").select("*").limit(1).execute()
    
    if not org_result.data:
        org_insert = supabase.table("organizations").insert({
            "name": org_name,
            "slug": org_slug,
            "platform": "woocommerce",
            "platform_store_url": store_url,
            "platform_api_key": consumer_key,
            "platform_api_secret": consumer_secret,
            "settings": {"source": domain, "currency": "INR", "country": "IN"}
        }).execute()
        org_id = org_insert.data[0]["id"]
        print(f"   ✅ Created org: {org_id} ({org_name})")
    else:
        org_id = org_result.data[0]["id"]
        supabase.table("organizations").update({
            "platform": "woocommerce",
            "platform_store_url": store_url,
            "platform_api_key": consumer_key,
            "platform_api_secret": consumer_secret
        }).eq("id", org_id).execute()
        print(f"   ✅ Using existing org: {org_id} ({org_result.data[0].get('name', '')})")
    
    # Create sync log
    sync_log = supabase.table("sync_logs").insert({
        "org_id": org_id,
        "platform": "woocommerce",
        "sync_type": "full",
        "status": "running"
    }).execute()
    sync_id = sync_log.data[0]["id"]
    
    records_synced = 0
    client = requests.Session()
    client.auth = auth
    
    # ---- Step 2: Sync Categories from WooCommerce ----
    print("\n📂 Step 2: Syncing Categories...")
    category_map = {}  # WooCommerce category ID -> DB UUID
    try:
        page = 1
        total_categories = 0
        while True:
            resp = client.get(
                f"{store_url}/wp-json/wc/v3/products/categories",
                params={"per_page": 100, "page": page}
            )
            if resp.status_code != 200:
                print(f"   ❌ Categories API error: {resp.status_code}")
                break
            
            categories = resp.json()
            if not categories:
                break
            
            for cat in categories:
                try:
                    cat_name = cat.get("name", "Uncategorized")
                    cat_slug = cat.get("slug", cat_name.lower().replace(" ", "-"))
                    woo_cat_id = cat.get("id")
                    
                    result = supabase.table("categories").upsert({
                        "org_id": org_id,
                        "name": cat_name,
                        "slug": cat_slug,
                        "description": (cat.get("description") or "")[:500],
                    }, on_conflict="org_id,slug").execute()
                    
                    if result.data:
                        category_map[woo_cat_id] = result.data[0]["id"]
                        total_categories += 1
                except Exception as e:
                    print(f"   ⚠️ Category '{cat.get('name')}' error: {e}")
            
            if len(categories) < 100:
                break
            page += 1
        
        print(f"   ✅ Total categories synced: {total_categories}")
    except Exception as e:
        print(f"   ❌ Categories sync error: {e}")
    
    # Also build a slug->id lookup for fallback matching
    db_cats = supabase.table("categories").select("id, slug, name").eq("org_id", org_id).execute()
    cat_slug_map = {c["slug"]: c["id"] for c in (db_cats.data or [])}
    cat_name_map = {c["name"].lower(): c["id"] for c in (db_cats.data or [])}
    
    # ---- Step 3: Sync Products ----
    print("\n🛍️  Step 3: Syncing Products...")
    try:
        page = 1
        total_products = 0
        while True:
            resp = client.get(
                f"{store_url}/wp-json/wc/v3/products",
                params={"per_page": 100, "page": page}
            )
            if resp.status_code != 200:
                print(f"   ❌ Products API error: {resp.status_code}")
                break
                
            products = resp.json()
            if not products:
                break
                
            for product in products:
                try:
                    sku = product.get("sku") or str(product["id"])
                    price = float(product.get("price", 0) or 0)
                    regular_price = float(product.get("regular_price", 0) or 0)
                    
                    # Resolve category_id from WooCommerce categories
                    category_id = None
                    woo_cats = product.get("categories", [])
                    if woo_cats:
                        # Try to match by WooCommerce category ID first
                        for wc in woo_cats:
                            wc_id = wc.get("id")
                            if wc_id in category_map:
                                category_id = category_map[wc_id]
                                break
                        # Fallback: match by slug or name
                        if not category_id:
                            for wc in woo_cats:
                                slug = wc.get("slug", "")
                                name = wc.get("name", "").lower()
                                if slug in cat_slug_map:
                                    category_id = cat_slug_map[slug]
                                    break
                                if name in cat_name_map:
                                    category_id = cat_name_map[name]
                                    break
                    
                    supabase.table("products").upsert({
                        "org_id": org_id,
                        "sku_id": sku,
                        "name": product["name"],
                        "category_id": category_id,
                        "description": (product.get("short_description") or "")[:500],
                        "price": price if price > 0 else regular_price,
                        "image_url": (product.get("images", [{}])[0].get("src") if product.get("images") else None),
                        "platform_product_id": str(product["id"]),
                        "is_active": product.get("status") == "publish",
                        "tags": [t["name"] for t in product.get("tags", [])],
                        "metadata": {
                            "categories": [c["name"] for c in woo_cats],
                            "stock_quantity": product.get("stock_quantity"),
                            "weight": product.get("weight"),
                            "type": product.get("type"),
                        }
                    }, on_conflict="org_id,sku_id").execute()
                    total_products += 1
                    records_synced += 1
                except Exception as e:
                    print(f"   ⚠️ Product '{product.get('name')}' error: {e}")
            
            print(f"   📄 Page {page}: {len(products)} products")
            if len(products) < 100:
                break
            page += 1
        
        print(f"   ✅ Total products synced: {total_products}")
        
        # Create inventory from synced products
        products_data = supabase.table("products").select("id, sku_id, metadata").eq("org_id", org_id).execute()
        inv_count = 0
        for p in (products_data.data or []):
            stock_qty = 0
            if p.get("metadata") and p["metadata"].get("stock_quantity"):
                stock_qty = int(p["metadata"]["stock_quantity"])
            
            supabase.table("inventory").upsert({
                "org_id": org_id,
                "product_id": p["id"],
                "sku_id": p["sku_id"],
                "current_stock": stock_qty if stock_qty > 0 else 50,
                "reorder_threshold": 10,
                "safety_stock": 5,
                "max_stock": 500
            }, on_conflict="org_id,sku_id").execute()
            inv_count += 1
        print(f"   ✅ Inventory records: {inv_count}")
            
    except Exception as e:
        print(f"   ❌ Products sync error: {e}")

    # ---- Step 4: Sync Orders & Extract Customers ----
    print("\n🧾 Step 4: Syncing Orders & Extracting Customers...")
    customer_metrics = {}
    try:
        page = 1
        total_orders = 0
        while True:
            resp = client.get(
                f"{store_url}/wp-json/wc/v3/orders",
                params={"per_page": 100, "page": page}
            )
            if resp.status_code != 200:
                print(f"   ❌ Orders API error: {resp.status_code}")
                break
                
            orders = resp.json()
            if not orders:
                break
                
            status_map = {
                "completed": "completed",
                "processing": "processing",
                "pending": "pending",
                "cancelled": "cancelled",
                "refunded": "returned",
                "on-hold": "on-hold",
                "failed": "cancelled",
            }
                
            for order in orders:
                try:
                    woo_status = order.get("status", "completed")
                    mapped_status = status_map.get(woo_status, "completed")
                    order_total = float(order.get("total", 0))
                    
                    # --- EXTRACT CUSTOMER ---
                    billing = order.get("billing", {})
                    email = billing.get("email") or f"guest_{order['id']}@example.com"
                    phone = billing.get("phone", "")
                    first_name = billing.get("first_name", "")
                    last_name = billing.get("last_name", "")
                    name = f"{first_name} {last_name}".strip() or "Guest Customer"
                    
                    woo_customer_id = str(order.get("customer_id", 0))
                    if woo_customer_id == "0":
                        woo_customer_id = f"guest_{email.replace('@', '_').replace('.', '_')}"
                        
                    # Aggregate metrics for this customer
                    if woo_customer_id not in customer_metrics:
                        customer_metrics[woo_customer_id] = {
                            "email": email, "name": name, "phone": phone,
                            "region": billing.get("state", ""), "city": billing.get("city", ""),
                            "country": billing.get("country", "IN"), "total_orders": 0, "total_spent": 0.0,
                            "first_order_date": None, "last_order_date": None
                        }
                    
                    customer_metrics[woo_customer_id]["total_orders"] += 1
                    customer_metrics[woo_customer_id]["total_spent"] += order_total
                    
                    # Track first/last order dates
                    order_dt = order.get("date_created")
                    if order_dt:
                        prev_first = customer_metrics[woo_customer_id]["first_order_date"]
                        prev_last = customer_metrics[woo_customer_id]["last_order_date"]
                        if prev_first is None or order_dt < prev_first:
                            customer_metrics[woo_customer_id]["first_order_date"] = order_dt
                        if prev_last is None or order_dt > prev_last:
                            customer_metrics[woo_customer_id]["last_order_date"] = order_dt

                    # Upsert customer first
                    cm = customer_metrics[woo_customer_id]
                    customer_data = {
                        "org_id": org_id,
                        "customer_id": woo_customer_id,
                        "email": cm["email"],
                        "name": cm["name"],
                        "phone": cm["phone"],
                        "region": cm["region"],
                        "city": cm["city"],
                        "country": cm["country"],
                        "total_orders": cm["total_orders"],
                        "total_spent": cm["total_spent"],
                        "average_order_value": cm["total_spent"] / cm["total_orders"],
                        "first_order_date": cm["first_order_date"],
                        "last_order_date": cm["last_order_date"],
                    }
                    supabase.table("customers").upsert(customer_data, on_conflict="org_id,customer_id").execute()
                    
                    # Get internal customer ID
                    cust_result = supabase.table("customers").select("id").eq("org_id", org_id).eq("customer_id", woo_customer_id).execute()
                    internal_customer_id = cust_result.data[0]["id"] if cust_result.data else None

                    # --- UPSERT ORDER ---
                    supabase.table("orders").upsert({
                        "org_id": org_id,
                        "order_id": str(order["id"]),
                        "customer_id": internal_customer_id,
                        "order_date": order["date_created"],
                        "total_amount": order_total,
                        "discount_amount": float(order.get("discount_total", 0)),
                        "tax_amount": float(order.get("total_tax", 0)),
                        "shipping_amount": float(order.get("shipping_total", 0)),
                        "status": mapped_status,
                        "has_discount": float(order.get("discount_total", 0)) > 0,
                        "region": billing.get("state", ""),
                        "channel": "online",
                        "platform_order_id": str(order["id"]),
                        "metadata": {
                            "payment_method": order.get("payment_method_title"),
                            "currency": order.get("currency"),
                        }
                    }, on_conflict="org_id,order_id").execute()
                    
                    # --- SYNC ORDER ITEMS (crucial for forecasting) ---
                    ord_res = supabase.table("orders").select("id").eq("org_id", org_id).eq("order_id", str(order["id"])).execute()
                    if ord_res.data:
                        internal_order_id = ord_res.data[0]["id"]
                        for item in order.get("line_items", []):
                            sku = item.get("sku") or str(item.get("product_id"))
                            prod_res = supabase.table("products").select("id").eq("org_id", org_id).eq("sku_id", sku).execute()
                            prod_id = prod_res.data[0]["id"] if prod_res.data else None
                            
                            # Use upsert to avoid duplicates on re-sync
                            try:
                                supabase.table("order_items").upsert({
                                    "order_id": internal_order_id,
                                    "product_id": prod_id,
                                    "sku_id": sku,
                                    "quantity": item.get("quantity", 1),
                                    "unit_price": float(item.get("price", 0)),
                                    "total_price": float(item.get("total", 0)),
                                }, on_conflict="order_id,sku_id").execute()
                            except Exception:
                                supabase.table("order_items").insert({
                                    "order_id": internal_order_id,
                                    "product_id": prod_id,
                                    "sku_id": sku,
                                    "quantity": item.get("quantity", 1),
                                    "unit_price": float(item.get("price", 0)),
                                    "total_price": float(item.get("total", 0)),
                                }).execute()

                    total_orders += 1
                    records_synced += 1
                except Exception as e:
                    pass
            
            print(f"   📄 Page {page}: {len(orders)} orders")
            if len(orders) < 100:
                break
            page += 1
        
        print(f"   ✅ Total orders synced: {total_orders}")
        print(f"   ✅ Customers extracted from orders: {len(customer_metrics)}")
            
    except Exception as e:
        print(f"   ❌ Orders sync error: {e}")

    # ---- Step 5: Sync Customers (Explicit API) ----
    print("\n👥 Step 5: Syncing Customers from API...")
    try:
        page = 1
        total_customers = 0
        while True:
            resp = client.get(
                f"{store_url}/wp-json/wc/v3/customers",
                params={"per_page": 100, "page": page, "role": "all"}
            )
            if resp.status_code != 200:
                print(f"   ❌ Customers API error: {resp.status_code}")
                break
                
            customers = resp.json()
            if not customers:
                break
                
            for customer in customers:
                try:
                    name = f"{customer.get('first_name', '')} {customer.get('last_name', '')}".strip()
                    billing = customer.get("billing", {})
                    cust_id_str = str(customer["id"])
                    
                    # Fetch existing customer to avoid overwriting dynamically calculated metrics
                    existing = supabase.table("customers").select("total_orders, total_spent").eq("org_id", org_id).eq("customer_id", cust_id_str).execute()
                    
                    total_orders = customer.get("orders_count", 0) or 0
                    total_spent = float(customer.get("total_spent", 0) or 0)
                    
                    if existing.data:
                        if total_orders == 0:
                            total_orders = existing.data[0].get("total_orders", 0)
                        if total_spent == 0:
                            total_spent = existing.data[0].get("total_spent", 0)
                            
                    avg_order = total_spent / max(total_orders, 1)
                    
                    supabase.table("customers").upsert({
                        "org_id": org_id,
                        "customer_id": cust_id_str,
                        "email": customer.get("email"),
                        "name": name or customer.get("username", "Unknown"),
                        "phone": billing.get("phone", ""),
                        "region": billing.get("state", ""),
                        "city": billing.get("city", ""),
                        "country": billing.get("country", "IN"),
                        "total_orders": total_orders,
                        "total_spent": total_spent,
                        "average_order_value": avg_order,
                        "platform_customer_id": cust_id_str
                    }, on_conflict="org_id,customer_id").execute()
                    total_customers += 1
                    records_synced += 1
                except Exception as e:
                    pass
            
            print(f"   📄 Page {page}: {len(customers)} customers")
            if len(customers) < 100:
                break
            page += 1
        
        print(f"   ✅ Total explicit customers synced: {total_customers}")
            
    except Exception as e:
        print(f"   ❌ Customers sync error: {e}")

    # ---- Step 6: Compute customer first/last order dates from orders table ----
    print("\n📅 Step 6: Computing customer order dates...")
    try:
        all_customers = supabase.table("customers").select("id").eq("org_id", org_id).execute()
        updated_count = 0
        for cust in (all_customers.data or []):
            cust_id = cust["id"]
            # Get first order date
            first_ord = supabase.table("orders").select("order_date").eq(
                "org_id", org_id
            ).eq("customer_id", cust_id).order("order_date").limit(1).execute()
            # Get last order date
            last_ord = supabase.table("orders").select("order_date").eq(
                "org_id", org_id
            ).eq("customer_id", cust_id).order("order_date", desc=True).limit(1).execute()
            
            update_data = {}
            if first_ord.data:
                update_data["first_order_date"] = first_ord.data[0]["order_date"]
            if last_ord.data:
                update_data["last_order_date"] = last_ord.data[0]["order_date"]
            
            if update_data:
                supabase.table("customers").update(update_data).eq("id", cust_id).execute()
                updated_count += 1
        print(f"   ✅ Updated order dates for {updated_count} customers")
    except Exception as e:
        print(f"   ⚠️ Customer dates update error: {e}")

    # ---- Step 7: Fetch WooCommerce store currency ----
    print("\n💱 Step 7: Fetching store currency settings...")
    try:
        resp = client.get(f"{store_url}/wp-json/wc/v3/settings/general/woocommerce_currency")
        if resp.status_code == 200:
            currency_code = resp.json().get("value", "INR")
            currency_symbols = {
                "INR": "₹", "USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥",
                "AUD": "A$", "CAD": "C$", "SGD": "S$", "AED": "AED", "SAR": "SAR",
                "BRL": "R$", "CNY": "¥", "KRW": "₩", "THB": "฿", "MYR": "RM",
                "IDR": "Rp", "PHP": "₱", "VND": "₫", "ZAR": "R", "NGN": "₦",
            }
            org = supabase.table("organizations").select("settings").eq("id", org_id).single().execute()
            org_settings = org.data.get("settings") or {} if org.data else {}
            org_settings["currency"] = currency_code
            org_settings["currency_symbol"] = currency_symbols.get(currency_code, currency_code)
            supabase.table("organizations").update({"settings": org_settings}).eq("id", org_id).execute()
            print(f"   ✅ Store currency: {currency_code} ({currency_symbols.get(currency_code, currency_code)})")
        else:
            print(f"   ⚠️ Currency API returned {resp.status_code}, using default")
    except Exception as e:
        print(f"   ⚠️ Currency fetch error: {e}")

    # ---- Step 8: Update sync log ----
    supabase.table("sync_logs").update({
        "status": "completed",
        "records_synced": records_synced,
        "completed_at": datetime.now(timezone.utc).isoformat()
    }).eq("id", sync_id).execute()
    
    print(f"\n{'='*60}")
    print(f"  ✅ SYNC COMPLETE!")
    print(f"  Total records synced: {records_synced}")
    print(f"  Organization ID: {org_id}")
    print(f"{'='*60}\n")
    
if __name__ == "__main__":
    sync_woocommerce()
