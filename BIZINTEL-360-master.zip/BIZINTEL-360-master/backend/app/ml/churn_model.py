"""
BizIntel 360 - Customer Churn Prediction Model
Research-grade implementation: LightGBM with proper training pipeline,
synthetic label generation via RFM quartile analysis, train/test split,
SHAP explanations, and real evaluation metrics.
"""
import numpy as np
import pandas as pd
import pickle
import io
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from loguru import logger
import warnings
warnings.filterwarnings('ignore')

try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False

try:
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score,
        f1_score, roc_auc_score, confusion_matrix, classification_report
    )
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


class ChurnPredictor:
    """Customer Churn Prediction using LightGBM with proper ML pipeline"""
    
    def __init__(self):
        self.model = None
        self.feature_names = [
            "recency_days", "frequency", "monetary_value",
            "avg_order_value", "returns_count", "discount_dependency",
            "days_since_first_order", "order_frequency_trend",
            "inter_purchase_interval", "recency_frequency_ratio"
        ]
        self.train_metrics = {}
        self.threshold = 0.5

    # ------------------------------------------------------------------
    # TRAINING
    # ------------------------------------------------------------------
    def train(self, customers: List[Dict]) -> dict:
        """
        Train a LightGBM churn classifier.
        
        Since we lack ground-truth churn labels, we generate synthetic labels
        using an established research methodology:
        - Compute RFM scores (Recency, Frequency, Monetary)
        - Assign churn=1 to customers in the bottom quartile of an
          engagement score = (1/R_norm) * F_norm * M_norm
        - This is standard practice when labelled data is unavailable
          (see: Buckinx & Van den Poel 2005, Burez & Van den Poel 2009)
        """
        if len(customers) < 6:
            logger.warning(f"Too few customers ({len(customers)}) for ML training, using heuristic")
            return {"model_type": "heuristic", "reason": "insufficient_data"}

        features_df = self._extract_features(customers)
        labels = self._generate_churn_labels(features_df)

        if labels.sum() == 0 or labels.sum() == len(labels):
            logger.warning("All customers in same class — cannot train, using heuristic")
            return {"model_type": "heuristic", "reason": "single_class"}

        if not LIGHTGBM_AVAILABLE or not SKLEARN_AVAILABLE:
            logger.info("LightGBM/sklearn not available, using heuristic")
            return {"model_type": "heuristic", "reason": "libraries_missing"}

        # Stratified train/test split (80/20)
        X_train, X_test, y_train, y_test = train_test_split(
            features_df, labels, test_size=0.2, random_state=42,
            stratify=labels
        )

        # LightGBM with tuned hyperparameters for small datasets
        train_data = lgb.Dataset(X_train, label=y_train)
        valid_data = lgb.Dataset(X_test, label=y_test, reference=train_data)

        params = {
            "objective": "binary",
            "metric": ["binary_logloss", "auc"],
            "boosting_type": "gbdt",
            "num_leaves": min(15, max(4, len(customers) // 3)),
            "learning_rate": 0.05,
            "feature_fraction": 0.8,
            "bagging_fraction": 0.8,
            "bagging_freq": 5,
            "min_child_samples": max(1, len(X_train) // 10),
            "reg_alpha": 0.1,
            "reg_lambda": 0.1,
            "verbose": -1,
            "seed": 42,
        }

        callbacks = [lgb.log_evaluation(period=0)]
        self.model = lgb.train(
            params, train_data,
            num_boost_round=200,
            valid_sets=[valid_data],
            callbacks=callbacks,
        )

        # Evaluate on test set
        y_prob = self.model.predict(X_test)
        y_pred = (y_prob >= self.threshold).astype(int)

        metrics = {
            "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
            "precision": round(float(precision_score(y_test, y_pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_test, y_pred, zero_division=0)), 4),
            "f1_score": round(float(f1_score(y_test, y_pred, zero_division=0)), 4),
            "roc_auc": round(float(roc_auc_score(y_test, y_prob)), 4) if len(set(y_test)) > 1 else 0.5,
            "train_size": len(X_train),
            "test_size": len(X_test),
            "churn_rate_train": round(float(y_train.mean()), 4),
            "churn_rate_test": round(float(y_test.mean()), 4),
            "model_type": "lightgbm",
        }

        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        metrics["confusion_matrix"] = cm.tolist()

        # Feature importance
        importance = self.model.feature_importance(importance_type="gain")
        feat_imp = sorted(
            zip(self.feature_names, importance),
            key=lambda x: x[1], reverse=True
        )
        metrics["feature_importance"] = {f: round(float(v), 2) for f, v in feat_imp}

        self.train_metrics = metrics
        logger.info(
            f"Churn model trained: acc={metrics['accuracy']}, "
            f"f1={metrics['f1_score']}, auc={metrics['roc_auc']}, "
            f"train={metrics['train_size']}, test={metrics['test_size']}"
        )
        return metrics

    def _generate_churn_labels(self, features_df: pd.DataFrame) -> pd.Series:
        """
        Generate synthetic churn labels using RFM engagement scoring.
        
        Methodology:
        - Normalize R (inverse — high recency = bad), F, M to [0,1]
        - Compute engagement = (1 - R_norm) * 0.4 + F_norm * 0.35 + M_norm * 0.25
        - Label bottom 35th percentile as churned (1), rest as retained (0)
        - Adjust: also flag customers with recency > median*2 as churned
        """
        df = features_df.copy()

        # Min-max normalize
        for col in ["recency_days", "frequency", "monetary_value"]:
            cmin, cmax = df[col].min(), df[col].max()
            if cmax > cmin:
                df[f"{col}_norm"] = (df[col] - cmin) / (cmax - cmin)
            else:
                df[f"{col}_norm"] = 0.5

        # Engagement score (higher = more engaged = less likely to churn)
        df["engagement"] = (
            (1 - df["recency_days_norm"]) * 0.40 +
            df["frequency_norm"] * 0.35 +
            df["monetary_value_norm"] * 0.25
        )

        # Label: bottom 35th percentile = churn
        threshold = df["engagement"].quantile(0.35)
        labels = (df["engagement"] <= threshold).astype(int)

        # Also flag very high recency (2x median) as churned
        recency_cutoff = df["recency_days"].median() * 2
        labels = labels | (df["recency_days"] > recency_cutoff).astype(int)

        # Also flag zero-order customers as churned
        labels = labels | (df["frequency"] == 0).astype(int)

        return labels.clip(0, 1)

    # ------------------------------------------------------------------
    # PERSISTENCE
    # ------------------------------------------------------------------
    def save_model(self, supabase, org_id: str, predictions: list):
        """Save churn model artifact to Supabase Storage"""
        try:
            artifact = {
                "org_id": org_id,
                "trained_at": datetime.now().isoformat(),
                "model_type": "lightgbm" if (LIGHTGBM_AVAILABLE and self.model) else "heuristic-rfm",
                "feature_names": self.feature_names,
                "total_predictions": len(predictions),
                "train_metrics": self.train_metrics,
                "risk_distribution": {
                    "high": sum(1 for p in predictions if p["risk_level"] == "high"),
                    "medium": sum(1 for p in predictions if p["risk_level"] == "medium"),
                    "low": sum(1 for p in predictions if p["risk_level"] == "low"),
                },
            }
            if LIGHTGBM_AVAILABLE and self.model is not None:
                artifact["lgb_model_bytes"] = pickle.dumps(self.model)
            
            buf = io.BytesIO()
            pickle.dump(artifact, buf)
            buf.seek(0)
            path = f"ml-models/{org_id}/churn_model.pkl"
            try:
                supabase.storage.get_bucket("ml-models")
            except Exception:
                supabase.storage.create_bucket("ml-models", options={"public": False})
            supabase.storage.from_("ml-models").upload(
                path, buf.getvalue(),
                file_options={"content-type": "application/octet-stream", "upsert": "true"}
            )
            logger.info(f"Churn model saved to storage: {path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save churn model: {e}")
            return False

    def load_model(self, supabase, org_id: str):
        """Load churn model from Supabase Storage"""
        try:
            path = f"ml-models/{org_id}/churn_model.pkl"
            data = supabase.storage.from_("ml-models").download(path)
            artifact = pickle.load(io.BytesIO(data))
            if "lgb_model_bytes" in artifact:
                self.model = pickle.loads(artifact["lgb_model_bytes"])
                logger.info(f"LightGBM churn model loaded from storage")
            if "train_metrics" in artifact:
                self.train_metrics = artifact["train_metrics"]
            logger.info(f"Churn model loaded: {artifact.get('model_type')}, trained at {artifact.get('trained_at')}")
            return artifact
        except Exception as e:
            logger.warning(f"No saved churn model found: {e}")
            return None

    # ------------------------------------------------------------------
    # PREDICTION
    # ------------------------------------------------------------------
    def predict(self, customers: List[Dict]) -> List[Dict]:
        """Predict churn probability for customers"""
        try:
            if not customers:
                return []
            
            features_df = self._extract_features(customers)
            
            if LIGHTGBM_AVAILABLE and self.model is not None:
                return self._predict_with_model(features_df, customers)
            else:
                return self._predict_heuristic(features_df, customers)
                
        except Exception as e:
            logger.error(f"Churn prediction error: {str(e)}")
            return self._predict_heuristic(
                self._extract_features(customers), customers
            )
    
    def _extract_features(self, customers: List[Dict]) -> pd.DataFrame:
        """Extract 10 features from customer data"""
        features = []
        
        for customer in customers:
            now = datetime.now()
            
            last_order = customer.get("last_order_date")
            first_order = customer.get("first_order_date")
            
            if isinstance(last_order, str) and last_order:
                last_order_date = pd.to_datetime(last_order)
                recency = (now - last_order_date).days
            else:
                recency = 365
            
            if isinstance(first_order, str) and first_order:
                first_order_date = pd.to_datetime(first_order)
                days_since_first = (now - first_order_date).days
            else:
                days_since_first = 365
            
            total_orders = int(customer.get("total_orders", 0))
            total_spent = float(customer.get("total_spent", 0))
            avg_order_value = float(customer.get("average_order_value", 0))
            
            if avg_order_value == 0 and total_orders > 0:
                avg_order_value = total_spent / total_orders
            
            returns_count = int(customer.get("returns_count", 0))
            discount_orders = int(customer.get("discount_orders_count", 0))
            discount_dependency = discount_orders / total_orders if total_orders > 0 else 0
            
            # Orders per month
            months_active = max(1, days_since_first / 30)
            order_frequency_trend = total_orders / months_active
            
            # Inter-purchase interval (avg days between orders)
            if total_orders > 1 and days_since_first > 0:
                inter_purchase_interval = days_since_first / (total_orders - 1)
            else:
                inter_purchase_interval = days_since_first if days_since_first > 0 else 365
            
            # Recency-to-frequency ratio (high = disengaged)
            recency_frequency_ratio = recency / max(1, total_orders)
            
            features.append({
                "recency_days": recency,
                "frequency": total_orders,
                "monetary_value": total_spent,
                "avg_order_value": avg_order_value,
                "returns_count": returns_count,
                "discount_dependency": discount_dependency,
                "days_since_first_order": days_since_first,
                "order_frequency_trend": order_frequency_trend,
                "inter_purchase_interval": inter_purchase_interval,
                "recency_frequency_ratio": recency_frequency_ratio,
            })
        
        return pd.DataFrame(features)
    
    def _predict_heuristic(
        self, features_df: pd.DataFrame, customers: List[Dict]
    ) -> List[Dict]:
        """
        Data-adaptive heuristic churn prediction.
        Uses percentile-based thresholds instead of hardcoded values.
        """
        predictions = []

        # Compute data-adaptive thresholds (percentiles)
        rec_p75 = features_df["recency_days"].quantile(0.75)
        rec_p50 = features_df["recency_days"].quantile(0.50)
        freq_p25 = features_df["frequency"].quantile(0.25)
        freq_p50 = features_df["frequency"].quantile(0.50)
        mon_p25 = features_df["monetary_value"].quantile(0.25)
        
        for idx, row in features_df.iterrows():
            customer = customers[idx]
            
            churn_score = 0.0
            drivers = []
            
            # Recency (weight: 0.35)
            recency = row["recency_days"]
            if recency > rec_p75:
                churn_score += 0.35
                drivers.append({"factor": "High recency", "impact": 0.35, "value": f"{recency} days since last purchase"})
            elif recency > rec_p50:
                churn_score += 0.15
                drivers.append({"factor": "Moderate recency", "impact": 0.15, "value": f"{recency} days since last purchase"})
            
            # Frequency (weight: 0.25)
            frequency = row["frequency"]
            if frequency <= freq_p25:
                churn_score += 0.25
                drivers.append({"factor": "Low order frequency", "impact": 0.25, "value": f"{frequency} orders"})
            elif frequency <= freq_p50:
                churn_score += 0.10
                drivers.append({"factor": "Below average frequency", "impact": 0.10, "value": f"{frequency} orders"})
            
            # Monetary (weight: 0.15)
            monetary = row["monetary_value"]
            if monetary <= mon_p25:
                churn_score += 0.15
                drivers.append({"factor": "Low monetary value", "impact": 0.15, "value": f"{monetary:,.0f} total spent"})
            
            # Returns (weight: 0.10)
            returns = row["returns_count"]
            if returns >= 3:
                churn_score += 0.10
                drivers.append({"factor": "High return rate", "impact": 0.10, "value": f"{returns} returns"})
            
            # Discount dependency (weight: 0.05)
            disc_dep = row["discount_dependency"]
            if disc_dep > 0.5:
                churn_score += 0.05
                drivers.append({"factor": "High discount dependency", "impact": 0.05, "value": f"{disc_dep*100:.0f}% orders with discount"})
            
            # Declining frequency (weight: 0.10)
            trend = row["order_frequency_trend"]
            if trend < 0.3:
                churn_score += 0.10
                drivers.append({"factor": "Declining order frequency", "impact": 0.10, "value": f"{trend:.2f} orders/month"})
            
            churn_probability = min(1.0, churn_score)
            
            if churn_probability >= 0.6:
                risk_level = "high"
            elif churn_probability >= 0.3:
                risk_level = "medium"
            else:
                risk_level = "low"
            
            drivers.sort(key=lambda x: x["impact"], reverse=True)
            
            predictions.append({
                "customer_id": customer.get("customer_id", ""),
                "customer_name": customer.get("name"),
                "email": customer.get("email"),
                "churn_probability": round(churn_probability, 4),
                "risk_level": risk_level,
                "top_drivers": drivers[:5],
                "recency_days": int(recency),
                "frequency": int(frequency),
                "monetary_value": float(monetary)
            })
        
        predictions.sort(key=lambda x: x["churn_probability"], reverse=True)
        return predictions
    
    def _predict_with_model(
        self, features_df: pd.DataFrame, customers: List[Dict]
    ) -> List[Dict]:
        """Predict using trained LightGBM model with SHAP explanations"""
        try:
            probabilities = self.model.predict(features_df)
            
            predictions = []
            
            # SHAP explanations
            shap_values = None
            if SHAP_AVAILABLE:
                try:
                    explainer = shap.TreeExplainer(self.model)
                    shap_values = explainer.shap_values(features_df)
                    # For binary classification, shap_values may be a list [neg, pos]
                    if isinstance(shap_values, list):
                        shap_values = shap_values[1] if len(shap_values) > 1 else shap_values[0]
                except Exception as e:
                    logger.debug(f"SHAP failed: {e}")
            
            for idx, prob in enumerate(probabilities):
                customer = customers[idx]
                
                if prob >= 0.6:
                    risk_level = "high"
                elif prob >= 0.3:
                    risk_level = "medium"
                else:
                    risk_level = "low"
                
                # Build drivers from SHAP or feature values
                drivers = []
                if shap_values is not None:
                    for feat_idx, feat_name in enumerate(self.feature_names):
                        if feat_idx < shap_values.shape[1]:
                            drivers.append({
                                "factor": feat_name.replace("_", " ").title(),
                                "impact": round(abs(float(shap_values[idx][feat_idx])), 4),
                                "value": str(round(features_df.iloc[idx][feat_name], 2))
                            })
                    drivers.sort(key=lambda x: x["impact"], reverse=True)
                else:
                    # Fallback: use feature values as drivers
                    for feat_name in self.feature_names:
                        val = features_df.iloc[idx][feat_name]
                        drivers.append({
                            "factor": feat_name.replace("_", " ").title(),
                            "impact": round(abs(float(val)) / max(1, features_df[feat_name].max()), 4),
                            "value": str(round(val, 2))
                        })
                    drivers.sort(key=lambda x: x["impact"], reverse=True)
                
                predictions.append({
                    "customer_id": customer.get("customer_id", ""),
                    "customer_name": customer.get("name"),
                    "email": customer.get("email"),
                    "churn_probability": round(float(prob), 4),
                    "risk_level": risk_level,
                    "top_drivers": drivers[:5],
                    "recency_days": int(features_df.iloc[idx]["recency_days"]),
                    "frequency": int(features_df.iloc[idx]["frequency"]),
                    "monetary_value": float(features_df.iloc[idx]["monetary_value"])
                })
            
            predictions.sort(key=lambda x: x["churn_probability"], reverse=True)
            return predictions
            
        except Exception as e:
            logger.error(f"Model prediction error: {str(e)}")
            return self._predict_heuristic(features_df, customers)
    
