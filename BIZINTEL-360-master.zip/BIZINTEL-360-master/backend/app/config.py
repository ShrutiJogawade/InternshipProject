"""
BizIntel 360 - Backend Configuration
"""
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from functools import lru_cache

# Resolve .env file path: look in project root (two levels up from this file)
_THIS_DIR = Path(__file__).resolve().parent  # backend/app/
_BACKEND_DIR = _THIS_DIR.parent              # backend/
_PROJECT_ROOT = _BACKEND_DIR.parent          # project root

# Check multiple possible .env locations
_ENV_FILE = None
for candidate in [
    _PROJECT_ROOT / ".env",
    _BACKEND_DIR / ".env",
    Path.cwd() / ".env",
]:
    if candidate.exists():
        _ENV_FILE = str(candidate)
        break


class Settings(BaseSettings):
    # App
    APP_NAME: str = "BizIntel 360"
    APP_ENV: str = "development"
    APP_DEBUG: bool = True
    APP_PORT: int = 8000
    FRONTEND_URL: str = "http://localhost:3000"

    # Supabase
    SUPABASE_URL: str = ""
    SUPABASE_ANON_KEY: str = ""
    SUPABASE_SERVICE_KEY: str = ""

    # JWT
    JWT_SECRET_KEY: str = "bizintel360-secret-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_MINUTES: int = 1440

    # OpenAI
    OPENAI_API_KEY: str = ""

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Shopify
    SHOPIFY_API_KEY: str = ""
    SHOPIFY_API_SECRET: str = ""
    SHOPIFY_STORE_URL: str = ""

    # WooCommerce
    WOOCOMMERCE_URL: str = ""
    WOOCOMMERCE_CONSUMER_KEY: str = ""
    WOOCOMMERCE_CONSUMER_SECRET: str = ""

    # WhatsApp Business API (Meta Cloud API)
    WHATSAPP_PHONE_NUMBER_ID: str = ""
    WHATSAPP_ACCESS_TOKEN: str = ""
    WHATSAPP_VERIFY_TOKEN: str = "bizintel360_verify"

    class Config:
        env_file = _ENV_FILE
        case_sensitive = True
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
