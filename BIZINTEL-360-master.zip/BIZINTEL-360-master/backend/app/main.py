"""
BizIntel 360 - Main FastAPI Application
AI-Powered Fashion Intelligence Platform
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
import sys

from app.config import get_settings
from app.routers import auth, forecast, churn, inventory, dashboard, chat, integrations, whatsapp, reports

from contextlib import asynccontextmanager

# Configure logging
logger.remove()
logger.add(sys.stdout, level="INFO", format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | <cyan>{name}</cyan> - {message}")
import os as _os
_log_dir = _os.path.join(_os.path.dirname(__file__), "..", "logs")
_os.makedirs(_log_dir, exist_ok=True)
logger.add(_os.path.join(_log_dir, "bizintel360.log"), rotation="10 MB", retention="7 days", level="DEBUG")

settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Initializing application scheduler...")
    from app.scheduler import start_scheduler, stop_scheduler
    start_scheduler()
    yield
    # Shutdown
    logger.info("Shutting down application scheduler...")
    stop_scheduler()

app = FastAPI(
    title="BizIntel 360 API",
    description="AI-Powered Fashion Intelligence Platform - Sales Forecasting, Churn Prediction, Stock Alerts & Conversational Analytics",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS - Allow all origins to prevent CORS errors across web/mobile/desktop
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(forecast.router, prefix="/api/forecast", tags=["Sales Forecasting"])
app.include_router(churn.router, prefix="/api/churn", tags=["Churn Prediction"])
app.include_router(inventory.router, prefix="/api/inventory", tags=["Inventory & Stock Alerts"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard Analytics"])
app.include_router(chat.router, prefix="/api/chat", tags=["Chat AI"])
app.include_router(whatsapp.router, prefix="/api/whatsapp", tags=["WhatsApp"])
app.include_router(integrations.router, prefix="/api/integrations", tags=["Platform Integrations"])
app.include_router(reports.router, prefix="/api/reports", tags=["PDF Reports"])


@app.get("/", tags=["Health"])
async def root():
    return {
        "name": "BizIntel 360 API",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    db_status = "disconnected"
    try:
        from app.database import get_supabase_admin
        sb = get_supabase_admin()
        sb.table("organizations").select("id").limit(1).execute()
        db_status = "connected"
    except Exception as e:
        db_status = f"error: {str(e)}"
    return {
        "status": "healthy" if db_status == "connected" else "degraded",
        "services": {
            "api": "up",
            "database": db_status
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=settings.APP_PORT, reload=True)
