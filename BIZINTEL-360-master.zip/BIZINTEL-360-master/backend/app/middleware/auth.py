"""
BizIntel 360 - Authentication Middleware
"""
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.database import get_supabase_admin

security = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Verify JWT token and return current user"""
    token = credentials.credentials
    
    try:
        supabase = get_supabase_admin()
        # Verify token with Supabase
        user_response = supabase.auth.get_user(token)
        
        if not user_response or not user_response.user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication token"
            )
        
        user = user_response.user
        
        # Get user profile
        profile = supabase.table("profiles").select("*").eq("id", str(user.id)).single().execute()
        
        return {
            "id": str(user.id),
            "email": user.email,
            "profile": profile.data if profile.data else {}
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Authentication failed: {str(e)}"
        )


async def require_role(required_roles: list):
    """Check if user has required role"""
    async def role_checker(current_user: dict = Depends(get_current_user)):
        user_role = current_user.get("profile", {}).get("role", "")
        if user_role not in required_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        return current_user
    return role_checker


def get_org_id(current_user: dict = Depends(get_current_user)) -> str:
    """Extract organization ID from user context"""
    # For now, get the first org the user belongs to
    supabase = get_supabase_admin()
    membership = supabase.table("org_members").select("org_id").eq(
        "user_id", current_user["id"]
    ).limit(1).execute()
    
    if membership.data:
        return membership.data[0]["org_id"]
    
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="No organization found for user"
    )
