"""
BizIntel 360 - Pydantic Models / Schemas
"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime, date
from enum import Enum


# ============================================
# ENUMS
# ============================================

class UserRole(str, Enum):
    ADMIN = "admin"
    DEVELOPER = "developer"
    SALES_MANAGER = "sales_manager"
    INVENTORY_MANAGER = "inventory_manager"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class AlertType(str, Enum):
    LOW_STOCK = "low_stock"
    OVERSTOCK = "overstock"
    OUT_OF_STOCK = "out_of_stock"


class AlertSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ForecastType(str, Enum):
    SKU = "sku"
    CATEGORY = "category"
    STORE = "store"


class Platform(str, Enum):
    SHOPIFY = "shopify"
    WOOCOMMERCE = "woocommerce"
    CUSTOM = "custom"
    MANUAL = "manual"


# ============================================
# AUTH SCHEMAS
# ============================================

class LoginRequest(BaseModel):
    email: str
    password: str


class RegisterRequest(BaseModel):
    email: str
    password: str
    full_name: str
    company_name: Optional[str] = None
    role: UserRole = UserRole.SALES_MANAGER


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]


class UserProfile(BaseModel):
    id: str
    email: str
    full_name: Optional[str]
    company_name: Optional[str]
    role: str
    avatar_url: Optional[str]
    is_active: bool
    created_at: Optional[str]


# ============================================
# ORGANIZATION SCHEMAS
# ============================================

class OrganizationCreate(BaseModel):
    name: str
    platform: Platform = Platform.MANUAL
    platform_store_url: Optional[str] = None


class OrganizationResponse(BaseModel):
    id: str
    name: str
    slug: str
    platform: Optional[str]
    settings: Optional[Dict[str, Any]]
    created_at: Optional[str]


# ============================================
# PRODUCT SCHEMAS
# ============================================

class ProductCreate(BaseModel):
    sku_id: str
    name: str
    category_id: Optional[str] = None
    price: float
    cost_price: Optional[float] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = []


class ProductResponse(BaseModel):
    id: str
    sku_id: str
    name: str
    category_name: Optional[str] = None
    price: float
    is_active: bool
    current_stock: Optional[int] = None


# ============================================
# FORECAST SCHEMAS
# ============================================

class ForecastRunRequest(BaseModel):
    org_id: str
    forecast_type: ForecastType = ForecastType.SKU
    horizon_days: int = Field(default=30, ge=7, le=90)
    sku_ids: Optional[List[str]] = None
    category_names: Optional[List[str]] = None


class ForecastResponse(BaseModel):
    sku_id: Optional[str]
    category: Optional[str]
    product_name: Optional[str] = None
    forecast_date: str
    predicted_quantity: float
    lower_bound: Optional[float]
    upper_bound: Optional[float]
    confidence: Optional[float]


class ForecastResult(BaseModel):
    forecast_type: str
    total_predictions: int
    horizon_days: int
    predictions: List[ForecastResponse]
    metrics: Optional[Dict[str, float]] = None


# ============================================
# CHURN SCHEMAS
# ============================================

class ChurnPredictRequest(BaseModel):
    org_id: str
    customer_ids: Optional[List[str]] = None  # If None, predict all


class ChurnPredictionResponse(BaseModel):
    customer_id: str
    customer_name: Optional[str]
    email: Optional[str]
    churn_probability: float
    risk_level: str
    top_drivers: List[Dict[str, Any]]
    recency_days: Optional[int]
    frequency: Optional[int]
    monetary_value: Optional[float]


class ChurnResult(BaseModel):
    total_customers: int
    high_risk: int
    medium_risk: int
    low_risk: int
    predictions: List[ChurnPredictionResponse]
    model_metrics: Optional[Dict[str, float]] = None


# ============================================
# INVENTORY SCHEMAS
# ============================================

class InventoryUpdateRequest(BaseModel):
    org_id: str
    sku_id: str
    new_stock: int
    change_type: str = "adjustment"
    change_reason: Optional[str] = None


class StockAlertResponse(BaseModel):
    id: str
    sku_id: str
    product_name: str
    alert_type: str
    severity: str
    current_stock: int
    forecasted_demand: Optional[int]
    suggested_reorder_qty: Optional[int]
    message: str
    created_at: str


class InventoryHealthResponse(BaseModel):
    sku_id: str
    product_name: str
    category_name: Optional[str]
    current_stock: int
    reorder_threshold: int
    stock_status: str


# ============================================
# DASHBOARD SCHEMAS
# ============================================

class DashboardKPIs(BaseModel):
    total_revenue: float
    total_orders: int
    avg_order_value: float
    total_customers: int
    active_customers: int
    churn_rate: float
    low_stock_count: int
    overstock_count: int
    forecast_accuracy: Optional[float] = None


class SalesChartData(BaseModel):
    dates: List[str]
    revenue: List[float]
    orders: List[int]


class CategoryBreakdown(BaseModel):
    category: str
    revenue: float
    quantity: int
    percentage: float


class DashboardResponse(BaseModel):
    kpis: DashboardKPIs
    sales_chart: SalesChartData
    category_breakdown: List[CategoryBreakdown]
    recent_alerts: List[StockAlertResponse]
    top_churn_risks: List[ChurnPredictionResponse]


# ============================================
# CHAT SCHEMAS
# ============================================

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    org_id: str


class ChatResponse(BaseModel):
    response: str
    session_id: str
    chart_data: Optional[Dict[str, Any]] = None
    suggestions: Optional[List[str]] = None


# ============================================
# INTEGRATION SCHEMAS
# ============================================

class ShopifyConnectRequest(BaseModel):
    org_id: str
    store_url: str
    api_key: str
    api_secret: str


class WooCommerceConnectRequest(BaseModel):
    org_id: str
    store_url: str
    consumer_key: str
    consumer_secret: str


class SyncStatusResponse(BaseModel):
    id: str
    platform: str
    sync_type: str
    status: str
    records_synced: int
    started_at: str
    completed_at: Optional[str]
