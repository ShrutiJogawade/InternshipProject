"""
BizIntel 360 - Supabase Client
"""
from supabase import create_client, Client
from app.config import get_settings

settings = get_settings()

# Public client (respects RLS)
supabase: Client = create_client(
    settings.SUPABASE_URL,
    settings.SUPABASE_ANON_KEY
)

# Admin client (bypasses RLS - for backend operations)
supabase_admin: Client = create_client(
    settings.SUPABASE_URL,
    settings.SUPABASE_SERVICE_KEY
)


def get_supabase() -> Client:
    """Get public Supabase client"""
    return supabase


def get_supabase_admin() -> Client:
    """Get admin Supabase client (bypasses RLS)"""
    return supabase_admin
