"""
BizIntel 360 - Background Task Scheduler
Schedule:
  - WooCommerce sync: every 6 hours
  - ML model training: daily at 2:00 AM (refreshes forecasts, churn, alerts)
"""
from loguru import logger
import subprocess
import sys
import os

_scheduler = None


def run_woo_sync():
    """Run WooCommerce sync script"""
    try:
        script_path = os.path.join(os.path.dirname(__file__), "..", "scripts", "sync_woocommerce.py")
        logger.info("Starting scheduled WooCommerce sync...")
        subprocess.run([sys.executable, script_path], check=True)
        logger.info("Scheduled WooCommerce sync completed")
    except Exception as e:
        logger.error(f"Scheduled WooCommerce sync failed: {e}")


def run_ml_training():
    """Run ML model training - forecasts, churn predictions, stock alerts"""
    try:
        script_path = os.path.join(os.path.dirname(__file__), "..", "scripts", "run_ml_models.py")
        logger.info("Starting scheduled ML model training...")
        subprocess.run([sys.executable, script_path], check=True)
        logger.info("Scheduled ML model training completed")
    except Exception as e:
        logger.error(f"Scheduled ML training failed: {e}")


def start_scheduler():
    """Start the background scheduler"""
    global _scheduler
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        from apscheduler.triggers.cron import CronTrigger

        _scheduler = BackgroundScheduler()

        # WooCommerce sync every 5 minutes
        _scheduler.add_job(
            run_woo_sync, 'interval', minutes=5,
            id='woo_sync', replace_existing=True,
            misfire_grace_time=300,
        )

        # ML training daily at 2:00 AM server time
        _scheduler.add_job(
            run_ml_training,
            CronTrigger(hour=2, minute=0),
            id='ml_training_daily',
            replace_existing=True,
            misfire_grace_time=3600,
        )

        _scheduler.start()
        logger.info("Background scheduler started — WooSync every 5min, ML training daily at 02:00")
    except ImportError:
        logger.warning("APScheduler not installed. Background scheduling disabled.")
    except Exception as e:
        logger.warning(f"Scheduler start failed (non-critical): {e}")


def stop_scheduler():
    """Stop the background scheduler"""
    global _scheduler
    try:
        if _scheduler:
            _scheduler.shutdown(wait=False)
            logger.info("Background scheduler stopped")
    except Exception as e:
        logger.warning(f"Scheduler stop failed: {e}")
