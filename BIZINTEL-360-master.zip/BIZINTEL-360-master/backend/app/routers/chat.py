"""
BizIntel 360 - AI Chatbot Router
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
from loguru import logger
import json
import re

from app.database import get_supabase_admin
from app.models.schemas import ChatRequest, ChatResponse
from app.middleware.auth import get_current_user
from app.config import get_settings

router = APIRouter()
settings = get_settings()

CURRENCY_SYMBOLS = {
    "INR": "\u20b9", "USD": "$", "EUR": "\u20ac", "GBP": "\u00a3",
    "JPY": "\u00a5", "AUD": "A$", "CAD": "C$", "SGD": "S$",
    "AED": "AED", "SAR": "SAR", "BRL": "R$", "CNY": "\u00a5",
}


def _get_currency_symbol(supabase, org_id: str) -> str:
    """Get currency symbol from org settings in Supabase"""
    try:
        org = supabase.table("organizations").select("settings").eq("id", org_id).single().execute()
        if org.data and org.data.get("settings"):
            code = org.data["settings"].get("currency", "INR")
            return CURRENCY_SYMBOLS.get(code, code)
    except Exception:
        pass
    return "\u20b9"


@router.post("/message", response_model=ChatResponse)
async def send_chat_message(
    request: ChatRequest,
    current_user: dict = Depends(get_current_user)
):
    """Process a chat message and return AI response with data"""
    try:
        supabase = get_supabase_admin()
        org_id = request.org_id
        
        # Create or get session
        session_id = request.session_id
        if not session_id:
            session = supabase.table("chat_sessions").insert({
                "org_id": org_id,
                "user_id": current_user["id"],
                "title": request.message[:50]
            }).execute()
            session_id = session.data[0]["id"]
        
        # Store user message
        supabase.table("chat_messages").insert({
            "session_id": session_id,
            "role": "user",
            "content": request.message
        }).execute()
        
        # Get currency symbol from org settings
        currency = _get_currency_symbol(supabase, org_id)
        
        # Process query
        response_data = await _process_query(request.message, org_id, supabase, currency)
        
        # Store assistant response
        supabase.table("chat_messages").insert({
            "session_id": session_id,
            "role": "assistant",
            "content": response_data["response"],
            "metadata": {"chart_data": response_data.get("chart_data")}
        }).execute()
        
        return ChatResponse(
            response=response_data["response"],
            session_id=session_id,
            chart_data=response_data.get("chart_data"),
            suggestions=response_data.get("suggestions", [])
        )
        
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions")
async def get_chat_sessions(
    org_id: str = Query(...),
    current_user: dict = Depends(get_current_user)
):
    """Get user's chat sessions"""
    try:
        supabase = get_supabase_admin()
        
        sessions = supabase.table("chat_sessions").select("*").eq(
            "user_id", current_user["id"]
        ).eq("org_id", org_id).order("updated_at", desc=True).execute()
        
        return {"sessions": sessions.data or []}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Get messages for a chat session"""
    try:
        supabase = get_supabase_admin()
        
        messages = supabase.table("chat_messages").select("*").eq(
            "session_id", session_id
        ).order("created_at").execute()
        
        return {"messages": messages.data or []}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


async def _process_query(message: str, org_id: str, supabase, currency: str = "\u20b9") -> dict:
    """Process natural language query and return data-driven response"""
    message_lower = message.lower()
    
    # Intent detection and response generation
    if any(kw in message_lower for kw in ["out of stock", "low stock", "stock alert", "running out", "reorder"]):
        return await _handle_stock_query(org_id, supabase)
    
    elif any(kw in message_lower for kw in ["churn", "risk", "leaving", "stop buying", "at risk"]):
        return await _handle_churn_query(org_id, supabase, currency)
    
    elif any(kw in message_lower for kw in ["forecast", "demand", "predict", "next month", "next week", "expected"]):
        return await _handle_forecast_query(message_lower, org_id, supabase)
    
    elif any(kw in message_lower for kw in ["revenue", "sales", "income", "earning"]):
        return await _handle_revenue_query(org_id, supabase, currency)
    
    elif any(kw in message_lower for kw in ["top product", "best seller", "popular", "top selling"]):
        return await _handle_top_products_query(org_id, supabase, currency)
    
    elif any(kw in message_lower for kw in ["customer", "buyer", "client"]):
        return await _handle_customer_query(org_id, supabase, currency)
    
    elif any(kw in message_lower for kw in ["inventory", "warehouse", "stock level"]):
        return await _handle_inventory_query(org_id, supabase)
    
    elif any(kw in message_lower for kw in ["help", "what can you", "capabilities"]):
        return _handle_help_query()
    
    else:
        return _handle_general_query(message)


async def _handle_stock_query(org_id: str, supabase) -> dict:
    """Handle stock-related queries"""
    inventory = supabase.table("inventory").select(
        "sku_id, current_stock, reorder_threshold, safety_stock, products(name)"
    ).eq("org_id", org_id).execute()
    
    low_stock = []
    out_of_stock = []
    
    for item in (inventory.data or []):
        name = item.get("products", {}).get("name", "Unknown Product") if item.get("products") else "Unknown Product"
        if item["current_stock"] <= 0:
            out_of_stock.append(f"🚨 **{name}**: OUT OF STOCK")
        elif item["current_stock"] <= item["safety_stock"]:
            low_stock.append(f"⚠️ **{name}**: {item['current_stock']} units (critical)")
        elif item["current_stock"] <= item["reorder_threshold"]:
            low_stock.append(f"📦 **{name}**: {item['current_stock']} units (low)")
    
    response = "## Stock Alert Summary\n\n"
    
    if out_of_stock:
        response += "### 🚨 Out of Stock\n" + "\n".join(out_of_stock) + "\n\n"
    
    if low_stock:
        response += "### ⚠️ Low Stock Items\n" + "\n".join(low_stock) + "\n\n"
    
    if not out_of_stock and not low_stock:
        response += "✅ All products are well-stocked! No immediate action needed.\n"
    else:
        response += f"\n**Action Required:** {len(out_of_stock)} items need immediate reorder, {len(low_stock)} items approaching reorder point."
    
    return {
        "response": response,
        "chart_data": {
            "type": "bar",
            "labels": [(item.get("products") or {}).get("name", item["sku_id"])[:20] for item in (inventory.data or [])[:10]],
            "values": [item["current_stock"] for item in (inventory.data or [])[:10]],
            "title": "Current Stock Levels"
        },
        "suggestions": [
            "Show me the forecast for low-stock items",
            "What's the reorder quantity for out-of-stock items?",
            "Show inventory health summary"
        ]
    }


async def _handle_churn_query(org_id: str, supabase, currency: str = "\u20b9") -> dict:
    """Handle churn-related queries"""
    predictions = supabase.table("churn_predictions").select(
        "churn_probability, risk_level, customers(customer_id, name, email, total_spent)"
    ).eq("org_id", org_id).order("churn_probability", desc=True).limit(10).execute()
    
    if not predictions.data:
        return {
            "response": "No churn predictions available yet. Run the churn prediction model first to identify at-risk customers.",
            "suggestions": ["Run churn prediction", "Show customer overview"]
        }
    
    response = "## 🎯 Customer Churn Risk Analysis\n\n"
    
    high_risk = [p for p in predictions.data if p["risk_level"] == "high"]
    
    if high_risk:
        response += f"### High Risk Customers ({len(high_risk)})\n\n"
        for p in high_risk[:5]:
            customer = p.get("customers", {})
            name = customer.get("name", "Unknown") if customer else "Unknown"
            prob = round(p["churn_probability"] * 100, 1)
            spent = customer.get("total_spent", 0) if customer else 0
            response += f"- **{name}**: {prob}% churn probability ({currency}{spent:,.0f} lifetime value)\n"
    
    response += "\n**Recommendation:** Engage high-risk customers with personalized offers and loyalty rewards."
    
    return {
        "response": response,
        "chart_data": {
            "type": "pie",
            "labels": ["High Risk", "Medium Risk", "Low Risk"],
            "values": [
                len([p for p in predictions.data if p["risk_level"] == "high"]),
                len([p for p in predictions.data if p["risk_level"] == "medium"]),
                len([p for p in predictions.data if p["risk_level"] == "low"])
            ],
            "title": "Customer Churn Risk Distribution"
        },
        "suggestions": [
            "Show detailed drivers for each high-risk customer",
            "What retention actions should we take?",
            "Show customer lifetime value breakdown"
        ]
    }


async def _handle_forecast_query(message: str, org_id: str, supabase) -> dict:
    """Handle forecast-related queries"""
    forecasts = supabase.table("forecasts").select("*").eq(
        "org_id", org_id
    ).order("forecast_date").limit(30).execute()
    
    if not forecasts.data:
        return {
            "response": "No forecasts available yet. I can generate them for you. Would you like me to run the sales forecast model?",
            "suggestions": ["Run sales forecast", "Show product categories", "Show historical sales"]
        }
    
    response = "## 📊 Sales Forecast Overview\n\n"
    
    # Group by reference
    ref_map = {}
    for f in forecasts.data:
        ref = f["reference_name"] or f["reference_id"]
        if ref not in ref_map:
            ref_map[ref] = []
        ref_map[ref].append(f)
    
    for ref, preds in list(ref_map.items())[:5]:
        total_predicted = sum(p["predicted_quantity"] for p in preds)
        response += f"- **{ref}**: {total_predicted:.0f} units predicted over next {len(preds)} days\n"
    
    response += "\n📈 Forecast generated using hybrid Prophet + XGBoost model."
    
    return {
        "response": response,
        "chart_data": {
            "type": "line",
            "labels": [f["forecast_date"] for f in forecasts.data[:30]],
            "values": [f["predicted_quantity"] for f in forecasts.data[:30]],
            "title": "Sales Forecast"
        },
        "suggestions": [
            "Forecast for jackets next month",
            "Which products need restocking?",
            "Show forecast accuracy metrics"
        ]
    }


async def _handle_revenue_query(org_id: str, supabase, currency: str = "\u20b9") -> dict:
    """Handle revenue queries"""
    orders = supabase.table("orders").select(
        "total_amount, order_date"
    ).eq("org_id", org_id).in_("status", ["completed", "processing", "on-hold"]).order("order_date", desc=True).limit(100).execute()
    
    total = sum(float(o.get("total_amount", 0)) for o in (orders.data or []))
    count = len(orders.data or [])
    avg = total / count if count > 0 else 0
    
    response = f"## 💰 Revenue Summary\n\n"
    response += f"- **Total Revenue:** {currency}{total:,.2f}\n"
    response += f"- **Total Orders:** {count}\n"
    response += f"- **Average Order Value:** {currency}{avg:,.2f}\n"
    
    return {
        "response": response,
        "chart_data": {
            "type": "line",
            "labels": [o["order_date"][:10] for o in (orders.data or [])[:30]],
            "values": [float(o["total_amount"]) for o in (orders.data or [])[:30]],
            "title": "Revenue Trend"
        },
        "suggestions": [
            "Show revenue by category",
            "Compare this month vs last month",
            "Show top revenue products"
        ]
    }


async def _handle_top_products_query(org_id: str, supabase, currency: str = "\u20b9") -> dict:
    """Handle top products queries"""
    products = supabase.table("products").select(
        "sku_id, name, price"
    ).eq("org_id", org_id).eq("is_active", True).execute()
    
    # Get actual sales data to show real top products by revenue
    orders_data = supabase.table("orders").select("id").eq("org_id", org_id).in_(
        "status", ["completed", "processing", "on-hold"]
    ).execute()
    order_ids = [o["id"] for o in (orders_data.data or [])]

    name_map = {p["sku_id"]: p for p in (products.data or [])}

    from collections import defaultdict
    agg = defaultdict(lambda: {"qty": 0, "rev": 0.0})
    for oid in order_ids[:100]:  # limit to avoid too many queries
        items = supabase.table("order_items").select(
            "sku_id, quantity, total_price"
        ).eq("order_id", oid).execute()
        for it in (items.data or []):
            agg[it["sku_id"]]["qty"] += it["quantity"]
            agg[it["sku_id"]]["rev"] += float(it["total_price"])

    sorted_prods = sorted(agg.items(), key=lambda x: x[1]["rev"], reverse=True)

    response = "## 🏆 Top Products by Revenue\n\n"
    rank = 0
    for sku, d in sorted_prods:
        prod_name = name_map.get(sku, {}).get("name", "")
        if not prod_name or prod_name == "0":
            continue  # skip unmapped/invalid products
        rank += 1
        response += f"{rank}. **{prod_name}**: {currency}{d['rev']:,.0f} | {d['qty']} sold\n"
        if rank >= 10:
            break

    if rank == 0:
        response += "No sales data available yet.\n"
    
    return {
        "response": response,
        "suggestions": ["Show forecast for each product", "Which products are low on stock?"]
    }


async def _handle_customer_query(org_id: str, supabase, currency: str = "\u20b9") -> dict:
    """Handle customer queries"""
    customers = supabase.table("customers").select("*").eq(
        "org_id", org_id
    ).order("total_spent", desc=True).limit(10).execute()
    
    response = "## 👥 Top Customers by Spending\n\n"
    for c in (customers.data or []):
        response += f"- **{c.get('name', 'N/A')}**: {currency}{float(c.get('total_spent', 0)):,.2f} ({c.get('total_orders', 0)} orders)\n"
    
    return {
        "response": response,
        "suggestions": ["Show churn risk for top customers", "Customer segmentation breakdown"]
    }


async def _handle_inventory_query(org_id: str, supabase) -> dict:
    """Handle inventory queries"""
    inventory = supabase.table("inventory").select(
        "sku_id, current_stock, products(name)"
    ).eq("org_id", org_id).execute()
    
    response = "## 📦 Inventory Overview\n\n"
    total_items = 0
    total_stock = 0
    
    for item in (inventory.data or []):
        name = item.get("products", {}).get("name", item["sku_id"]) if item.get("products") else item["sku_id"]
        response += f"- **{name}**: {item['current_stock']} units\n"
        total_items += 1
        total_stock += item["current_stock"]
    
    response += f"\n**Total SKUs:** {total_items} | **Total Stock:** {total_stock} units"
    
    return {
        "response": response,
        "chart_data": {
            "type": "bar",
            "labels": [item.get("products", {}).get("name", item["sku_id"])[:15] if item.get("products") else item["sku_id"] for item in (inventory.data or [])],
            "values": [item["current_stock"] for item in (inventory.data or [])],
            "title": "Stock Levels by Product"
        },
        "suggestions": ["Show low stock alerts", "Which items need reordering?"]
    }


def _handle_help_query() -> dict:
    """Handle help queries"""
    return {
        "response": """## 🤖 BizIntel 360 AI Assistant

I can help you with:

### 📊 Sales & Revenue
- "What's our total revenue this month?"
- "Show top selling products"
- "Revenue breakdown by category"

### 🔮 Forecasting
- "What's the expected demand for jackets next month?"
- "Show sales forecast for all products"
- "Forecast accuracy metrics"

### 👥 Customer Analytics
- "Show top 5 high churn customers"
- "Which customers are at risk of leaving?"
- "Customer spending breakdown"

### 📦 Inventory
- "Which products will go out of stock?"
- "Show inventory health"
- "What needs reordering?"

Just ask me anything about your business data!""",
        "suggestions": [
            "Show dashboard overview",
            "Which products are running low?",
            "Show churn risk analysis"
        ]
    }


def _handle_general_query(message: str) -> dict:
    """Handle general/unknown queries"""
    return {
        "response": f"I understand you're asking about: *{message}*\n\nI can help with sales forecasting, churn prediction, inventory management, and business analytics. Try asking me something specific like:\n- \"Which products will go out of stock next week?\"\n- \"Show top 5 high churn customers\"\n- \"What is the expected demand for jackets?\"",
        "suggestions": [
            "Show me stock alerts",
            "Who are the high-risk customers?",
            "What's our sales forecast?"
        ]
    }
