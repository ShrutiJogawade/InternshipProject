"""
BizIntel 360 - WhatsApp Business API Integration
Handles incoming WhatsApp messages via Meta Cloud API webhook,
processes them through the same chat engine, and replies via WhatsApp.
"""
from fastapi import APIRouter, Request, HTTPException, Query
from loguru import logger
import httpx
import json

from app.database import get_supabase_admin
from app.config import get_settings

router = APIRouter()
settings = get_settings()

WHATSAPP_API_URL = "https://graph.facebook.com/v18.0"


def _get_whatsapp_config():
    """Get WhatsApp credentials from settings"""
    return {
        "phone_number_id": getattr(settings, "WHATSAPP_PHONE_NUMBER_ID", ""),
        "access_token": getattr(settings, "WHATSAPP_ACCESS_TOKEN", ""),
        "verify_token": getattr(settings, "WHATSAPP_VERIFY_TOKEN", "bizintel360_verify"),
    }


@router.get("/webhook")
async def verify_webhook(
    hub_mode: str = Query(None, alias="hub.mode"),
    hub_verify_token: str = Query(None, alias="hub.verify_token"),
    hub_challenge: str = Query(None, alias="hub.challenge"),
):
    """Verify webhook for Meta WhatsApp Cloud API"""
    config = _get_whatsapp_config()
    if hub_mode == "subscribe" and hub_verify_token == config["verify_token"]:
        logger.info("WhatsApp webhook verified successfully")
        return int(hub_challenge)
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/webhook")
async def receive_whatsapp_message(request: Request):
    """Receive and process incoming WhatsApp messages"""
    try:
        body = await request.json()
    except Exception:
        return {"status": "ok"}

    # Extract message from Meta webhook payload
    try:
        entry = body.get("entry", [{}])[0]
        changes = entry.get("changes", [{}])[0]
        value = changes.get("value", {})
        messages = value.get("messages", [])

        if not messages:
            return {"status": "ok"}

        message = messages[0]
        sender_phone = message.get("from", "")
        msg_type = message.get("type", "")

        if msg_type != "text":
            await _send_whatsapp_reply(
                sender_phone,
                "I can only process text messages right now. Please send a text query like:\n\n"
                "• *revenue summary*\n• *stock alerts*\n• *churn analysis*\n• *top products*",
            )
            return {"status": "ok"}

        user_message = message["text"]["body"]
        logger.info(f"WhatsApp message from {sender_phone}: {user_message}")

        # Find the org linked to this phone number, or use default org
        supabase = get_supabase_admin()
        org_id = await _resolve_org(supabase, sender_phone)

        if not org_id:
            await _send_whatsapp_reply(
                sender_phone,
                "Your phone number is not linked to any organization. "
                "Please register at BizIntel 360 first.",
            )
            return {"status": "ok"}

        # Process the message through the same chat engine
        response_text = await _process_chat_query(supabase, org_id, user_message)

        # Send reply via WhatsApp
        await _send_whatsapp_reply(sender_phone, response_text)

        return {"status": "ok"}

    except Exception as e:
        logger.error(f"WhatsApp webhook error: {e}")
        return {"status": "error", "detail": str(e)}


async def _resolve_org(supabase, phone: str) -> str | None:
    """Find org_id for a WhatsApp phone number"""
    # Try to find a profile with this phone, then get their org
    try:
        profile = supabase.table("profiles").select("id").eq("phone", phone).limit(1).execute()
        if profile.data:
            user_id = profile.data[0]["id"]
            membership = supabase.table("org_members").select("org_id").eq(
                "user_id", user_id
            ).limit(1).execute()
            if membership.data:
                return membership.data[0]["org_id"]

        # Fallback: use the first available org
        org = supabase.table("organizations").select("id").limit(1).execute()
        if org.data:
            return org.data[0]["id"]
    except Exception as e:
        logger.error(f"Org resolution error: {e}")

    return None


async def _process_chat_query(supabase, org_id: str, message: str) -> str:
    """Process a chat query using the same logic as the chat router"""
    from app.routers.chat import _get_currency_symbol

    currency = _get_currency_symbol(supabase, org_id)
    lower = message.lower().strip()

    # Revenue / Sales
    if any(kw in lower for kw in ["revenue", "sales", "income", "earning"]):
        orders = supabase.table("orders").select("total_amount, status").eq(
            "org_id", org_id
        ).in_("status", ["completed", "processing", "on-hold"]).execute()
        total = sum(float(o["total_amount"]) for o in (orders.data or []))
        count = len(orders.data or [])
        avg = total / count if count > 0 else 0
        return (
            f"💰 *Revenue Summary*\n\n"
            f"• Total Revenue: {currency}{total:,.2f}\n"
            f"• Total Orders: {count}\n"
            f"• Avg Order Value: {currency}{avg:,.2f}"
        )

    # Stock / Inventory
    if any(kw in lower for kw in ["stock", "inventory", "alert"]):
        inv = supabase.table("inventory").select(
            "sku_id, current_stock, reorder_threshold, safety_stock, products(name)"
        ).eq("org_id", org_id).execute()

        low = [i for i in (inv.data or []) if 0 < i["current_stock"] <= i["reorder_threshold"]]
        out = [i for i in (inv.data or []) if i["current_stock"] == 0]

        if not low and not out:
            return "✅ *Stock Alert Summary*\n\nAll products are well-stocked! No action needed."

        lines = ["📦 *Stock Alert Summary*\n"]
        if out:
            lines.append(f"🚨 *Out of Stock ({len(out)}):*")
            for i in out[:5]:
                name = (i.get('products') or {}).get('name', 'Unknown Product')
                lines.append(f"  • {name}")
        if low:
            lines.append(f"\n⚠️ *Low Stock ({len(low)}):*")
            for i in low[:5]:
                name = (i.get('products') or {}).get('name', 'Unknown Product')
                lines.append(f"  • {name}: {i['current_stock']} units")
        return "\n".join(lines)

    # Churn
    if any(kw in lower for kw in ["churn", "risk", "customer risk"]):
        preds = supabase.table("churn_predictions").select(
            "churn_probability, risk_level, customers(name, total_spent)"
        ).eq("org_id", org_id).order("churn_probability", desc=True).limit(5).execute()

        if not preds.data:
            return "No churn data available. Run ML models first."

        high = sum(1 for p in preds.data if p["risk_level"] == "high")
        lines = [f"🎯 *Top Churn Risks*\n\nHigh risk customers: {high}\n"]
        for p in preds.data[:5]:
            cust = p.get("customers", {}) or {}
            name = cust.get("name", "Unknown")
            prob = float(p["churn_probability"]) * 100
            spent = float(cust.get("total_spent", 0))
            lines.append(f"• *{name}*: {prob:.0f}% risk ({currency}{spent:,.0f} lifetime)")
        return "\n".join(lines)

    # Top products
    if any(kw in lower for kw in ["top product", "best sell", "popular"]):
        # Get order_items filtered by org through orders table
        orders = supabase.table("orders").select("id").eq("org_id", org_id).in_(
            "status", ["completed", "processing", "on-hold"]
        ).execute()
        order_ids = [o["id"] for o in (orders.data or [])]

        if not order_ids:
            return "No order data available yet."

        # Build a product name lookup
        products = supabase.table("products").select("sku_id, name").eq("org_id", org_id).execute()
        name_map = {p["sku_id"]: p["name"] for p in (products.data or [])}

        from collections import defaultdict
        agg = defaultdict(lambda: {"qty": 0, "rev": 0.0})
        for oid in order_ids:
            items = supabase.table("order_items").select(
                "sku_id, quantity, total_price"
            ).eq("order_id", oid).execute()
            for it in (items.data or []):
                sku = it["sku_id"]
                agg[sku]["qty"] += it["quantity"]
                agg[sku]["rev"] += float(it["total_price"])

        # Filter out unknown SKUs (no product name) and sort by revenue
        sorted_prods = sorted(agg.items(), key=lambda x: x[1]["rev"], reverse=True)
        lines = ["⭐ *Top Products*\n"]
        rank = 0
        for sku, d in sorted_prods:
            prod_name = name_map.get(sku, "")
            if not prod_name or prod_name == "0":
                continue  # skip unmapped/invalid products
            rank += 1
            lines.append(f"{rank}. *{prod_name}*\n   {currency}{d['rev']:,.0f} | {d['qty']} sold")
            if rank >= 5:
                break
        return "\n".join(lines) if rank > 0 else "No product data available."

    # Forecast
    if any(kw in lower for kw in ["forecast", "predict", "demand"]):
        forecasts = supabase.table("forecasts").select(
            "reference_id, reference_name, predicted_quantity, forecast_date"
        ).eq("org_id", org_id).order("forecast_date").limit(50).execute()

        if not forecasts.data:
            return "No forecast data available. Run ML models first."

        # Build product name lookup for any SKU-based reference names
        products = supabase.table("products").select("sku_id, name").eq("org_id", org_id).execute()
        name_map = {p["sku_id"]: p["name"] for p in (products.data or [])}

        # Aggregate predicted quantity per product
        from collections import defaultdict
        totals = defaultdict(lambda: {"qty": 0.0, "name": ""})
        for f in forecasts.data:
            ref_id = f.get("reference_id", "")
            ref_name = f.get("reference_name", ref_id)
            # Resolve product name: prefer name_map lookup, then reference_name
            prod_name = name_map.get(ref_id, name_map.get(ref_name, ref_name))
            totals[ref_id]["qty"] += float(f["predicted_quantity"])
            totals[ref_id]["name"] = prod_name

        sorted_items = sorted(totals.items(), key=lambda x: x[1]["qty"], reverse=True)
        lines = ["📊 *Sales Forecast (Next 30 Days)*\n"]
        count = 0
        for ref_id, d in sorted_items:
            pname = d["name"]
            if not pname or pname == "0" or pname == ref_id and ref_id.isdigit():
                continue  # skip unmapped/invalid products
            count += 1
            lines.append(f"• *{pname}*: ~{d['qty']:.0f} units")
            if count >= 5:
                break
        return "\n".join(lines) if count > 0 else "No forecast data available."

    # Help / Default
    return (
        "👋 *BizIntel 360 AI Assistant*\n\n"
        "I can help with:\n"
        "• *revenue summary* — Sales & revenue data\n"
        "• *stock alerts* — Inventory status\n"
        "• *churn analysis* — Customer risk\n"
        "• *top products* — Best sellers\n"
        "• *forecast* — Demand predictions\n\n"
        "Just type your question!"
    )


@router.post("/send-test")
async def send_test_message(
    request: Request,
):
    """Send a test WhatsApp message to verify integration"""
    try:
        body = await request.json()
        phone = body.get("phone", "")
        message = body.get("message", "")

        if not phone:
            raise HTTPException(status_code=400, detail="Phone number is required")

        # Default test message
        if not message:
            message = (
                "\u2705 *BizIntel 360 - WhatsApp Connected!*\n\n"
                "Your WhatsApp integration is working.\n\n"
                "Try these commands:\n"
                "\u2022 *revenue summary*\n"
                "\u2022 *stock alerts*\n"
                "\u2022 *churn analysis*\n"
                "\u2022 *top products*\n"
                "\u2022 *forecast*"
            )

        await _send_whatsapp_reply(phone, message)
        return {"status": "sent", "phone": phone}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"WhatsApp test send error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/send")
async def send_whatsapp_message(request: Request):
    """Send a WhatsApp message to a phone number with org context"""
    try:
        body = await request.json()
        phone = body.get("phone", "")
        query = body.get("message", "")
        org_id = body.get("org_id", "")

        if not phone or not query:
            raise HTTPException(status_code=400, detail="phone and message are required")

        supabase = get_supabase_admin()

        if not org_id:
            org = supabase.table("organizations").select("id").limit(1).execute()
            org_id = org.data[0]["id"] if org.data else None

        if org_id:
            response_text = await _process_chat_query(supabase, org_id, query)
        else:
            response_text = query

        await _send_whatsapp_reply(phone, response_text)
        return {"status": "sent", "phone": phone, "response": response_text}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"WhatsApp send error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def _send_whatsapp_reply(to: str, text: str):
    """Send a WhatsApp message via Meta Cloud API"""
    config = _get_whatsapp_config()

    if not config["phone_number_id"] or not config["access_token"]:
        logger.warning("WhatsApp credentials not configured — skipping reply")
        return

    url = f"{WHATSAPP_API_URL}/{config['phone_number_id']}/messages"
    headers = {
        "Authorization": f"Bearer {config['access_token']}",
        "Content-Type": "application/json",
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": text},
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(url, json=payload, headers=headers)
        if resp.status_code != 200:
            logger.error(f"WhatsApp send error: {resp.status_code} {resp.text}")
        else:
            logger.info(f"WhatsApp reply sent to {to}")
