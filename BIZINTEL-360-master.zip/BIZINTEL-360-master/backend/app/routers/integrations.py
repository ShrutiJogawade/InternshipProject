"""
BizIntel 360 - Platform Integrations Router (Shopify, WooCommerce)
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional
from loguru import logger
import httpx
from datetime import datetime

from app.database import get_supabase_admin
from app.models.schemas import ShopifyConnectRequest, WooCommerceConnectRequest, SyncStatusResponse
from app.middleware.auth import get_current_user

router = APIRouter()


@router.post("/shopify/connect")
async def connect_shopify(
    request: ShopifyConnectRequest,
    current_user: dict = Depends(get_current_user)
):
    """Connect a Shopify store"""
    try:
        supabase = get_supabase_admin()
        
        # Validate Shopify credentials
        headers = {
            "X-Shopify-Access-Token": request.api_secret,
            "Content-Type": "application/json"
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://{request.store_url}/admin/api/2024-01/shop.json",
                headers=headers
            )
        
        if response.status_code != 200:
            raise HTTPException(status_code=400, detail="Invalid Shopify credentials")
        
        shop_info = response.json().get("shop", {})
        
        # Update organization
        supabase.table("organizations").update({
            "platform": "shopify",
            "platform_store_url": request.store_url,
            "platform_api_key": request.api_key,
            "platform_api_secret": request.api_secret,
            "settings": {
                "shop_name": shop_info.get("name"),
                "currency": shop_info.get("currency"),
                "country": shop_info.get("country_code")
            }
        }).eq("id", request.org_id).execute()
        
        logger.info(f"Shopify store connected: {request.store_url}")
        
        return {
            "message": "Shopify store connected successfully",
            "shop_name": shop_info.get("name"),
            "store_url": request.store_url
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Shopify connection error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/shopify/sync")
async def sync_shopify_data(
    org_id: str = Query(...),
    sync_type: str = Query("full"),
    current_user: dict = Depends(get_current_user)
):
    """Sync data from Shopify store"""
    try:
        supabase = get_supabase_admin()
        
        # Get org credentials
        org = supabase.table("organizations").select("*").eq("id", org_id).single().execute()
        
        if not org.data or org.data.get("platform") != "shopify":
            raise HTTPException(status_code=400, detail="Shopify not connected")
        
        # Create sync log
        sync_log = supabase.table("sync_logs").insert({
            "org_id": org_id,
            "platform": "shopify",
            "sync_type": sync_type,
            "status": "running"
        }).execute()
        
        sync_id = sync_log.data[0]["id"]
        
        try:
            headers = {
                "X-Shopify-Access-Token": org.data["platform_api_secret"],
                "Content-Type": "application/json"
            }
            store_url = org.data["platform_store_url"]
            records_synced = 0
            
            async with httpx.AsyncClient() as client:
                # Sync Products
                if sync_type in ("full", "products"):
                    products_resp = await client.get(
                        f"https://{store_url}/admin/api/2024-01/products.json?limit=250",
                        headers=headers
                    )
                    if products_resp.status_code == 200:
                        products = products_resp.json().get("products", [])
                        for product in products:
                            for variant in product.get("variants", []):
                                supabase.table("products").upsert({
                                    "org_id": org_id,
                                    "sku_id": variant.get("sku") or str(variant["id"]),
                                    "name": f"{product['title']} - {variant.get('title', '')}".strip(" - "),
                                    "price": float(variant.get("price", 0)),
                                    "platform_product_id": str(product["id"]),
                                    "is_active": product.get("status") == "active"
                                }, on_conflict="org_id,sku_id").execute()
                                records_synced += 1
                
                # Sync Orders
                if sync_type in ("full", "orders"):
                    orders_resp = await client.get(
                        f"https://{store_url}/admin/api/2024-01/orders.json?limit=250&status=any",
                        headers=headers
                    )
                    if orders_resp.status_code == 200:
                        orders = orders_resp.json().get("orders", [])
                        for order in orders:
                            supabase.table("orders").upsert({
                                "org_id": org_id,
                                "order_id": str(order["order_number"]),
                                "order_date": order["created_at"],
                                "total_amount": float(order.get("total_price", 0)),
                                "discount_amount": float(order.get("total_discounts", 0)),
                                "status": _map_shopify_status(order.get("financial_status")),
                                "has_discount": float(order.get("total_discounts", 0)) > 0,
                                "platform_order_id": str(order["id"])
                            }, on_conflict="org_id,order_id").execute()
                            records_synced += 1
                
                # Sync Customers
                if sync_type in ("full", "customers"):
                    customers_resp = await client.get(
                        f"https://{store_url}/admin/api/2024-01/customers.json?limit=250",
                        headers=headers
                    )
                    if customers_resp.status_code == 200:
                        customers = customers_resp.json().get("customers", [])
                        for customer in customers:
                            supabase.table("customers").upsert({
                                "org_id": org_id,
                                "customer_id": str(customer["id"]),
                                "email": customer.get("email"),
                                "name": f"{customer.get('first_name', '')} {customer.get('last_name', '')}".strip(),
                                "total_orders": customer.get("orders_count", 0),
                                "total_spent": float(customer.get("total_spent", 0)),
                                "platform_customer_id": str(customer["id"])
                            }, on_conflict="org_id,customer_id").execute()
                            records_synced += 1
            
            # Update sync log
            supabase.table("sync_logs").update({
                "status": "completed",
                "records_synced": records_synced,
                "completed_at": datetime.utcnow().isoformat()
            }).eq("id", sync_id).execute()
            
            return {
                "message": f"Sync completed: {records_synced} records synced",
                "sync_id": sync_id,
                "records_synced": records_synced
            }
            
        except Exception as sync_error:
            supabase.table("sync_logs").update({
                "status": "failed",
                "error_message": str(sync_error),
                "completed_at": datetime.utcnow().isoformat()
            }).eq("id", sync_id).execute()
            raise
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Shopify sync error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/woocommerce/connect")
async def connect_woocommerce(
    request: WooCommerceConnectRequest,
    current_user: dict = Depends(get_current_user)
):
    """Connect a WooCommerce store"""
    try:
        supabase = get_supabase_admin()
        
        # Validate WooCommerce credentials
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{request.store_url}/wp-json/wc/v3/system_status",
                auth=(request.consumer_key, request.consumer_secret)
            )
        
        if response.status_code != 200:
            raise HTTPException(status_code=400, detail="Invalid WooCommerce credentials")
        
        # Update organization
        supabase.table("organizations").update({
            "platform": "woocommerce",
            "platform_store_url": request.store_url,
            "platform_api_key": request.consumer_key,
            "platform_api_secret": request.consumer_secret
        }).eq("id", request.org_id).execute()
        
        logger.info(f"WooCommerce store connected: {request.store_url}")
        
        return {
            "message": "WooCommerce store connected successfully",
            "store_url": request.store_url
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"WooCommerce connection error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/woocommerce/sync")
async def sync_woocommerce_data(
    org_id: str = Query(...),
    sync_type: str = Query("full"),
    current_user: dict = Depends(get_current_user)
):
    """Sync data from WooCommerce store"""
    try:
        supabase = get_supabase_admin()
        
        org = supabase.table("organizations").select("*").eq("id", org_id).single().execute()
        
        if not org.data or org.data.get("platform") != "woocommerce":
            raise HTTPException(status_code=400, detail="WooCommerce not connected")
        
        sync_log = supabase.table("sync_logs").insert({
            "org_id": org_id,
            "platform": "woocommerce",
            "sync_type": sync_type,
            "status": "running"
        }).execute()
        
        sync_id = sync_log.data[0]["id"]
        records_synced = 0
        
        try:
            store_url = org.data["platform_store_url"]
            auth = (org.data["platform_api_key"], org.data["platform_api_secret"])
            
            async with httpx.AsyncClient() as client:
                # Sync Products
                if sync_type in ("full", "products"):
                    resp = await client.get(
                        f"{store_url}/wp-json/wc/v3/products?per_page=100",
                        auth=auth
                    )
                    if resp.status_code == 200:
                        for product in resp.json():
                            supabase.table("products").upsert({
                                "org_id": org_id,
                                "sku_id": product.get("sku") or str(product["id"]),
                                "name": product["name"],
                                "price": float(product.get("price", 0) or 0),
                                "platform_product_id": str(product["id"]),
                                "is_active": product.get("status") == "publish"
                            }, on_conflict="org_id,sku_id").execute()
                            records_synced += 1
                
                # Sync Orders
                if sync_type in ("full", "orders"):
                    resp = await client.get(
                        f"{store_url}/wp-json/wc/v3/orders?per_page=100",
                        auth=auth
                    )
                    if resp.status_code == 200:
                        for order in resp.json():
                            supabase.table("orders").upsert({
                                "org_id": org_id,
                                "order_id": str(order["id"]),
                                "order_date": order["date_created"],
                                "total_amount": float(order.get("total", 0)),
                                "discount_amount": float(order.get("discount_total", 0)),
                                "status": _map_woo_status(order.get("status")),
                                "platform_order_id": str(order["id"])
                            }, on_conflict="org_id,order_id").execute()
                            records_synced += 1
                
                # Sync Customers
                if sync_type in ("full", "customers"):
                    resp = await client.get(
                        f"{store_url}/wp-json/wc/v3/customers?per_page=100&role=all",
                        auth=auth
                    )
                    if resp.status_code == 200:
                        for customer in resp.json():
                            supabase.table("customers").upsert({
                                "org_id": org_id,
                                "customer_id": str(customer["id"]),
                                "email": customer.get("email"),
                                "name": f"{customer.get('first_name', '')} {customer.get('last_name', '')}".strip() or customer.get('username'),
                                "total_orders": customer.get("orders_count", 0),
                                "total_spent": float(customer.get("total_spent", "0")),
                                "platform_customer_id": str(customer["id"])
                            }, on_conflict="org_id,customer_id").execute()
                            records_synced += 1
            
            supabase.table("sync_logs").update({
                "status": "completed",
                "records_synced": records_synced,
                "completed_at": datetime.utcnow().isoformat()
            }).eq("id", sync_id).execute()
            
            return {
                "message": f"Sync completed: {records_synced} records synced",
                "sync_id": sync_id,
                "records_synced": records_synced
            }
            
        except Exception as sync_error:
            supabase.table("sync_logs").update({
                "status": "failed",
                "error_message": str(sync_error),
                "completed_at": datetime.utcnow().isoformat()
            }).eq("id", sync_id).execute()
            raise
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"WooCommerce sync error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sync/status")
async def get_sync_status(
    org_id: str = Query(...),
    current_user: dict = Depends(get_current_user)
):
    """Get sync history and status"""
    try:
        supabase = get_supabase_admin()
        
        logs = supabase.table("sync_logs").select("*").eq(
            "org_id", org_id
        ).order("started_at", desc=True).limit(20).execute()
        
        return {"sync_logs": logs.data or []}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _map_shopify_status(status: str) -> str:
    """Map Shopify order status to internal status"""
    mapping = {
        "paid": "completed",
        "partially_paid": "processing",
        "pending": "pending",
        "voided": "cancelled",
        "refunded": "returned"
    }
    return mapping.get(status, "completed")


def _map_woo_status(status: str) -> str:
    """Map WooCommerce order status to internal status"""
    mapping = {
        "completed": "completed",
        "processing": "processing",
        "pending": "pending",
        "cancelled": "cancelled",
        "refunded": "returned",
        "on-hold": "pending"
    }
    return mapping.get(status, "completed")
