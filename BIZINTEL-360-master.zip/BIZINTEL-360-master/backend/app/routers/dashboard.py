"""
BizIntel 360 - Dashboard Analytics Router
"""
from fastapi import APIRouter, HTTPException, Depends, Query, Body
from typing import Optional
from datetime import datetime, timedelta
from loguru import logger

from app.database import get_supabase_admin
from app.models.schemas import DashboardResponse, DashboardKPIs
from app.middleware.auth import get_current_user

router = APIRouter()


@router.get("/overview")
async def get_dashboard_overview(
    org_id: str = Query(...),
    period: str = Query("30d", regex="^(7d|14d|30d|90d|1y|all)$"),
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive dashboard overview"""
    try:
        supabase = get_supabase_admin()
        
        # Calculate date range
        days_map = {"7d": 7, "14d": 14, "30d": 30, "90d": 90, "1y": 365}
        days = days_map.get(period)
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat() if days else None
        
        # Get KPIs
        kpis = await _get_kpis(supabase, org_id, start_date)
        
        # Get sales chart data
        sales_chart = await _get_sales_chart(supabase, org_id, start_date, days or 3650)
        
        # Get category breakdown
        category_breakdown = await _get_category_breakdown(supabase, org_id, start_date)
        
        # Get recent alerts
        alerts = supabase.table("stock_alerts").select(
            "*, products(name)"
        ).eq("org_id", org_id).eq(
            "is_resolved", False
        ).order("created_at", desc=True).limit(5).execute()
        
        # Get top churn risks
        churn_risks = supabase.table("churn_predictions").select(
            "*, customers(customer_id, name, email, total_spent)"
        ).eq("org_id", org_id).order(
            "churn_probability", desc=True
        ).limit(5).execute()
        
        # Get top products
        top_products = await _get_top_products(supabase, org_id, start_date)
        
        # Get regional breakdown
        regional_data = await _get_regional_breakdown(supabase, org_id, start_date)
        
        return {
            "kpis": kpis,
            "sales_chart": sales_chart,
            "category_breakdown": category_breakdown,
            "recent_alerts": alerts.data or [],
            "top_churn_risks": churn_risks.data or [],
            "top_products": top_products,
            "regional_data": regional_data,
            "period": period
        }
        
    except Exception as e:
        logger.error(f"Dashboard error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/kpis")
async def get_kpis(
    org_id: str = Query(...),
    period: str = Query("30d"),
    current_user: dict = Depends(get_current_user)
):
    """Get key performance indicators"""
    try:
        supabase = get_supabase_admin()
        days_map = {"7d": 7, "14d": 14, "30d": 30, "90d": 90, "1y": 365}
        days = days_map.get(period)
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat() if days else None
        
        kpis = await _get_kpis(supabase, org_id, start_date)
        return kpis
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sales-chart")
async def get_sales_chart(
    org_id: str = Query(...),
    period: str = Query("30d"),
    current_user: dict = Depends(get_current_user)
):
    """Get sales chart data"""
    try:
        supabase = get_supabase_admin()
        days_map = {"7d": 7, "14d": 14, "30d": 30, "90d": 90, "1y": 365}
        days = days_map.get(period)
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat() if days else None
        
        return await _get_sales_chart(supabase, org_id, start_date, days or 3650)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/org-settings")
async def get_org_settings(
    org_id: str = Query(...),
    current_user: dict = Depends(get_current_user)
):
    """Get organization settings including currency"""
    try:
        supabase = get_supabase_admin()
        org = supabase.table("organizations").select(
            "id, name, slug, platform, settings"
        ).eq("id", org_id).single().execute()
        
        if not org.data:
            return {
                "currency_symbol": "\u20b9",
                "currency_code": "INR",
                "country": "IN",
                "settings": {}
            }
        
        settings_data = org.data.get("settings") or {}
        currency_code = settings_data.get("currency", "INR")
        
        currency_symbols = {
            "INR": "\u20b9", "USD": "$", "EUR": "\u20ac", "GBP": "\u00a3",
            "JPY": "\u00a5", "AUD": "A$", "CAD": "C$", "SGD": "S$",
            "AED": "AED", "SAR": "SAR", "BRL": "R$", "CNY": "\u00a5",
            "KRW": "\u20a9", "THB": "\u0e3f", "MYR": "RM", "IDR": "Rp",
            "PHP": "\u20b1", "VND": "\u20ab", "ZAR": "R", "NGN": "\u20a6",
        }
        
        return {
            "org_id": org.data["id"],
            "org_name": org.data["name"],
            "platform": org.data.get("platform"),
            "currency_symbol": currency_symbols.get(currency_code, currency_code),
            "currency_code": currency_code,
            "country": settings_data.get("country", "IN"),
            "settings": settings_data
        }
        
    except Exception as e:
        return {
            "currency_symbol": "\u20b9",
            "currency_code": "INR",
            "country": "IN",
            "settings": {}
        }


@router.put("/org-settings")
async def update_org_settings(
    org_id: str = Query(...),
    body: dict = Body(...),
    current_user: dict = Depends(get_current_user),
):
    """Update organization settings (currency, etc.)"""
    try:
        supabase = get_supabase_admin()
        org = supabase.table("organizations").select("settings").eq("id", org_id).single().execute()
        existing = org.data.get("settings") or {} if org.data else {}

        if body:
            existing.update(body)

        supabase.table("organizations").update({"settings": existing}).eq("id", org_id).execute()

        currency_code = existing.get("currency", "INR")
        currency_symbols = {
            "INR": "\u20b9", "USD": "$", "EUR": "\u20ac", "GBP": "\u00a3",
            "JPY": "\u00a5", "AUD": "A$", "CAD": "C$", "SGD": "S$",
            "AED": "AED", "SAR": "SAR", "BRL": "R$", "CNY": "\u00a5",
            "KRW": "\u20a9", "THB": "\u0e3f", "MYR": "RM", "IDR": "Rp",
            "PHP": "\u20b1", "VND": "\u20ab", "ZAR": "R", "NGN": "\u20a6",
        }
        return {
            "success": True,
            "currency_code": currency_code,
            "currency_symbol": currency_symbols.get(currency_code, currency_code),
            "settings": existing,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/reports/summary")
async def get_report_summary(
    org_id: str = Query(...),
    period: str = Query("30d"),
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive report summary"""
    try:
        supabase = get_supabase_admin()
        days_map = {"7d": 7, "14d": 14, "30d": 30, "90d": 90, "1y": 365}
        days = days_map.get(period)
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat() if days else None
        
        kpis = await _get_kpis(supabase, org_id, start_date)
        categories = await _get_category_breakdown(supabase, org_id, start_date)
        top_products = await _get_top_products(supabase, org_id, start_date)
        
        # Inventory summary
        inventory = supabase.table("inventory").select("current_stock, reorder_threshold, safety_stock, max_stock").eq("org_id", org_id).execute()
        
        inv_summary = {"total_items": 0, "low_stock": 0, "overstock": 0, "out_of_stock": 0, "healthy": 0}
        for item in (inventory.data or []):
            inv_summary["total_items"] += 1
            stock = item["current_stock"]
            if stock <= 0:
                inv_summary["out_of_stock"] += 1
            elif stock <= item["safety_stock"]:
                inv_summary["low_stock"] += 1
            elif stock > item["max_stock"] * 0.9:
                inv_summary["overstock"] += 1
            else:
                inv_summary["healthy"] += 1
        
        return {
            "kpis": kpis,
            "category_breakdown": categories,
            "top_products": top_products,
            "inventory_summary": inv_summary,
            "period": period,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================
# Helper Functions
# ============================================

async def _get_kpis(supabase, org_id: str, start_date: str = None) -> dict:
    """Calculate KPIs"""
    # Orders — include completed + processing (WooCommerce standard)
    q = supabase.table("orders").select(
        "id, total_amount, customer_id"
    ).eq("org_id", org_id).in_("status", ["completed", "processing", "on-hold"])
    if start_date:
        q = q.gte("order_date", start_date)
    orders = q.execute()
    
    order_data = orders.data or []
    total_revenue = sum(float(o.get("total_amount", 0)) for o in order_data)
    total_orders = len(order_data)
    avg_order_value = total_revenue / total_orders if total_orders > 0 else 0
    unique_customers = len(set(o.get("customer_id") for o in order_data if o.get("customer_id")))
    
    # Total customers
    customers = supabase.table("customers").select("id", count="exact").eq("org_id", org_id).execute()
    total_customers = customers.count or 0
    
    # Churn stats
    churn = supabase.table("churn_predictions").select(
        "risk_level"
    ).eq("org_id", org_id).eq("risk_level", "high").execute()
    high_risk_count = len(churn.data) if churn.data else 0
    churn_rate = (high_risk_count / total_customers * 100) if total_customers > 0 else 0
    
    # Inventory alerts
    inventory = supabase.table("inventory").select(
        "current_stock, reorder_threshold, safety_stock, max_stock"
    ).eq("org_id", org_id).execute()
    
    low_stock = sum(1 for i in (inventory.data or []) if i["current_stock"] <= i["reorder_threshold"])
    overstock = sum(1 for i in (inventory.data or []) if i["current_stock"] > i["max_stock"] * 0.9)
    
    return {
        "total_revenue": round(total_revenue, 2),
        "total_orders": total_orders,
        "avg_order_value": round(avg_order_value, 2),
        "total_customers": total_customers,
        "active_customers": unique_customers,
        "churn_rate": round(churn_rate, 2),
        "low_stock_count": low_stock,
        "overstock_count": overstock,
        "high_risk_customers": high_risk_count
    }


async def _get_sales_chart(supabase, org_id: str, start_date: str, days: int) -> dict:
    """Get sales chart data grouped by date"""
    q = supabase.table("orders").select(
        "order_date, total_amount"
    ).eq("org_id", org_id).in_("status", ["completed", "processing", "on-hold"])
    if start_date:
        q = q.gte("order_date", start_date)
    orders = q.order("order_date").execute()
    
    # Group by date
    date_map = {}
    for order in (orders.data or []):
        date = order["order_date"][:10]
        if date not in date_map:
            date_map[date] = {"revenue": 0, "orders": 0}
        date_map[date]["revenue"] += float(order.get("total_amount", 0))
        date_map[date]["orders"] += 1
    
    sorted_dates = sorted(date_map.keys())
    
    return {
        "dates": sorted_dates,
        "revenue": [round(date_map[d]["revenue"], 2) for d in sorted_dates],
        "orders": [date_map[d]["orders"] for d in sorted_dates]
    }


async def _get_category_breakdown(supabase, org_id: str, start_date: str) -> list:
    """Get sales breakdown by category"""
    items = supabase.table("order_items").select(
        "total_price, quantity, products(category_id, categories(name)), orders!inner(org_id)"
    ).eq("orders.org_id", org_id).execute()
    
    category_map = {}
    total = 0
    
    for item in (items.data or []):
        cat_name = "Uncategorized"
        if item.get("products") and item["products"].get("categories"):
            cat_name = item["products"]["categories"].get("name", "Uncategorized")
        
        if cat_name not in category_map:
            category_map[cat_name] = {"revenue": 0, "quantity": 0}
        
        revenue = float(item.get("total_price", 0))
        category_map[cat_name]["revenue"] += revenue
        category_map[cat_name]["quantity"] += item.get("quantity", 0)
        total += revenue
    
    result = []
    for cat, data in category_map.items():
        result.append({
            "category": cat,
            "revenue": round(data["revenue"], 2),
            "quantity": data["quantity"],
            "percentage": round(data["revenue"] / total * 100, 2) if total > 0 else 0
        })
    
    return sorted(result, key=lambda x: x["revenue"], reverse=True)


async def _get_top_products(supabase, org_id: str, start_date: str) -> list:
    """Get top selling products"""
    items = supabase.table("order_items").select(
        "sku_id, quantity, total_price, products(name), orders!inner(org_id)"
    ).eq("orders.org_id", org_id).execute()
    
    product_map = {}
    for item in (items.data or []):
        sku = item["sku_id"]
        if sku not in product_map:
            product_map[sku] = {
                "sku_id": sku,
                "name": item.get("products", {}).get("name", sku) if item.get("products") else sku,
                "quantity": 0,
                "revenue": 0
            }
        product_map[sku]["quantity"] += item.get("quantity", 0)
        product_map[sku]["revenue"] += float(item.get("total_price", 0))
    
    sorted_products = sorted(product_map.values(), key=lambda x: x["revenue"], reverse=True)
    return sorted_products[:10]


async def _get_regional_breakdown(supabase, org_id: str, start_date: str = None) -> list:
    """Get sales by region"""
    q = supabase.table("orders").select(
        "region, total_amount"
    ).eq("org_id", org_id).in_("status", ["completed", "processing", "on-hold"])
    if start_date:
        q = q.gte("order_date", start_date)
    orders = q.execute()
    
    region_map = {}
    for order in (orders.data or []):
        region = order.get("region", "Unknown") or "Unknown"
        if region not in region_map:
            region_map[region] = {"revenue": 0, "orders": 0}
        region_map[region]["revenue"] += float(order.get("total_amount", 0))
        region_map[region]["orders"] += 1
    
    return [{"region": k, **v} for k, v in region_map.items()]
