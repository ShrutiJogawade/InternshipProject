"""
BizIntel 360 - Authentication Router
"""
from fastapi import APIRouter, HTTPException, status, Depends
from loguru import logger

from app.database import get_supabase, get_supabase_admin
from app.models.schemas import LoginRequest, RegisterRequest, AuthResponse
from app.middleware.auth import get_current_user

router = APIRouter()


@router.post("/register", response_model=AuthResponse)
async def register(request: RegisterRequest):
    """Register a new user"""
    try:
        supabase = get_supabase()
        
        # Create user in Supabase Auth
        auth_response = supabase.auth.sign_up({
            "email": request.email,
            "password": request.password,
            "options": {
                "data": {
                    "full_name": request.full_name,
                    "company_name": request.company_name or "",
                    "role": request.role.value
                }
            }
        })
        
        if not auth_response.user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Registration failed"
            )
        
        user = auth_response.user
        
        # Auto-confirm email using admin/service-role client
        admin = get_supabase_admin()
        try:
            admin.auth.admin.update_user_by_id(
                str(user.id),
                {"email_confirm": True}
            )
            logger.info(f"Auto-confirmed email for user: {request.email}")
        except Exception as confirm_err:
            logger.warning(f"Email auto-confirm failed (non-critical): {confirm_err}")
        
        # Ensure profile exists (trigger may not have fired yet) then update
        import time
        user_id_str = str(user.id)
        profile_exists = False
        for _ in range(5):
            check = admin.table("profiles").select("id").eq("id", user_id_str).execute()
            if check.data:
                profile_exists = True
                break
            time.sleep(0.3)
        
        if not profile_exists:
            # Manually create the profile since the trigger hasn't fired
            admin.table("profiles").insert({
                "id": user_id_str,
                "email": request.email,
                "full_name": request.full_name,
                "company_name": request.company_name,
                "role": request.role.value
            }).execute()
        else:
            admin.table("profiles").update({
                "full_name": request.full_name,
                "company_name": request.company_name,
                "role": request.role.value
            }).eq("id", user_id_str).execute()
        
        # Create or link organization
        if request.company_name:
            # Check if org with this name or slug already exists
            slug = request.company_name.lower().replace(" ", "-").replace(".", "")
            existing_org = admin.table("organizations").select("id").eq("slug", slug).execute()
            
            if existing_org.data:
                # Link to existing org
                try:
                    admin.table("org_members").insert({
                        "org_id": existing_org.data[0]["id"],
                        "user_id": str(user.id),
                        "role": "admin"
                    }).execute()
                except Exception:
                    pass  # Already linked
            else:
                org = admin.table("organizations").insert({
                    "name": request.company_name,
                    "slug": slug,
                    "owner_id": str(user.id),
                    "platform": "manual",
                    "settings": {"currency": "INR", "country": "IN"}
                }).execute()
                
                if org.data:
                    admin.table("org_members").insert({
                        "org_id": org.data[0]["id"],
                        "user_id": str(user.id),
                        "role": "owner"
                    }).execute()
        else:
            # No company name - link to first available org (demo org)
            try:
                default_org = admin.table("organizations").select("id").limit(1).execute()
                if default_org.data:
                    admin.table("org_members").insert({
                        "org_id": default_org.data[0]["id"],
                        "user_id": str(user.id),
                        "role": "admin"
                    }).execute()
            except Exception:
                pass
        
        logger.info(f"New user registered: {request.email}")
        
        # Sign in immediately to get a valid session token
        access_token = ""
        if auth_response.session and auth_response.session.access_token:
            access_token = auth_response.session.access_token
        else:
            try:
                supabase = get_supabase()
                login_resp = supabase.auth.sign_in_with_password({
                    "email": request.email,
                    "password": request.password
                })
                if login_resp.session:
                    access_token = login_resp.session.access_token
            except Exception as login_err:
                logger.warning(f"Auto-login after register failed: {login_err}")
        
        return AuthResponse(
            access_token=access_token,
            user={
                "id": str(user.id),
                "email": user.email,
                "full_name": request.full_name,
                "role": request.role.value
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Registration error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )


@router.post("/login", response_model=AuthResponse)
async def login(request: LoginRequest):
    """Login user"""
    try:
        supabase = get_supabase()
        
        auth_response = supabase.auth.sign_in_with_password({
            "email": request.email,
            "password": request.password
        })
        
        if not auth_response.user or not auth_response.session:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        user = auth_response.user
        
        # Get profile
        admin = get_supabase_admin()
        profile = admin.table("profiles").select("*").eq("id", str(user.id)).single().execute()
        
        # Get organization - auto-link to demo org if user has no membership
        org_member = admin.table("org_members").select("org_id, organizations(id, name, slug)").eq(
            "user_id", str(user.id)
        ).limit(1).execute()
        
        if not org_member.data:
            # Auto-link to first available org (demo org)
            try:
                default_org = admin.table("organizations").select("id").limit(1).execute()
                if default_org.data:
                    admin.table("org_members").insert({
                        "org_id": default_org.data[0]["id"],
                        "user_id": str(user.id),
                        "role": "admin"
                    }).execute()
                    org_member = admin.table("org_members").select("org_id, organizations(id, name, slug)").eq(
                        "user_id", str(user.id)
                    ).limit(1).execute()
                    logger.info(f"Auto-linked user {request.email} to default org")
            except Exception as link_err:
                logger.warning(f"Auto-link org failed: {link_err}")
        
        user_data = {
            "id": str(user.id),
            "email": user.email,
            "full_name": profile.data.get("full_name", "") if profile.data else "",
            "role": profile.data.get("role", "sales_manager") if profile.data else "sales_manager",
            "company_name": profile.data.get("company_name", "") if profile.data else "",
            "organization": org_member.data[0]["organizations"] if org_member.data else None
        }
        
        logger.info(f"User logged in: {request.email}")
        
        return AuthResponse(
            access_token=auth_response.session.access_token,
            user=user_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )


@router.post("/logout")
async def logout():
    """Logout user"""
    try:
        supabase = get_supabase()
        supabase.auth.sign_out()
        return {"message": "Logged out successfully"}
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        return {"message": "Logged out"}


@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    """Get current user profile"""
    try:
        admin = get_supabase_admin()
        user_id = current_user["id"]
        
        profile = admin.table("profiles").select("*").eq("id", user_id).single().execute()
        
        org_member = admin.table("org_members").select(
            "org_id, role, organizations(id, name, slug, platform, settings)"
        ).eq("user_id", user_id).execute()
        
        return {
            "id": user_id,
            "email": current_user["email"],
            "profile": profile.data,
            "organizations": [m["organizations"] for m in org_member.data] if org_member.data else []
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))
