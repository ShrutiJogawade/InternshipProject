"""
BizIntel 360 - Inventory & Stock Alerts Router
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional, List
from loguru import logger

from app.database import get_supabase_admin
from app.models.schemas import (
    InventoryUpdateRequest, StockAlertResponse,
    InventoryHealthResponse
)
from app.middleware.auth import get_current_user

router = APIRouter()


@router.get("/alerts")
async def get_stock_alerts(
    org_id: str = Query(...),
    alert_type: Optional[str] = Query(None),
    resolved: bool = Query(False),
    current_user: dict = Depends(get_current_user)
):
    """Get all stock alerts"""
    try:
        supabase = get_supabase_admin()
        
        query = supabase.table("stock_alerts").select(
            "*, products(name, price)"
        ).eq("org_id", org_id).eq("is_resolved", resolved)
        
        if alert_type:
            query = query.eq("alert_type", alert_type)
        
        alerts = query.order("created_at", desc=True).execute()
        
        if not alerts.data:
            # Generate alerts from inventory check
            generated_alerts = await _generate_stock_alerts(org_id)
            return {"alerts": generated_alerts, "total": len(generated_alerts)}
        
        return {"alerts": alerts.data, "total": len(alerts.data)}
        
    except Exception as e:
        logger.error(f"Error fetching alerts: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/update")
async def update_inventory(
    request: InventoryUpdateRequest,
    current_user: dict = Depends(get_current_user)
):
    """Update inventory stock level"""
    try:
        supabase = get_supabase_admin()
        
        # Get current inventory
        inventory = supabase.table("inventory").select("*").eq(
            "org_id", request.org_id
        ).eq("sku_id", request.sku_id).single().execute()
        
        if not inventory.data:
            raise HTTPException(status_code=404, detail=f"SKU {request.sku_id} not found")
        
        old_stock = inventory.data["current_stock"]
        
        # Update stock
        supabase.table("inventory").update({
            "current_stock": request.new_stock
        }).eq("id", inventory.data["id"]).execute()
        
        # Record history
        supabase.table("inventory_history").insert({
            "inventory_id": inventory.data["id"],
            "previous_stock": old_stock,
            "new_stock": request.new_stock,
            "change_type": request.change_type,
            "change_reason": request.change_reason,
            "changed_by": current_user["id"]
        }).execute()
        
        logger.info(f"Inventory updated: {request.sku_id} {old_stock} → {request.new_stock}")
        
        return {
            "message": "Inventory updated successfully",
            "sku_id": request.sku_id,
            "previous_stock": old_stock,
            "new_stock": request.new_stock
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Inventory update error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def get_inventory_health(
    org_id: str = Query(...),
    current_user: dict = Depends(get_current_user)
):
    """Get inventory health overview"""
    try:
        supabase = get_supabase_admin()
        
        inventory = supabase.table("inventory").select(
            "*, products(name, price, category_id, categories(name))"
        ).eq("org_id", org_id).execute()
        
        if not inventory.data:
            return {"items": [], "summary": {}}
        
        items = []
        summary = {
            "total_skus": 0,
            "healthy": 0,
            "low_stock": 0,
            "critical": 0,
            "out_of_stock": 0,
            "overstock": 0,
            "total_value": 0
        }
        
        for item in inventory.data:
            stock = item["current_stock"]
            threshold = item["reorder_threshold"]
            safety = item["safety_stock"]
            max_stock = item["max_stock"]
            
            if stock <= 0:
                status = "out_of_stock"
                summary["out_of_stock"] += 1
            elif stock <= safety:
                status = "critical"
                summary["critical"] += 1
            elif stock <= threshold:
                status = "low_stock"
                summary["low_stock"] += 1
            elif stock > max_stock * 0.9:
                status = "overstock"
                summary["overstock"] += 1
            else:
                status = "healthy"
                summary["healthy"] += 1
            
            summary["total_skus"] += 1
            
            product = item.get("products", {})
            price = product.get("price", 0) if product else 0
            summary["total_value"] += stock * float(price) if price else 0
            
            items.append({
                "sku_id": item["sku_id"],
                "product_name": product.get("name", "") if product else "",
                "category_name": product.get("categories", {}).get("name", "") if product and product.get("categories") else "",
                "current_stock": stock,
                "reorder_threshold": threshold,
                "safety_stock": safety,
                "max_stock": max_stock,
                "stock_status": status,
                "stock_value": stock * float(price) if price else 0
            })
        
        return {"items": items, "summary": summary}
        
    except Exception as e:
        logger.error(f"Error fetching inventory health: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history/{sku_id}")
async def get_inventory_history(
    sku_id: str,
    org_id: str = Query(...),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user)
):
    """Get inventory change history for a SKU"""
    try:
        supabase = get_supabase_admin()
        
        inventory = supabase.table("inventory").select("id").eq(
            "org_id", org_id
        ).eq("sku_id", sku_id).single().execute()
        
        if not inventory.data:
            raise HTTPException(status_code=404, detail="SKU not found")
        
        history = supabase.table("inventory_history").select(
            "*, profiles(full_name)"
        ).eq(
            "inventory_id", inventory.data["id"]
        ).order("created_at", desc=True).limit(limit).execute()
        
        return {"sku_id": sku_id, "history": history.data or []}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


async def _generate_stock_alerts(org_id: str) -> list:
    """Generate stock alerts by comparing inventory vs forecasts"""
    supabase = get_supabase_admin()
    
    inventory = supabase.table("inventory").select(
        "*, products(name, price)"
    ).eq("org_id", org_id).execute()
    
    alerts = []
    
    for item in (inventory.data or []):
        stock = item["current_stock"]
        threshold = item["reorder_threshold"]
        safety = item["safety_stock"]
        max_stock = item["max_stock"]
        product_name = item.get("products", {}).get("name", item["sku_id"]) if item.get("products") else item["sku_id"]
        
        alert = None
        
        if stock <= 0:
            alert = {
                "sku_id": item["sku_id"],
                "product_name": product_name,
                "alert_type": "out_of_stock",
                "severity": "critical",
                "current_stock": stock,
                "suggested_reorder_qty": threshold * 3,
                "message": f"🚨 {product_name} is OUT OF STOCK! Immediate reorder needed."
            }
        elif stock <= safety:
            alert = {
                "sku_id": item["sku_id"],
                "product_name": product_name,
                "alert_type": "low_stock",
                "severity": "high",
                "current_stock": stock,
                "suggested_reorder_qty": threshold * 2,
                "message": f"⚠️ {product_name} stock critically low ({stock} units). Below safety threshold."
            }
        elif stock <= threshold:
            alert = {
                "sku_id": item["sku_id"],
                "product_name": product_name,
                "alert_type": "low_stock",
                "severity": "medium",
                "current_stock": stock,
                "suggested_reorder_qty": threshold,
                "message": f"📦 {product_name} approaching reorder point ({stock}/{threshold} units)."
            }
        elif stock > max_stock * 0.9:
            alert = {
                "sku_id": item["sku_id"],
                "product_name": product_name,
                "alert_type": "overstock",
                "severity": "low",
                "current_stock": stock,
                "suggested_reorder_qty": 0,
                "message": f"📈 {product_name} is overstocked ({stock}/{max_stock} units). Consider promotions."
            }
        
        if alert:
            # Store alert
            supabase.table("stock_alerts").insert({
                "org_id": org_id,
                "product_id": item["product_id"],
                "sku_id": item["sku_id"],
                "alert_type": alert["alert_type"],
                "severity": alert["severity"],
                "current_stock": stock,
                "suggested_reorder_qty": alert["suggested_reorder_qty"],
                "message": alert["message"]
            }).execute()
            
            alerts.append(alert)
    
    return alerts
