"""
BizIntel 360 - PDF Report Generation Router
Generates downloadable PDF reports with date range, category, and product filters.
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from fastapi.responses import StreamingResponse
from typing import Optional, List
from datetime import datetime, timedelta
from loguru import logger
import io

from app.database import get_supabase_admin
from app.middleware.auth import get_current_user

router = APIRouter()

CURRENCY_SYMBOLS = {
    "INR": "\u20b9", "USD": "$", "EUR": "\u20ac", "GBP": "\u00a3",
    "JPY": "\u00a5", "AUD": "A$", "CAD": "C$", "SGD": "S$",
    "AED": "AED", "SAR": "SAR", "BRL": "R$", "CNY": "\u00a5",
    "KRW": "\u20a9", "THB": "\u0e3f", "MYR": "RM", "IDR": "Rp",
    "PHP": "\u20b1", "VND": "\u20ab", "ZAR": "R", "NGN": "\u20a6",
}


def _get_currency(supabase, org_id: str) -> tuple:
    """Return (currency_code, currency_symbol) for an org"""
    try:
        org = supabase.table("organizations").select("settings").eq("id", org_id).single().execute()
        settings = org.data.get("settings") or {} if org.data else {}
        code = settings.get("currency", "INR")
        return code, CURRENCY_SYMBOLS.get(code, code)
    except Exception:
        return "INR", "\u20b9"


def _build_pdf(title: str, sections: list, currency_symbol: str = "\u20b9") -> bytes:
    """Build a PDF report using reportlab.
    sections = [{"heading": str, "table_headers": [...], "table_rows": [[...], ...]}, ...]
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import inch, mm
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=30, bottomMargin=30,
                            leftMargin=40, rightMargin=40)
    styles = getSampleStyleSheet()
    elements = []

    # Title
    title_style = ParagraphStyle("ReportTitle", parent=styles["Title"], fontSize=20,
                                  textColor=colors.HexColor("#1a1a2e"), spaceAfter=6)
    elements.append(Paragraph(title, title_style))
    elements.append(Paragraph(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
                              styles["Normal"]))
    elements.append(Spacer(1, 16))

    # Pre-define reusable styles
    cell_header_style = ParagraphStyle("CellH", parent=styles["Normal"],
                                        fontSize=10, textColor=colors.white,
                                        fontName="Helvetica-Bold", leading=12)
    cell_body_style = ParagraphStyle("CellB", parent=styles["Normal"],
                                      fontSize=9, leading=11, wordWrap='CJK')
    heading_style = ParagraphStyle("SH", parent=styles["Heading2"], fontSize=14,
                                    textColor=colors.HexColor("#4361ee"), spaceAfter=8)

    for section in sections:
        # Section heading
        elements.append(Paragraph(section["heading"], heading_style))

        if section.get("summary"):
            elements.append(Paragraph(section["summary"], styles["Normal"]))
            elements.append(Spacer(1, 8))

        headers = section.get("table_headers", [])
        rows = section.get("table_rows", [])
        if headers and rows:
            col_count = len(headers)
            col_widths = [doc.width / col_count] * col_count

            # Wrap cell text in Paragraphs so long text wraps to next line
            wrapped_headers = [Paragraph(str(h), cell_header_style) for h in headers]
            wrapped_rows = [
                [Paragraph(str(cell), cell_body_style) for cell in row]
                for row in rows[:200]
            ]
            data = [wrapped_headers] + wrapped_rows

            table = Table(data, colWidths=col_widths, repeatRows=1)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4361ee")),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#ddd")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8f9fa")]),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ]))
            elements.append(table)

        elements.append(Spacer(1, 20))

    doc.build(elements)
    buf.seek(0)
    return buf.getvalue()


# ============================================
# REPORT ENDPOINTS
# ============================================

@router.get("/sales")
async def generate_sales_report(
    org_id: str = Query(...),
    start_date: Optional[str] = Query(None, description="YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="YYYY-MM-DD"),
    category: Optional[str] = Query(None),
    product: Optional[str] = Query(None),
    format: str = Query("pdf", regex="^(pdf|json)$"),
    current_user: dict = Depends(get_current_user),
):
    """Generate sales report with optional filters"""
    try:
        supabase = get_supabase_admin()
        currency_code, currency_sym = _get_currency(supabase, org_id)

        # Default date range: last 30 days
        if not end_date:
            end_date = datetime.utcnow().strftime("%Y-%m-%d")
        if not start_date:
            start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")

        # --- Orders ---
        q = supabase.table("orders").select(
            "order_id, order_date, total_amount, status, discount_amount, tax_amount, "
            "customers(name, email)"
        ).eq("org_id", org_id).in_(
            "status", ["completed", "processing", "on-hold"]
        ).gte("order_date", f"{start_date}T00:00:00").lte("order_date", f"{end_date}T23:59:59"
        ).order("order_date", desc=True)
        orders = q.execute()
        order_data = orders.data or []

        total_revenue = sum(float(o.get("total_amount", 0)) for o in order_data)
        total_orders = len(order_data)
        avg_order = total_revenue / total_orders if total_orders else 0

        # --- Order items with product/category info ---
        items_q = supabase.table("order_items").select(
            "sku_id, quantity, total_price, unit_price, "
            "products(name, category_id, categories(name)), "
            "orders!inner(org_id, order_date, status)"
        ).eq("orders.org_id", org_id).in_(
            "orders.status", ["completed", "processing", "on-hold"]
        ).gte("orders.order_date", f"{start_date}T00:00:00"
        ).lte("orders.order_date", f"{end_date}T23:59:59")
        items = items_q.execute()

        # Build product summary
        product_map = {}
        category_map = {}
        for item in (items.data or []):
            prod_name = "Unknown"
            cat_name = "Uncategorized"
            if item.get("products"):
                prod_name = item["products"].get("name", item["sku_id"])
                if item["products"].get("categories"):
                    cat_name = item["products"]["categories"].get("name", "Uncategorized")

            # Apply filters
            if category and cat_name.lower() != category.lower():
                continue
            if product and prod_name.lower() != product.lower():
                continue

            qty = item.get("quantity", 0)
            rev = float(item.get("total_price", 0))

            product_map.setdefault(prod_name, {"qty": 0, "revenue": 0, "category": cat_name})
            product_map[prod_name]["qty"] += qty
            product_map[prod_name]["revenue"] += rev

            category_map.setdefault(cat_name, {"qty": 0, "revenue": 0})
            category_map[cat_name]["qty"] += qty
            category_map[cat_name]["revenue"] += rev

        # Sort by revenue desc
        sorted_products = sorted(product_map.items(), key=lambda x: x[1]["revenue"], reverse=True)
        sorted_categories = sorted(category_map.items(), key=lambda x: x[1]["revenue"], reverse=True)

        if format == "json":
            return {
                "period": {"start": start_date, "end": end_date},
                "summary": {
                    "total_revenue": round(total_revenue, 2),
                    "total_orders": total_orders,
                    "avg_order_value": round(avg_order, 2),
                    "currency": currency_code,
                },
                "products": [{"name": k, **v} for k, v in sorted_products],
                "categories": [{"name": k, **v} for k, v in sorted_categories],
                "orders": [{
                    "order_id": o["order_id"],
                    "date": o["order_date"][:10],
                    "amount": float(o["total_amount"]),
                    "status": o["status"],
                    "customer": o.get("customers", {}).get("name", "Guest") if o.get("customers") else "Guest",
                } for o in order_data[:100]],
            }

        # Build PDF
        sections = []

        # Summary section
        sections.append({
            "heading": "Sales Summary",
            "summary": f"Period: {start_date} to {end_date}",
            "table_headers": ["Metric", "Value"],
            "table_rows": [
                ["Total Revenue", f"{currency_sym}{total_revenue:,.2f}"],
                ["Total Orders", str(total_orders)],
                ["Average Order Value", f"{currency_sym}{avg_order:,.2f}"],
                ["Currency", currency_code],
            ],
        })

        # Category breakdown
        if sorted_categories:
            cat_total = sum(v["revenue"] for _, v in sorted_categories)
            sections.append({
                "heading": "Category Breakdown",
                "table_headers": ["Category", "Revenue", "Qty Sold", "Share %"],
                "table_rows": [
                    [k, f"{currency_sym}{v['revenue']:,.2f}", str(v["qty"]),
                     f"{v['revenue']/cat_total*100:.1f}%" if cat_total else "0%"]
                    for k, v in sorted_categories
                ],
            })

        # Top products
        if sorted_products:
            sections.append({
                "heading": "Product Performance",
                "table_headers": ["Product", "Category", "Revenue", "Qty Sold"],
                "table_rows": [
                    [k, v["category"], f"{currency_sym}{v['revenue']:,.2f}", str(v["qty"])]
                    for k, v in sorted_products[:30]
                ],
            })

        # Order details
        if order_data:
            sections.append({
                "heading": "Order Details",
                "table_headers": ["Order #", "Date", "Customer", "Amount", "Status"],
                "table_rows": [
                    [o["order_id"], o["order_date"][:10],
                     (o.get("customers", {}) or {}).get("name", "Guest"),
                     f"{currency_sym}{float(o['total_amount']):,.2f}", o["status"]]
                    for o in order_data[:100]
                ],
            })

        filter_label = ""
        if category:
            filter_label += f" | Category: {category}"
        if product:
            filter_label += f" | Product: {product}"

        pdf_bytes = _build_pdf(f"Sales Report{filter_label}", sections, currency_sym)

        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=sales_report_{start_date}_{end_date}.pdf"}
        )

    except Exception as e:
        logger.error(f"Sales report error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/inventory")
async def generate_inventory_report(
    org_id: str = Query(...),
    format: str = Query("pdf", regex="^(pdf|json)$"),
    current_user: dict = Depends(get_current_user),
):
    """Generate inventory health report"""
    try:
        supabase = get_supabase_admin()
        _, currency_sym = _get_currency(supabase, org_id)

        inv = supabase.table("inventory").select(
            "sku_id, current_stock, reorder_threshold, safety_stock, max_stock, "
            "products(name, price, categories(name))"
        ).eq("org_id", org_id).execute()

        items = []
        summary = {"total": 0, "low_stock": 0, "overstock": 0, "out_of_stock": 0, "healthy": 0}

        for row in (inv.data or []):
            stock = row["current_stock"]
            prod = row.get("products") or {}
            name = prod.get("name", row["sku_id"])
            cat = prod.get("categories", {}).get("name", "-") if prod.get("categories") else "-"
            price = float(prod.get("price", 0))

            summary["total"] += 1
            if stock <= 0:
                status = "Out of Stock"
                summary["out_of_stock"] += 1
            elif stock <= row["safety_stock"]:
                status = "Critical Low"
                summary["low_stock"] += 1
            elif stock <= row["reorder_threshold"]:
                status = "Low Stock"
                summary["low_stock"] += 1
            elif stock > row["max_stock"] * 0.9:
                status = "Overstock"
                summary["overstock"] += 1
            else:
                status = "Healthy"
                summary["healthy"] += 1

            items.append({
                "name": name, "sku": row["sku_id"], "category": cat,
                "stock": stock, "reorder_at": row["reorder_threshold"],
                "price": price, "status": status,
                "value": round(stock * price, 2),
            })

        items.sort(key=lambda x: x["stock"])

        if format == "json":
            return {"summary": summary, "items": items}

        sections = [
            {
                "heading": "Inventory Summary",
                "table_headers": ["Metric", "Count"],
                "table_rows": [
                    ["Total SKUs", str(summary["total"])],
                    ["Healthy", str(summary["healthy"])],
                    ["Low Stock", str(summary["low_stock"])],
                    ["Overstock", str(summary["overstock"])],
                    ["Out of Stock", str(summary["out_of_stock"])],
                ],
            },
            {
                "heading": "Inventory Details",
                "table_headers": ["Product", "Category", "Stock", "Reorder At", "Status", "Value"],
                "table_rows": [
                    [i["name"], i["category"], str(i["stock"]),
                     str(i["reorder_at"]), i["status"],
                     f"{currency_sym}{i['value']:,.0f}"]
                    for i in items
                ],
            },
        ]

        pdf_bytes = _build_pdf("Inventory Report", sections, currency_sym)
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=inventory_report.pdf"}
        )

    except Exception as e:
        logger.error(f"Inventory report error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/customers")
async def generate_customer_report(
    org_id: str = Query(...),
    format: str = Query("pdf", regex="^(pdf|json)$"),
    current_user: dict = Depends(get_current_user),
):
    """Generate customer churn report"""
    try:
        supabase = get_supabase_admin()
        _, currency_sym = _get_currency(supabase, org_id)

        custs = supabase.table("customers").select(
            "customer_id, name, email, total_orders, total_spent, "
            "last_order_date, first_order_date"
        ).eq("org_id", org_id).order("total_spent", desc=True).execute()

        churn = supabase.table("churn_predictions").select(
            "customer_id, churn_probability, risk_level, recency_days, frequency, monetary_value, "
            "customers(name, email)"
        ).eq("org_id", org_id).order("churn_probability", desc=True).execute()

        cust_data = custs.data or []
        churn_data = churn.data or []

        high = sum(1 for c in churn_data if c.get("risk_level") == "high")
        med = sum(1 for c in churn_data if c.get("risk_level") == "medium")
        low = sum(1 for c in churn_data if c.get("risk_level") == "low")

        if format == "json":
            return {
                "total_customers": len(cust_data),
                "churn_summary": {"high": high, "medium": med, "low": low},
                "customers": cust_data[:50],
                "churn_risks": churn_data[:50],
            }

        sections = [
            {
                "heading": "Customer Overview",
                "table_headers": ["Metric", "Value"],
                "table_rows": [
                    ["Total Customers", str(len(cust_data))],
                    ["High Risk", str(high)],
                    ["Medium Risk", str(med)],
                    ["Low Risk", str(low)],
                ],
            },
            {
                "heading": "Top Customers by Revenue",
                "table_headers": ["Name", "Email", "Orders", "Total Spent", "Last Order"],
                "table_rows": [
                    [c["name"] or "-", c["email"] or "-", str(c["total_orders"]),
                     f"{currency_sym}{float(c['total_spent']):,.0f}",
                     (c.get("last_order_date") or "-")[:10]]
                    for c in cust_data[:30]
                ],
            },
            {
                "heading": "Churn Risk Analysis",
                "table_headers": ["Customer", "Risk", "Churn %", "Recency (days)", "Orders", "Spent"],
                "table_rows": [
                    [(c.get("customers", {}) or {}).get("name", "-"),
                     c["risk_level"].upper(),
                     f"{c['churn_probability']*100:.0f}%",
                     str(c.get("recency_days", "-")),
                     str(c.get("frequency", "-")),
                     f"{currency_sym}{float(c.get('monetary_value', 0)):,.0f}"]
                    for c in churn_data[:30]
                ],
            },
        ]

        pdf_bytes = _build_pdf("Customer & Churn Report", sections, currency_sym)
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=customer_report.pdf"}
        )

    except Exception as e:
        logger.error(f"Customer report error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/forecast")
async def generate_forecast_report(
    org_id: str = Query(...),
    format: str = Query("pdf", regex="^(pdf|json)$"),
    current_user: dict = Depends(get_current_user),
):
    """Generate forecast report"""
    try:
        supabase = get_supabase_admin()
        _, currency_sym = _get_currency(supabase, org_id)

        forecasts = supabase.table("forecasts").select(
            "reference_id, reference_name, forecast_date, predicted_quantity, "
            "lower_bound, upper_bound, confidence, model_used"
        ).eq("org_id", org_id).order("forecast_date").limit(500).execute()

        data = forecasts.data or []

        # Group by product
        product_map = {}
        for f in data:
            name = f.get("reference_name") or f.get("reference_id", "Unknown")
            product_map.setdefault(name, []).append(f)

        if format == "json":
            return {
                "total_predictions": len(data),
                "products": list(product_map.keys()),
                "forecasts": data[:100],
            }

        sections = [
            {
                "heading": "Forecast Summary",
                "table_headers": ["Metric", "Value"],
                "table_rows": [
                    ["Total Predictions", str(len(data))],
                    ["Products Forecasted", str(len(product_map))],
                    ["Model", "Hybrid (Prophet + XGBoost)"],
                ],
            },
        ]

        for name, preds in list(product_map.items())[:15]:
            sections.append({
                "heading": f"Forecast: {name}",
                "table_headers": ["Date", "Predicted Qty", "Lower", "Upper", "Confidence"],
                "table_rows": [
                    [p["forecast_date"][:10],
                     f"{float(p.get('predicted_quantity', 0)):.1f}",
                     f"{float(p.get('lower_bound', 0)):.1f}",
                     f"{float(p.get('upper_bound', 0)):.1f}",
                     f"{float(p.get('confidence', 0))*100:.0f}%"]
                    for p in preds[:20]
                ],
            })

        pdf_bytes = _build_pdf("Forecast Report", sections, currency_sym)
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=forecast_report.pdf"}
        )

    except Exception as e:
        logger.error(f"Forecast report error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
