-- ============================================
-- BizIntel 360 - Seed Data for Demo
-- Fashion Retail Sample Data
-- ============================================

-- Insert demo organization
INSERT INTO public.organizations (id, name, slug, platform, settings) VALUES
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'FashionForward Inc.', 'fashionforward', 'manual', 
 '{"currency": "INR", "country": "IN", "industry": "fashion"}');

-- Insert demo categories
INSERT INTO public.categories (id, org_id, name, slug) VALUES
('c1000000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'T-Shirts', 't-shirts'),
('c1000000-0000-0000-0000-000000000002', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Jeans', 'jeans'),
('c1000000-0000-0000-0000-000000000003', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Jackets', 'jackets'),
('c1000000-0000-0000-0000-000000000004', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Dresses', 'dresses'),
('c1000000-0000-0000-0000-000000000005', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Sneakers', 'sneakers'),
('c1000000-0000-0000-0000-000000000006', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Accessories', 'accessories');

-- Insert demo products
INSERT INTO public.products (id, org_id, sku_id, name, category_id, price, cost_price, is_active) VALUES
('p1000000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'TSH-001', 'Classic White Tee', 'c1000000-0000-0000-0000-000000000001', 799.00, 350.00, true),
('p1000000-0000-0000-0000-000000000002', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'TSH-002', 'Black V-Neck', 'c1000000-0000-0000-0000-000000000001', 899.00, 400.00, true),
('p1000000-0000-0000-0000-000000000003', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'TSH-003', 'Striped Polo', 'c1000000-0000-0000-0000-000000000001', 1299.00, 550.00, true),
('p1000000-0000-0000-0000-000000000004', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'JNS-001', 'Slim Fit Blue Jeans', 'c1000000-0000-0000-0000-000000000002', 2499.00, 1100.00, true),
('p1000000-0000-0000-0000-000000000005', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'JNS-002', 'Relaxed Black Denim', 'c1000000-0000-0000-0000-000000000002', 2799.00, 1200.00, true),
('p1000000-0000-0000-0000-000000000006', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'JKT-001', 'Leather Biker Jacket', 'c1000000-0000-0000-0000-000000000003', 5999.00, 2800.00, true),
('p1000000-0000-0000-0000-000000000007', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'JKT-002', 'Denim Trucker Jacket', 'c1000000-0000-0000-0000-000000000003', 3499.00, 1500.00, true),
('p1000000-0000-0000-0000-000000000008', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'DRS-001', 'Floral Summer Dress', 'c1000000-0000-0000-0000-000000000004', 1999.00, 850.00, true),
('p1000000-0000-0000-0000-000000000009', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'DRS-002', 'Little Black Dress', 'c1000000-0000-0000-0000-000000000004', 2999.00, 1300.00, true),
('p1000000-0000-0000-0000-000000000010', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'SNK-001', 'Urban Runner Sneaker', 'c1000000-0000-0000-0000-000000000005', 3999.00, 1800.00, true),
('p1000000-0000-0000-0000-000000000011', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'SNK-002', 'Canvas Classic', 'c1000000-0000-0000-0000-000000000005', 1999.00, 900.00, true),
('p1000000-0000-0000-0000-000000000012', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'ACC-001', 'Leather Belt', 'c1000000-0000-0000-0000-000000000006', 999.00, 400.00, true),
('p1000000-0000-0000-0000-000000000013', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'ACC-002', 'Aviator Sunglasses', 'c1000000-0000-0000-0000-000000000006', 1499.00, 600.00, true),
('p1000000-0000-0000-0000-000000000014', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'TSH-004', 'Graphic Print Tee', 'c1000000-0000-0000-0000-000000000001', 999.00, 420.00, true),
('p1000000-0000-0000-0000-000000000015', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'JNS-003', 'Cargo Jogger Pants', 'c1000000-0000-0000-0000-000000000002', 1999.00, 850.00, true);

-- Insert demo customers
INSERT INTO public.customers (id, org_id, customer_id, email, name, region, total_orders, total_spent, average_order_value, first_order_date, last_order_date, returns_count, discount_orders_count) VALUES
('cu100000-0000-0000-0000-000000000001', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-001', 'rahul@example.com', 'Rahul Sharma', 'North', 45, 125000.00, 2777.78, '2024-01-15', '2026-02-20', 2, 12),
('cu100000-0000-0000-0000-000000000002', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-002', 'priya@example.com', 'Priya Patel', 'West', 38, 98000.00, 2578.95, '2024-02-10', '2026-02-18', 1, 8),
('cu100000-0000-0000-0000-000000000003', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-003', 'amit@example.com', 'Amit Kumar', 'South', 12, 35000.00, 2916.67, '2024-06-20', '2025-11-05', 3, 5),
('cu100000-0000-0000-0000-000000000004', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-004', 'sneha@example.com', 'Sneha Reddy', 'South', 52, 185000.00, 3557.69, '2023-11-01', '2026-02-22', 0, 15),
('cu100000-0000-0000-0000-000000000005', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-005', 'vikas@example.com', 'Vikas Gupta', 'North', 5, 12000.00, 2400.00, '2025-06-10', '2025-08-15', 1, 3),
('cu100000-0000-0000-0000-000000000006', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-006', 'anita@example.com', 'Anita Desai', 'West', 28, 72000.00, 2571.43, '2024-04-01', '2026-01-30', 2, 7),
('cu100000-0000-0000-0000-000000000007', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-007', 'raj@example.com', 'Raj Malhotra', 'East', 3, 8500.00, 2833.33, '2025-09-20', '2025-10-05', 0, 1),
('cu100000-0000-0000-0000-000000000008', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-008', 'meera@example.com', 'Meera Iyer', 'South', 41, 145000.00, 3536.59, '2024-01-05', '2026-02-21', 1, 10),
('cu100000-0000-0000-0000-000000000009', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-009', 'arjun@example.com', 'Arjun Singh', 'North', 8, 22000.00, 2750.00, '2025-03-15', '2025-12-20', 2, 4),
('cu100000-0000-0000-0000-000000000010', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'CUST-010', 'divya@example.com', 'Divya Nair', 'South', 67, 250000.00, 3731.34, '2023-08-10', '2026-02-24', 3, 20);

-- Insert inventory for all products
INSERT INTO public.inventory (org_id, product_id, sku_id, current_stock, reorder_threshold, safety_stock, max_stock) VALUES
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000001', 'TSH-001', 150, 30, 15, 500),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000002', 'TSH-002', 8, 25, 10, 400),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000003', 'TSH-003', 45, 20, 10, 300),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000004', 'JNS-001', 3, 15, 8, 250),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000005', 'JNS-002', 75, 20, 10, 300),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000006', 'JKT-001', 22, 10, 5, 150),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000007', 'JKT-002', 480, 15, 8, 200),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000008', 'DRS-001', 0, 20, 10, 350),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000009', 'DRS-002', 55, 15, 8, 250),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000010', 'SNK-001', 12, 10, 5, 200),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000011', 'SNK-002', 90, 20, 10, 300),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000012', 'ACC-001', 200, 30, 15, 500),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000013', 'ACC-002', 35, 15, 8, 250),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000014', 'TSH-004', 5, 25, 12, 400),
('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'p1000000-0000-0000-0000-000000000015', 'JNS-003', 110, 20, 10, 300);

-- Note: The demo user (demo@bizintel.com) is linked to this org 
-- via the backend /auth/register endpoint which auto-creates the profile + org_member record.
-- If manually linking, run:
-- INSERT INTO public.org_members (org_id, user_id, role) 
-- VALUES ('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', '<user-uuid-from-auth>', 'admin')
-- ON CONFLICT (org_id, user_id) DO NOTHING;
