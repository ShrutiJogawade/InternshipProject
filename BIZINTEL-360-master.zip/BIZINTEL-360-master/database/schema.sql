-- ============================================
-- BizIntel 360 - Database Schema
-- Supabase PostgreSQL Migration
-- ============================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- 1. USERS & AUTHENTICATION
-- ============================================

-- User profiles (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    company_name TEXT,
    role TEXT NOT NULL DEFAULT 'sales_manager' CHECK (role IN ('admin', 'developer', 'sales_manager', 'inventory_manager')),
    avatar_url TEXT,
    phone TEXT,
    timezone TEXT DEFAULT 'UTC',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 2. ORGANIZATIONS / STORES
-- ============================================

CREATE TABLE IF NOT EXISTS public.organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    owner_id UUID REFERENCES public.profiles(id),
    platform TEXT CHECK (platform IN ('shopify', 'woocommerce', 'custom', 'manual')),
    platform_store_url TEXT,
    platform_api_key TEXT,
    platform_api_secret TEXT,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Organization members
CREATE TABLE IF NOT EXISTS public.org_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, user_id)
);

-- ============================================
-- 3. PRODUCTS & CATEGORIES
-- ============================================

CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    parent_id UUID REFERENCES public.categories(id),
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, slug)
);

CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    sku_id TEXT NOT NULL,
    name TEXT NOT NULL,
    category_id UUID REFERENCES public.categories(id),
    description TEXT,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0,
    cost_price DECIMAL(10, 2),
    image_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    tags TEXT[],
    metadata JSONB DEFAULT '{}',
    platform_product_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, sku_id)
);

-- ============================================
-- 4. CUSTOMERS
-- ============================================

CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    customer_id TEXT NOT NULL,
    email TEXT,
    name TEXT,
    phone TEXT,
    region TEXT,
    city TEXT,
    country TEXT DEFAULT 'IN',
    total_orders INTEGER DEFAULT 0,
    total_spent DECIMAL(12, 2) DEFAULT 0,
    average_order_value DECIMAL(10, 2) DEFAULT 0,
    first_order_date DATE,
    last_order_date DATE,
    returns_count INTEGER DEFAULT 0,
    discount_orders_count INTEGER DEFAULT 0,
    tags TEXT[],
    platform_customer_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, customer_id)
);

-- ============================================
-- 5. ORDERS & SALES
-- ============================================

CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    order_id TEXT NOT NULL,
    customer_id UUID REFERENCES public.customers(id),
    order_date TIMESTAMPTZ NOT NULL,
    status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'processing', 'completed', 'cancelled', 'returned')),
    total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    shipping_amount DECIMAL(10, 2) DEFAULT 0,
    region TEXT,
    channel TEXT DEFAULT 'online',
    has_discount BOOLEAN DEFAULT FALSE,
    has_promotion BOOLEAN DEFAULT FALSE,
    is_festival_period BOOLEAN DEFAULT FALSE,
    platform_order_id TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, order_id)
);

CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id),
    sku_id TEXT NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 6. INVENTORY
-- ============================================

CREATE TABLE IF NOT EXISTS public.inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    sku_id TEXT NOT NULL,
    current_stock INTEGER NOT NULL DEFAULT 0,
    reorder_threshold INTEGER DEFAULT 10,
    safety_stock INTEGER DEFAULT 5,
    max_stock INTEGER DEFAULT 1000,
    warehouse_location TEXT,
    last_restocked_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, sku_id)
);

-- Inventory history for tracking changes
CREATE TABLE IF NOT EXISTS public.inventory_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    inventory_id UUID NOT NULL REFERENCES public.inventory(id) ON DELETE CASCADE,
    previous_stock INTEGER,
    new_stock INTEGER,
    change_type TEXT CHECK (change_type IN ('sale', 'restock', 'return', 'adjustment', 'sync')),
    change_reason TEXT,
    changed_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 7. FORECASTS
-- ============================================

CREATE TABLE IF NOT EXISTS public.forecasts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    forecast_type TEXT NOT NULL CHECK (forecast_type IN ('sku', 'category', 'store')),
    reference_id TEXT NOT NULL, -- sku_id, category slug, or store id
    reference_name TEXT,
    forecast_date DATE NOT NULL,
    predicted_quantity DECIMAL(10, 2) NOT NULL,
    lower_bound DECIMAL(10, 2),
    upper_bound DECIMAL(10, 2),
    confidence DECIMAL(5, 4),
    model_used TEXT DEFAULT 'hybrid',
    horizon_days INTEGER DEFAULT 30,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_forecasts_org_type ON public.forecasts(org_id, forecast_type);
CREATE INDEX idx_forecasts_ref ON public.forecasts(org_id, reference_id, forecast_date);

-- Forecast accuracy tracking
CREATE TABLE IF NOT EXISTS public.forecast_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    model_name TEXT NOT NULL,
    forecast_type TEXT NOT NULL,
    rmse DECIMAL(10, 4),
    mape DECIMAL(10, 4),
    mae DECIMAL(10, 4),
    r_squared DECIMAL(10, 6),
    training_date TIMESTAMPTZ DEFAULT NOW(),
    data_points INTEGER,
    metadata JSONB DEFAULT '{}'
);

-- ============================================
-- 8. CHURN PREDICTIONS
-- ============================================

CREATE TABLE IF NOT EXISTS public.churn_predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    churn_probability DECIMAL(5, 4) NOT NULL,
    risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
    top_drivers JSONB DEFAULT '[]',
    recency_days INTEGER,
    frequency INTEGER,
    monetary_value DECIMAL(12, 2),
    predicted_at TIMESTAMPTZ DEFAULT NOW(),
    model_version TEXT DEFAULT 'v1'
);

CREATE INDEX idx_churn_org_risk ON public.churn_predictions(org_id, risk_level);
CREATE INDEX idx_churn_probability ON public.churn_predictions(org_id, churn_probability DESC);

-- Churn model metrics
CREATE TABLE IF NOT EXISTS public.churn_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    accuracy DECIMAL(5, 4),
    f1_score DECIMAL(5, 4),
    roc_auc DECIMAL(5, 4),
    precision_score DECIMAL(5, 4),
    recall_score DECIMAL(5, 4),
    training_date TIMESTAMPTZ DEFAULT NOW(),
    data_points INTEGER,
    model_version TEXT DEFAULT 'v1'
);

-- ============================================
-- 9. STOCK ALERTS
-- ============================================

CREATE TABLE IF NOT EXISTS public.stock_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id),
    sku_id TEXT NOT NULL,
    alert_type TEXT NOT NULL CHECK (alert_type IN ('low_stock', 'overstock', 'out_of_stock')),
    severity TEXT DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    current_stock INTEGER,
    forecasted_demand INTEGER,
    suggested_reorder_qty INTEGER,
    message TEXT,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMPTZ,
    resolved_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_alerts_org_unresolved ON public.stock_alerts(org_id, is_resolved) WHERE NOT is_resolved;

-- ============================================
-- 10. CHAT HISTORY
-- ============================================

CREATE TABLE IF NOT EXISTS public.chat_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id),
    title TEXT DEFAULT 'New Chat',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.chat_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 11. DATA SYNC LOGS
-- ============================================

CREATE TABLE IF NOT EXISTS public.sync_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    platform TEXT NOT NULL,
    sync_type TEXT NOT NULL CHECK (sync_type IN ('orders', 'customers', 'products', 'inventory', 'full')),
    status TEXT DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed')),
    records_synced INTEGER DEFAULT 0,
    error_message TEXT,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- ============================================
-- 12. NOTIFICATION SETTINGS
-- ============================================

CREATE TABLE IF NOT EXISTS public.notification_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    email_alerts BOOLEAN DEFAULT TRUE,
    push_alerts BOOLEAN DEFAULT TRUE,
    low_stock_alerts BOOLEAN DEFAULT TRUE,
    churn_alerts BOOLEAN DEFAULT TRUE,
    forecast_alerts BOOLEAN DEFAULT TRUE,
    daily_digest BOOLEAN DEFAULT FALSE,
    weekly_report BOOLEAN DEFAULT TRUE,
    UNIQUE(user_id, org_id)
);

-- ============================================
-- 13. AUDIT LOG
-- ============================================

CREATE TABLE IF NOT EXISTS public.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    org_id UUID REFERENCES public.organizations(id),
    user_id UUID REFERENCES public.profiles(id),
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- FUNCTIONS & TRIGGERS
-- ============================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers
CREATE TRIGGER update_profiles_timestamp BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_organizations_timestamp BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_products_timestamp BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_customers_timestamp BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_inventory_timestamp BEFORE UPDATE ON public.inventory FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email)
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forecasts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.churn_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- Profile policies
CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Organization policies
CREATE POLICY "Org members can view org" ON public.organizations FOR SELECT 
    USING (id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));
CREATE POLICY "Owners can update org" ON public.organizations FOR UPDATE 
    USING (owner_id = auth.uid());

-- Data policies (org-scoped)
CREATE POLICY "Org members can view products" ON public.products FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));
CREATE POLICY "Org members can manage products" ON public.products FOR ALL 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view customers" ON public.customers FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view orders" ON public.orders FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view inventory" ON public.inventory FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view forecasts" ON public.forecasts FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view churn" ON public.churn_predictions FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Org members can view alerts" ON public.stock_alerts FOR SELECT 
    USING (org_id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid()));

CREATE POLICY "Users can view own chat sessions" ON public.chat_sessions FOR SELECT 
    USING (user_id = auth.uid());
CREATE POLICY "Users can create chat sessions" ON public.chat_sessions FOR INSERT 
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view own chat messages" ON public.chat_messages FOR SELECT 
    USING (session_id IN (SELECT id FROM public.chat_sessions WHERE user_id = auth.uid()));
CREATE POLICY "Users can create chat messages" ON public.chat_messages FOR INSERT 
    WITH CHECK (session_id IN (SELECT id FROM public.chat_sessions WHERE user_id = auth.uid()));

-- ============================================
-- SEED DATA VIEWS (for dashboard)
-- ============================================

-- Sales overview view
CREATE OR REPLACE VIEW public.v_sales_overview AS
SELECT 
    o.org_id,
    DATE_TRUNC('day', o.order_date) as sale_date,
    COUNT(DISTINCT o.id) as total_orders,
    SUM(o.total_amount) as total_revenue,
    AVG(o.total_amount) as avg_order_value,
    COUNT(DISTINCT o.customer_id) as unique_customers
FROM public.orders o
WHERE o.status = 'completed'
GROUP BY o.org_id, DATE_TRUNC('day', o.order_date);

-- Inventory health view
CREATE OR REPLACE VIEW public.v_inventory_health AS
SELECT 
    i.org_id,
    i.sku_id,
    p.name as product_name,
    c.name as category_name,
    i.current_stock,
    i.reorder_threshold,
    i.safety_stock,
    CASE 
        WHEN i.current_stock <= 0 THEN 'out_of_stock'
        WHEN i.current_stock <= i.safety_stock THEN 'critical'
        WHEN i.current_stock <= i.reorder_threshold THEN 'low'
        WHEN i.current_stock > i.max_stock * 0.9 THEN 'overstock'
        ELSE 'healthy'
    END as stock_status
FROM public.inventory i
JOIN public.products p ON i.product_id = p.id
LEFT JOIN public.categories c ON p.category_id = c.id;

-- Customer RFM view
CREATE OR REPLACE VIEW public.v_customer_rfm AS
SELECT 
    c.id,
    c.org_id,
    c.customer_id,
    c.name,
    c.email,
    c.total_orders as frequency,
    c.total_spent as monetary,
    EXTRACT(DAY FROM NOW() - c.last_order_date::timestamp) as recency_days,
    c.average_order_value,
    c.returns_count
FROM public.customers c;
