import 'package:flutter_test/flutter_test.dart';
import 'package:bizintel360/main.dart';

void main() {
  testWidgets('BizIntel360 app smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const BizIntel360App());
    await tester.pumpAndSettle();
    expect(find.textContaining('BizIntel'), findsWidgets);
  });
}
