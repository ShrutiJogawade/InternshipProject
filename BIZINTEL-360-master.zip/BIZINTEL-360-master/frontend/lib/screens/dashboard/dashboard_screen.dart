import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/dashboard_provider.dart';
import '../../widgets/kpi_card.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/alert_tile.dart';
import '../../widgets/shimmer_loading.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.watch<AuthProvider>();
    if (auth.orgId.isNotEmpty && !_initialized) {
      _initialized = true;
      final dash = context.read<DashboardProvider>();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        dash.loadDashboard(auth.orgId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final dash = context.watch<DashboardProvider>();
    final auth = context.watch<AuthProvider>();
    final currencyFormat = NumberFormat.currency(
        locale: 'en_IN', symbol: auth.currencySymbol, decimalDigits: 0);
    final isWide = MediaQuery.of(context).size.width > 900;

    if (dash.isLoading && dash.totalOrders == 0) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: const DashboardSkeleton(),
      );
    }

    if (dash.error != null && dash.totalOrders == 0) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.cloud_off_rounded,
                  size: 64, color: AppColors.textMuted),
              const SizedBox(height: 16),
              Text('Failed to load dashboard',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              Text(dash.error!,
                  style: TextStyle(fontSize: 13, color: AppColors.textMuted),
                  textAlign: TextAlign.center),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () => dash.loadDashboard(auth.orgId),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: RefreshIndicator(
        onRefresh: () => dash.loadDashboard(auth.orgId),
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics()),
          slivers: [
            // Header
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final isMobile = constraints.maxWidth < 400;
                        final hPad = isMobile ? 6.0 : 10.0;
                        final fontSize = isMobile ? 11.0 : 12.0;
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Dashboard title
                            Text(
                              'Dashboard',
                              style: TextStyle(
                                fontSize: isMobile ? 20 : 28,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            // Period Selector
                            Container(
                              padding: EdgeInsets.all(isMobile ? 2 : 3),
                              decoration: BoxDecoration(
                                color: AppColors.surfaceLight,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: AppColors.primary.withOpacity(0.15)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  '7d',
                                  '14d',
                                  '30d',
                                  '90d',
                                  '1y',
                                  'all'
                                ].map((p) {
                                  final isActive = dash.selectedPeriod == p;
                                  return GestureDetector(
                                    onTap: () {
                                      dash.setPeriod(p);
                                      dash.loadDashboard(auth.orgId, period: p);
                                    },
                                    child: AnimatedContainer(
                                      duration:
                                          const Duration(milliseconds: 200),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: hPad, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: isActive
                                            ? AppColors.primary
                                            : Colors.transparent,
                                        borderRadius: BorderRadius.circular(7),
                                      ),
                                      child: Text(
                                        p == 'all'
                                            ? 'All'
                                            : p == '1y'
                                                ? '1Y'
                                                : p,
                                        style: TextStyle(
                                          fontSize: fontSize,
                                          fontWeight: isActive
                                              ? FontWeight.w600
                                              : FontWeight.w400,
                                          color: isActive
                                              ? Colors.white
                                              : AppColors.textMuted,
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 400.ms),
            ),

            // KPI Cards
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final crossCount = constraints.maxWidth > 1100 ? 4 : 2;
                    final gap = constraints.maxWidth < 600 ? 10.0 : 16.0;
                    return Wrap(
                      spacing: gap,
                      runSpacing: gap,
                      children: [
                        _buildKpiCard(
                            'Total Revenue',
                            currencyFormat.format(dash.totalRevenue),
                            Icons.account_balance_wallet_rounded,
                            AppColors.primaryGradient,
                            '${dash.totalOrders} orders',
                            constraints.maxWidth,
                            crossCount,
                            gap),
                        _buildKpiCard(
                            'Active Customers',
                            '${dash.activeCustomers}',
                            Icons.people_rounded,
                            AppColors.successGradient,
                            'of ${dash.totalCustomers} total',
                            constraints.maxWidth,
                            crossCount,
                            gap),
                        _buildKpiCard(
                            'Avg Order Value',
                            currencyFormat.format(dash.avgOrderValue),
                            Icons.trending_up_rounded,
                            const LinearGradient(
                                colors: [Color(0xFF448AFF), Color(0xFF2979FF)]),
                            '${dash.selectedPeriod} period',
                            constraints.maxWidth,
                            crossCount,
                            gap),
                        _buildKpiCard(
                            'Churn Rate',
                            '${dash.churnRate.toStringAsFixed(1)}%',
                            Icons.warning_amber_rounded,
                            AppColors.warningGradient,
                            '${dash.highRiskCustomers} at risk',
                            constraints.maxWidth,
                            crossCount,
                            gap),
                      ]
                          .asMap()
                          .entries
                          .map((e) => e.value
                              .animate()
                              .fadeIn(
                                  delay: Duration(milliseconds: 100 * e.key),
                                  duration: 500.ms)
                              .slideX(begin: 0.1))
                          .toList(),
                    );
                  },
                ),
              ),
            ),

            // Charts Row
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
                child: isWide
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                              flex: 3,
                              child: _buildSalesChart(dash, currencyFormat)),
                          const SizedBox(width: 16),
                          Expanded(flex: 2, child: _buildCategoryPie(dash)),
                        ],
                      )
                    : Column(
                        children: [
                          _buildSalesChart(dash, currencyFormat),
                          const SizedBox(height: 16),
                          _buildCategoryPie(dash),
                        ],
                      ),
              ).animate().fadeIn(delay: 400.ms, duration: 500.ms),
            ),

            // Alerts & Churn Row
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
                child: isWide
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: _buildAlertPanel(dash)),
                          const SizedBox(width: 16),
                          Expanded(
                              child: _buildChurnPanel(dash, currencyFormat)),
                        ],
                      )
                    : Column(
                        children: [
                          _buildAlertPanel(dash),
                          const SizedBox(height: 16),
                          _buildChurnPanel(dash, currencyFormat),
                        ],
                      ),
              ).animate().fadeIn(delay: 600.ms, duration: 500.ms),
            ),

            // Top Products
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
                child: _buildTopProducts(dash, currencyFormat),
              ).animate().fadeIn(delay: 800.ms, duration: 500.ms),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKpiCard(
      String title,
      String value,
      IconData icon,
      LinearGradient gradient,
      String subtitle,
      double maxWidth,
      int crossCount,
      double gap) {
    final width = (maxWidth - (gap * (crossCount - 1))) / crossCount;
    return SizedBox(
      width: width,
      child: KpiCard(
        title: title,
        value: value,
        icon: icon,
        gradient: gradient,
        subtitle: subtitle,
      ),
    );
  }

  Widget _buildSalesChart(DashboardProvider dash, NumberFormat fmt) {
    final dates = dash.salesChartDates;
    final revenue = dash.salesChartRevenue;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Revenue Trend',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary),
              ),
              const Spacer(),
              if (dash.isLoading)
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primary,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 260,
            child: revenue.isEmpty
                ? const Center(
                    child: Text('No data available',
                        style: TextStyle(color: AppColors.textMuted)))
                : LineChart(
                    LineChartData(
                      gridData: FlGridData(
                        show: true,
                        drawVerticalLine: false,
                        horizontalInterval: _getMaxVal(revenue) / 4,
                        getDrawingHorizontalLine: (value) => FlLine(
                          color: AppColors.primary.withOpacity(0.06),
                          strokeWidth: 1,
                        ),
                      ),
                      titlesData: FlTitlesData(
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 50,
                            getTitlesWidget: (value, meta) {
                              if (value == meta.max || value == meta.min)
                                return const SizedBox();
                              return Text(
                                '${(value / 1000).toStringAsFixed(0)}k',
                                style: TextStyle(
                                    fontSize: 10, color: AppColors.textMuted),
                              );
                            },
                          ),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 30,
                            interval: (dates.length / 5).ceilToDouble(),
                            getTitlesWidget: (value, meta) {
                              final idx = value.toInt();
                              if (idx >= 0 && idx < dates.length) {
                                return Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text(
                                    dates[idx].toString().substring(5),
                                    style: TextStyle(
                                        fontSize: 10,
                                        color: AppColors.textMuted),
                                  ),
                                );
                              }
                              return const SizedBox();
                            },
                          ),
                        ),
                        topTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                      ),
                      borderData: FlBorderData(show: false),
                      lineBarsData: [
                        LineChartBarData(
                          spots: List.generate(
                            revenue.length,
                            (i) => FlSpot(
                                i.toDouble(), (revenue[i] as num).toDouble()),
                          ),
                          isCurved: true,
                          curveSmoothness: 0.3,
                          gradient: AppColors.primaryGradient,
                          barWidth: 3,
                          isStrokeCapRound: true,
                          dotData: FlDotData(show: false),
                          belowBarData: BarAreaData(
                            show: true,
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                AppColors.primary.withOpacity(0.2),
                                AppColors.primary.withOpacity(0.0),
                              ],
                            ),
                          ),
                        ),
                      ],
                      lineTouchData: LineTouchData(
                        touchTooltipData: LineTouchTooltipData(
                          getTooltipItems: (spots) => spots
                              .map(
                                (s) => LineTooltipItem(
                                  fmt.format(s.y),
                                  const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryPie(DashboardProvider dash) {
    final categories = dash.categoryBreakdown;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Category Breakdown',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: categories.isEmpty
                ? const Center(
                    child: Text('No data',
                        style: TextStyle(color: AppColors.textMuted)))
                : PieChart(
                    PieChartData(
                      sections: List.generate(categories.length, (i) {
                        final cat = categories[i];
                        return PieChartSectionData(
                          value: (cat['percentage'] as num).toDouble(),
                          color: AppColors
                              .chartColors[i % AppColors.chartColors.length],
                          radius: 45,
                          title:
                              '${(cat['percentage'] as num).toStringAsFixed(0)}%',
                          titleStyle: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: Colors.white),
                        );
                      }),
                      centerSpaceRadius: 40,
                      sectionsSpace: 3,
                    ),
                  ),
          ),
          const SizedBox(height: 16),
          ...List.generate(categories.length.clamp(0, 6), (i) {
            final cat = categories[i];
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: AppColors
                          .chartColors[i % AppColors.chartColors.length],
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(cat['category'] ?? '',
                        style: TextStyle(
                            fontSize: 13, color: AppColors.textSecondary)),
                  ),
                  Text('${(cat['percentage'] as num).toStringAsFixed(1)}%',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary)),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildAlertPanel(DashboardProvider dash) {
    final alerts = dash.recentAlerts;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.notification_important_rounded,
                  color: AppColors.warning, size: 22),
              const SizedBox(width: 8),
              const Text('Stock Alerts',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.error.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('${alerts.length}',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.error)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (alerts.isEmpty)
            const Center(
                child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('✅ No active alerts',
                        style: TextStyle(color: AppColors.textMuted))))
          else
            ...alerts.take(5).map((alert) => AlertTile(alert: alert)),
        ],
      ),
    );
  }

  Widget _buildChurnPanel(DashboardProvider dash, NumberFormat fmt) {
    final risks = dash.topChurnRisks;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.person_off_rounded, color: AppColors.error, size: 22),
              const SizedBox(width: 8),
              const Text('Churn Risk',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.warning.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('${risks.length} at risk',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.warning)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (risks.isEmpty)
            const Center(
                child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('No churn data',
                        style: TextStyle(color: AppColors.textMuted))))
          else
            ...risks.take(5).map((risk) {
              final customer = risk['customers'] ?? {};
              final prob = (risk['churn_probability'] as num?)?.toDouble() ?? 0;
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.surfaceLight,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: prob >= 0.6
                        ? AppColors.error.withOpacity(0.3)
                        : prob >= 0.3
                            ? AppColors.warning.withOpacity(0.3)
                            : AppColors.success.withOpacity(0.3),
                  ),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 18,
                      backgroundColor: prob >= 0.6
                          ? AppColors.error.withOpacity(0.2)
                          : AppColors.warning.withOpacity(0.2),
                      child: Text(
                        (customer['name'] ?? 'U')[0].toUpperCase(),
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color:
                              prob >= 0.6 ? AppColors.error : AppColors.warning,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(customer['name'] ?? 'Unknown',
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary)),
                          Text(
                              fmt.format((customer['total_spent'] as num?)
                                      ?.toDouble() ??
                                  0),
                              style: TextStyle(
                                  fontSize: 12, color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: prob >= 0.6
                            ? AppColors.error.withOpacity(0.15)
                            : prob >= 0.3
                                ? AppColors.warning.withOpacity(0.15)
                                : AppColors.success.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${(prob * 100).toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: prob >= 0.6
                              ? AppColors.error
                              : prob >= 0.3
                                  ? AppColors.warning
                                  : AppColors.success,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _buildTopProducts(DashboardProvider dash, NumberFormat fmt) {
    final products = dash.topProducts;

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.star_rounded, color: AppColors.accent, size: 22),
              const SizedBox(width: 8),
              const Text('Top Products',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
            ],
          ),
          const SizedBox(height: 16),
          if (products.isEmpty)
            const Center(
                child: Text('No product data',
                    style: TextStyle(color: AppColors.textMuted)))
          else
            ...products.asMap().entries.map((e) {
              final p = e.value;
              final maxRev = (products[0]['revenue'] as num).toDouble();
              final rev = (p['revenue'] as num).toDouble();
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surfaceLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: AppColors
                            .chartColors[e.key % AppColors.chartColors.length]
                            .withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                          child: Text('#${e.key + 1}',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.chartColors[
                                      e.key % AppColors.chartColors.length]))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p['name'] ?? '',
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary)),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: maxRev > 0 ? rev / maxRev : 0,
                              backgroundColor: AppColors.surfaceLight,
                              valueColor: AlwaysStoppedAnimation(
                                  AppColors.chartColors[
                                      e.key % AppColors.chartColors.length]),
                              minHeight: 4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(fmt.format(rev),
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary)),
                        Text('${p['quantity']} sold',
                            style: TextStyle(
                                fontSize: 11, color: AppColors.textMuted)),
                      ],
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  double _getMaxVal(List<dynamic> list) {
    if (list.isEmpty) return 100;
    double max = 0;
    for (var v in list) {
      final d = (v as num).toDouble();
      if (d > max) max = d;
    }
    return max > 0 ? max : 100;
  }
}
