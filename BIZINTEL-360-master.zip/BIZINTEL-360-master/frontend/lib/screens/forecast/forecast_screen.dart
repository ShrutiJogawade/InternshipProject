import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/forecast_provider.dart';
import '../../widgets/glass_card.dart';

class ForecastScreen extends StatefulWidget {
  const ForecastScreen({super.key});

  @override
  State<ForecastScreen> createState() => _ForecastScreenState();
}

class _ForecastScreenState extends State<ForecastScreen> {
  String _selectedSku = 'All';

  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.watch<AuthProvider>();
    if (auth.orgId.isNotEmpty && !_initialized) {
      _initialized = true;
      final forecast = context.read<ForecastProvider>();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        forecast.runForecast(auth.orgId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final forecast = context.watch<ForecastProvider>();
    final auth = context.watch<AuthProvider>();
    final isWide = MediaQuery.of(context).size.width > 900;

    // Get unique product names (fallback to sku_id)
    final allProducts = <String>{'All'};
    for (var p in forecast.predictions) {
      final name = p['product_name'] ?? p['sku_id'];
      if (name != null) allProducts.add(name);
    }

    // Filter predictions by product name
    final filtered = _selectedSku == 'All'
        ? forecast.predictions
        : forecast.predictions
            .where((p) => (p['product_name'] ?? p['sku_id']) == _selectedSku)
            .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Sales Forecast',
                                style: TextStyle(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.textPrimary)),
                            const SizedBox(height: 2),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                        ),
                        onPressed: forecast.isLoading
                            ? null
                            : () => forecast.runForecast(auth.orgId),
                        icon: forecast.isLoading
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.play_arrow_rounded, size: 18),
                        label: Text(forecast.isLoading ? 'Running...' : 'Run',
                            style: const TextStyle(fontSize: 13)),
                      ),
                    ],
                  ).animate().fadeIn(duration: 400.ms),

                  const SizedBox(height: 20),

                  // Controls
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      // Horizon selector
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: AppColors.primary.withOpacity(0.15)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [7, 14, 30, 90, 365, 9999].map((d) {
                            final isActive = forecast.horizonDays == d;
                            return GestureDetector(
                              onTap: () {
                                forecast.setHorizonDays(d);
                                forecast.runForecast(auth.orgId);
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                                decoration: BoxDecoration(
                                  color: isActive
                                      ? AppColors.primary
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                    d == 9999
                                        ? 'All'
                                        : d == 365
                                            ? '1Y'
                                            : '${d}d',
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: isActive
                                            ? FontWeight.w600
                                            : FontWeight.w400,
                                        color: isActive
                                            ? Colors.white
                                            : AppColors.textMuted)),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                      // Product selector
                      ConstrainedBox(
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width - 48,
                        ),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceLight,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: AppColors.primary.withOpacity(0.15)),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: allProducts.contains(_selectedSku)
                                  ? _selectedSku
                                  : 'All',
                              dropdownColor: AppColors.card,
                              isExpanded: true,
                              style: const TextStyle(
                                  color: AppColors.textPrimary, fontSize: 14),
                              items: allProducts
                                  .map((s) => DropdownMenuItem(
                                      value: s,
                                      child: Text(s,
                                          overflow: TextOverflow.ellipsis)))
                                  .toList(),
                              onChanged: (v) =>
                                  setState(() => _selectedSku = v ?? 'All'),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ).animate().fadeIn(delay: 200.ms, duration: 400.ms),
                ],
              ),
            ),
          ),

          // Metrics
          if (forecast.forecastResult?['metrics'] != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                child: Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    _metricChip(
                        'RMSE',
                        '${forecast.forecastResult!['metrics']['rmse']}',
                        AppColors.primary),
                    _metricChip(
                        'MAPE',
                        '${(forecast.forecastResult!['metrics']['mape'] * 100).toStringAsFixed(1)}%',
                        AppColors.accent),
                    _metricChip('Model', 'Hybrid', AppColors.success),
                    _metricChip(
                        'Predictions', '${filtered.length}', AppColors.info),
                  ],
                ).animate().fadeIn(delay: 300.ms),
              ),
            ),

          // Chart
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _selectedSku == 'All'
                          ? 'All Products Forecast'
                          : '$_selectedSku Forecast',
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 300,
                      child: filtered.isEmpty
                          ? const Center(
                              child: Text('Run forecast to see predictions',
                                  style: TextStyle(color: AppColors.textMuted)))
                          : _buildForecastChart(filtered),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 400.ms),
            ),
          ),

          // Predictions Table
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Prediction Details',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 16),
                    if (filtered.isEmpty)
                      const Center(
                          child: Text('No predictions available',
                              style: TextStyle(color: AppColors.textMuted)))
                    else
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          headingRowColor:
                              WidgetStateProperty.all(AppColors.surfaceLight),
                          columns: const [
                            DataColumn(
                                label: Text('Date',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600))),
                            DataColumn(
                                label: Text('Product',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600))),
                            DataColumn(
                                label: Text('Predicted Qty',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                            DataColumn(
                                label: Text('Lower',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                            DataColumn(
                                label: Text('Upper',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                            DataColumn(
                                label: Text('Confidence',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                          ],
                          rows: filtered
                              .take(20)
                              .map((p) => DataRow(cells: [
                                    DataCell(Text(p['forecast_date'] ?? '',
                                        style: const TextStyle(fontSize: 13))),
                                    DataCell(Text(
                                        p['product_name'] ?? p['sku_id'] ?? '-',
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500))),
                                    DataCell(Text(
                                        '${_parseNum(p['predicted_quantity']).toStringAsFixed(1)}',
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.accent))),
                                    DataCell(Text(
                                        '${_parseNum(p['lower_bound']).toStringAsFixed(1)}',
                                        style: TextStyle(
                                            fontSize: 13,
                                            color: AppColors.textMuted))),
                                    DataCell(Text(
                                        '${_parseNum(p['upper_bound']).toStringAsFixed(1)}',
                                        style: TextStyle(
                                            fontSize: 13,
                                            color: AppColors.textMuted))),
                                    DataCell(Text(
                                        '${(_parseNum(p['confidence']) * 100).toStringAsFixed(0)}%',
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500))),
                                  ]))
                              .toList(),
                        ),
                      ),
                  ],
                ),
              ).animate().fadeIn(delay: 500.ms),
            ),
          ),
        ],
      ),
    );
  }

  Widget _metricChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 12, color: color, fontWeight: FontWeight.w500)),
          const SizedBox(width: 6),
          Text(value,
              style: TextStyle(
                  fontSize: 14, color: color, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _buildForecastChart(List<dynamic> predictions) {
    // Group by product name for multi-line chart
    final skuGroups = <String, List<Map<String, dynamic>>>{};
    for (var p in predictions) {
      final name = p['product_name'] ?? p['sku_id'] ?? 'Total';
      skuGroups.putIfAbsent(name, () => []);
      skuGroups[name]!.add(Map<String, dynamic>.from(p));
    }

    final lines = <LineChartBarData>[];
    int colorIdx = 0;
    for (var entry in skuGroups.entries.take(6)) {
      final data = entry.value;
      data.sort((a, b) =>
          (a['forecast_date'] ?? '').compareTo(b['forecast_date'] ?? ''));

      lines.add(LineChartBarData(
        spots: List.generate(
            data.length,
            (i) =>
                FlSpot(i.toDouble(), _parseNum(data[i]['predicted_quantity']))),
        isCurved: true,
        curveSmoothness: 0.25,
        color: AppColors.chartColors[colorIdx % AppColors.chartColors.length],
        barWidth: 2.5,
        isStrokeCapRound: true,
        dotData: FlDotData(show: false),
        belowBarData: BarAreaData(
          show: skuGroups.length == 1,
          color: AppColors.chartColors[colorIdx % AppColors.chartColors.length]
              .withOpacity(0.1),
        ),
      ));
      colorIdx++;
    }

    final firstGroup = skuGroups.values.first;

    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (v) => FlLine(
              color: AppColors.primary.withOpacity(0.05), strokeWidth: 1),
        ),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (v, m) {
                if (v == m.max || v == m.min) return const SizedBox();
                return Text(v.toStringAsFixed(0),
                    style: TextStyle(fontSize: 10, color: AppColors.textMuted));
              },
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              interval: (firstGroup.length / 6).ceilToDouble(),
              getTitlesWidget: (v, m) {
                final idx = v.toInt();
                if (idx >= 0 && idx < firstGroup.length) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                        firstGroup[idx]['forecast_date']?.substring(5) ?? '',
                        style: TextStyle(
                            fontSize: 10, color: AppColors.textMuted)),
                  );
                }
                return const SizedBox();
              },
            ),
          ),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        lineBarsData: lines,
      ),
    );
  }

  double _parseNum(dynamic val) {
    if (val == null) return 0;
    if (val is num) return val.toDouble();
    return double.tryParse(val.toString()) ?? 0;
  }
}
