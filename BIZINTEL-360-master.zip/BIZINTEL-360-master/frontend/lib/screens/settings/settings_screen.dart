import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../widgets/glass_card.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _currencies = {
    'INR': '\u20b9 Indian Rupee',
    'USD': '\$ US Dollar',
    'EUR': '\u20ac Euro',
    'GBP': '\u00a3 British Pound',
    'JPY': '\u00a5 Japanese Yen',
    'AUD': 'A\$ Australian Dollar',
    'CAD': 'C\$ Canadian Dollar',
    'SGD': 'S\$ Singapore Dollar',
    'AED': 'AED Dirham',
    'SAR': 'SAR Riyal',
    'BRL': 'R\$ Brazilian Real',
    'CNY': '\u00a5 Chinese Yuan',
    'MYR': 'RM Malaysian Ringgit',
    'THB': '\u0e3f Thai Baht',
    'ZAR': 'R South African Rand',
    'NGN': '\u20a6 Nigerian Naira',
  };

  bool _savingCurrency = false;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isWoo =
        (auth.organization?['platform'] ?? '').toString().toLowerCase() ==
            'woocommerce';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Settings',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary)),
            const SizedBox(height: 24),

            // Profile Card
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Profile',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 32,
                        backgroundColor: AppColors.primary,
                        child: Text(
                          auth.userName.isNotEmpty
                              ? auth.userName[0].toUpperCase()
                              : 'U',
                          style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              color: Colors.white),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(auth.userName,
                                style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary)),
                            Text(auth.user?.email ?? '',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: AppColors.textSecondary)),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 3),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                  auth.userRole
                                      .replaceAll('_', ' ')
                                      .toUpperCase(),
                                  style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.primary)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ).animate().fadeIn(duration: 400.ms),

            const SizedBox(height: 16),

            // Organization
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Organization',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 16),
                  _settingTile(Icons.business_rounded, 'Company',
                      auth.organization?['name'] ?? 'Not set'),
                  _settingTile(Icons.link_rounded, 'Platform',
                      auth.organization?['platform'] ?? 'Manual'),
                  _settingTile(Icons.key_rounded, 'Org ID', auth.orgId),
                ],
              ),
            ).animate().fadeIn(delay: 200.ms),

            const SizedBox(height: 16),

            // Currency Selector
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('Dashboard Currency',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary)),
                      if (_savingCurrency) ...[
                        const SizedBox(width: 12),
                        const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2)),
                      ],
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('Current: ${auth.currencyCode} (${auth.currencySymbol})',
                      style: TextStyle(
                          fontSize: 13, color: AppColors.textSecondary)),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: AppColors.primary.withOpacity(0.15)),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: _currencies.containsKey(auth.currencyCode)
                            ? auth.currencyCode
                            : 'INR',
                        dropdownColor: AppColors.card,
                        style: const TextStyle(
                            color: AppColors.textPrimary, fontSize: 14),
                        items: _currencies.entries
                            .map((e) => DropdownMenuItem(
                                  value: e.key,
                                  child: Text(e.value),
                                ))
                            .toList(),
                        onChanged: (v) async {
                          if (v == null || v == auth.currencyCode) return;
                          setState(() => _savingCurrency = true);
                          await auth.updateCurrency(v);
                          if (mounted) setState(() => _savingCurrency = false);
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text('Currency updated to $v'),
                                  backgroundColor: AppColors.success),
                            );
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 300.ms),

            const SizedBox(height: 16),

            // Integrations
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Integrations',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 16),
                  _integrationTile('WooCommerce', Icons.store_rounded, isWoo),
                  _integrationTile('Supabase', Icons.cloud_rounded, true),
                  if (isWoo)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text('Orders auto-sync every 5 minutes',
                          style: TextStyle(
                              fontSize: 12, color: AppColors.textMuted)),
                    ),
                ],
              ),
            ).animate().fadeIn(delay: 400.ms),

            const SizedBox(height: 16),

            // Notifications
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Notifications',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary)),
                  const SizedBox(height: 16),
                  _switchTile('Low Stock Alerts', true),
                  _switchTile('Churn Risk Alerts', true),
                  _switchTile('Forecast Updates', false),
                  _switchTile('Weekly Report', true),
                ],
              ),
            ).animate().fadeIn(delay: 600.ms),

            const SizedBox(height: 24),

            // Logout
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await auth.signOut();
                  if (context.mounted) context.go('/login');
                },
                icon: const Icon(Icons.logout_rounded, color: AppColors.error),
                label: const Text('Sign Out',
                    style: TextStyle(color: AppColors.error)),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: AppColors.error.withOpacity(0.3)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ).animate().fadeIn(delay: 800.ms),
          ],
        ),
      ),
    );
  }

  Widget _settingTile(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textMuted, size: 20),
          const SizedBox(width: 12),
          Text(label,
              style: TextStyle(fontSize: 14, color: AppColors.textSecondary)),
          const Spacer(),
          Flexible(
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary),
                  overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }

  Widget _integrationTile(String name, IconData icon, bool connected) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon,
              color: connected ? AppColors.success : AppColors.textMuted,
              size: 22),
          const SizedBox(width: 12),
          Expanded(
              child: Text(name,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: (connected ? AppColors.success : AppColors.textMuted)
                  .withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              connected ? 'Connected' : 'Not Connected',
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: connected ? AppColors.success : AppColors.textMuted),
            ),
          ),
        ],
      ),
    );
  }

  Widget _switchTile(String label, bool value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
              child: Text(label,
                  style:
                      TextStyle(fontSize: 14, color: AppColors.textSecondary))),
          Switch(
            value: value,
            onChanged: (v) {},
            activeColor: AppColors.primary,
            inactiveTrackColor: AppColors.surfaceLight,
          ),
        ],
      ),
    );
  }
}
