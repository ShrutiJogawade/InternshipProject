import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:percent_indicator/percent_indicator.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/inventory_provider.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/alert_tile.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _statusFilter = 'all';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.watch<AuthProvider>();
    if (auth.orgId.isNotEmpty && !_initialized) {
      _initialized = true;
      final inv = context.read<InventoryProvider>();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        inv.loadInventory(auth.orgId);
        inv.loadAlerts(auth.orgId);
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inv = context.watch<InventoryProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Inventory',
                    style: TextStyle(
                      fontSize:
                          MediaQuery.of(context).size.width < 400 ? 22 : 28,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  // Refresh button
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: AppColors.primary.withOpacity(0.15)),
                    ),
                    child: IconButton(
                      icon: Icon(Icons.refresh_rounded,
                          color: AppColors.primary, size: 20),
                      onPressed: () {
                        inv.loadInventory(auth.orgId);
                        inv.loadAlerts(auth.orgId);
                      },
                      tooltip: 'Refresh',
                      padding: const EdgeInsets.all(8),
                      constraints: const BoxConstraints(),
                    ),
                  ),
                ],
              ).animate().fadeIn(duration: 400.ms),
            ),
          ),

          // Summary Cards - 2x2 Grid
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final cardWidth = (constraints.maxWidth - 12) / 2;
                  return Column(
                    children: [
                      // Row 1
                      Row(
                        children: [
                          _summaryCard(
                            'Total SKUs',
                            '${inv.totalSkus}',
                            Icons.inventory_2_rounded,
                            AppColors.primary,
                            cardWidth,
                          ),
                          const SizedBox(width: 12),
                          _summaryCard(
                            'Healthy',
                            '${inv.healthyCount}',
                            Icons.check_circle_rounded,
                            AppColors.success,
                            cardWidth,
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // Row 2
                      Row(
                        children: [
                          _summaryCard(
                            'Low Stock',
                            '${inv.lowStockCount}',
                            Icons.warning_rounded,
                            AppColors.warning,
                            cardWidth,
                          ),
                          const SizedBox(width: 12),
                          _summaryCard(
                            'Critical',
                            '${inv.criticalCount}',
                            Icons.error_rounded,
                            AppColors.error,
                            cardWidth,
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ).animate().fadeIn(delay: 100.ms),
            ),
          ),

          // Tab Bar - Modern Design
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Container(
                height: 48,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.surfaceLight),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppColors.primary,
                        AppColors.primary.withOpacity(0.8)
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: AppColors.textMuted,
                  labelStyle: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                  unselectedLabelStyle: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Stock Levels'),
                    Tab(text: 'Alerts'),
                  ],
                ),
              ).animate().fadeIn(delay: 200.ms),
            ),
          ),

          // Filter Chips - Professional Design
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _filterChip('all', 'All', Icons.apps_rounded),
                    _filterChip('healthy', 'Healthy',
                        Icons.check_circle_outline_rounded),
                    _filterChip(
                        'low_stock', 'Low', Icons.trending_down_rounded),
                    _filterChip(
                        'critical', 'Critical', Icons.warning_amber_rounded),
                  ],
                ),
              ).animate().fadeIn(delay: 300.ms),
            ),
          ),

          // Content
          SliverFillRemaining(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildStockList(inv, auth),
                _buildAlertList(inv),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryCard(
      String title, String value, IconData icon, Color color, double width) {
    return Container(
      width: width,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.15)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textMuted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(String value, String label, IconData icon) {
    final isActive = _statusFilter == value;
    Color chipColor;
    switch (value) {
      case 'healthy':
        chipColor = AppColors.success;
        break;
      case 'low_stock':
        chipColor = AppColors.warning;
        break;
      case 'critical':
        chipColor = AppColors.error;
        break;
      default:
        chipColor = AppColors.primary;
    }

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: () => setState(() => _statusFilter = value),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: isActive ? chipColor : AppColors.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isActive ? chipColor : AppColors.surfaceLight,
              width: 1.5,
            ),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: chipColor.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 16,
                color: isActive ? Colors.white : AppColors.textMuted,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
                  color: isActive ? Colors.white : AppColors.textMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStockList(InventoryProvider inv, AuthProvider auth) {
    // Filter
    final items = _statusFilter == 'all'
        ? inv.items
        : inv.items.where((i) => i['stock_status'] == _statusFilter).toList();

    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inventory_2_outlined,
                size: 64, color: AppColors.textMuted.withOpacity(0.5)),
            const SizedBox(height: 16),
            Text(
              'No items found',
              style: TextStyle(
                fontSize: 16,
                color: AppColors.textMuted,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try changing the filter',
              style: TextStyle(
                fontSize: 13,
                color: AppColors.textMuted.withOpacity(0.7),
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return _buildStockTile(item)
            .animate()
            .fadeIn(delay: Duration(milliseconds: 50 * index));
      },
    );
  }

  Widget _buildStockTile(Map<String, dynamic> item) {
    final stock = (item['current_stock'] as num?)?.toInt() ?? 0;
    final maxStock = (item['max_stock'] as num?)?.toInt() ?? 500;
    final status = item['stock_status'] ?? 'healthy';
    final percent = maxStock > 0 ? (stock / maxStock).clamp(0.0, 1.0) : 0.0;

    Color statusColor;
    switch (status) {
      case 'out_of_stock':
        statusColor = AppColors.error;
        break;
      case 'critical':
        statusColor = const Color(0xFFFF6B6B);
        break;
      case 'low_stock':
        statusColor = AppColors.warning;
        break;
      case 'overstock':
        statusColor = AppColors.info;
        break;
      default:
        statusColor = AppColors.success;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              status == 'out_of_stock'
                  ? Icons.remove_shopping_cart_rounded
                  : status == 'overstock'
                      ? Icons.trending_up_rounded
                      : Icons.inventory_2_rounded,
              color: statusColor,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item['product_name'] ?? '',
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text('${item['sku_id']} • ${item['category_name'] ?? ''}',
                    style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                const SizedBox(height: 8),
                LinearPercentIndicator(
                  lineHeight: 6,
                  percent: percent,
                  backgroundColor: AppColors.surfaceLight,
                  progressColor: statusColor,
                  barRadius: const Radius.circular(3),
                  padding: EdgeInsets.zero,
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('$stock',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: statusColor)),
              Text('/ $maxStock',
                  style: TextStyle(fontSize: 11, color: AppColors.textMuted)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  status.replaceAll('_', ' ').toUpperCase(),
                  style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      color: statusColor,
                      letterSpacing: 0.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAlertList(InventoryProvider inv) {
    return inv.alerts.isEmpty
        ? const Center(
            child: Text('✅ No active alerts',
                style: TextStyle(color: AppColors.textMuted, fontSize: 16)))
        : ListView.builder(
            padding: const EdgeInsets.all(24),
            itemCount: inv.alerts.length,
            itemBuilder: (context, index) {
              return AlertTile(
                      alert: Map<String, dynamic>.from(inv.alerts[index]))
                  .animate()
                  .fadeIn(delay: Duration(milliseconds: 80 * index));
            },
          );
  }
}
