import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/dashboard_provider.dart';
import '../../core/services/api_service.dart';
import '../../widgets/glass_card.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DateTimeRange? _dateRange;
  String? _selectedCategory;
  String? _selectedProduct;
  String? _downloading;
  bool _initialized = false;
  bool _allTime = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.watch<AuthProvider>();
    if (auth.orgId.isNotEmpty && !_initialized) {
      _initialized = true;
      final dash = context.read<DashboardProvider>();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        dash.loadDashboard(auth.orgId);
      });
    }
  }

  String get _startDate => _allTime
      ? '2000-01-01'
      : _dateRange != null
          ? DateFormat('yyyy-MM-dd').format(_dateRange!.start)
          : DateFormat('yyyy-MM-dd')
              .format(DateTime.now().subtract(const Duration(days: 30)));

  String get _endDate => _dateRange != null && !_allTime
      ? DateFormat('yyyy-MM-dd').format(_dateRange!.end)
      : DateFormat('yyyy-MM-dd').format(DateTime.now());

  Future<void> _downloadBytes(List<int> bytes, String filename) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$filename');
    await file.writeAsBytes(bytes);
    // Open share sheet so user can save/share the PDF
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      text: filename,
    );
  }

  Future<void> _downloadReport(String type) async {
    final auth = context.read<AuthProvider>();
    setState(() => _downloading = type);
    try {
      List<int> bytes;
      String filename;
      switch (type) {
        case 'sales':
          bytes = await ApiService.downloadSalesReport(
            orgId: auth.orgId,
            startDate: _startDate,
            endDate: _endDate,
            category: _selectedCategory,
            product: _selectedProduct,
          );
          filename = 'sales_report_${_startDate}_$_endDate.pdf';
          break;
        case 'inventory':
          bytes = await ApiService.downloadInventoryReport(orgId: auth.orgId);
          filename = 'inventory_report.pdf';
          break;
        case 'customer':
          bytes = await ApiService.downloadCustomerReport(orgId: auth.orgId);
          filename = 'customer_report.pdf';
          break;
        case 'forecast':
          bytes = await ApiService.downloadForecastReport(orgId: auth.orgId);
          filename = 'forecast_report.pdf';
          break;
        default:
          return;
      }
      await _downloadBytes(bytes, filename);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('$filename downloaded'),
              backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Failed: $e'), backgroundColor: AppColors.error),
        );
      }
    }
    if (mounted) setState(() => _downloading = null);
  }

  @override
  Widget build(BuildContext context) {
    final dash = context.watch<DashboardProvider>();
    final auth = context.watch<AuthProvider>();

    final categories = dash.categoryBreakdown
        .map<String>((c) => c['category']?.toString() ?? '')
        .where((c) => c.isNotEmpty)
        .toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Reports',
                      style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary)),
                ],
              ).animate().fadeIn(duration: 400.ms),
            ),
          ),

          // Filters
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Report Filters',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        // Date range picker
                        InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () async {
                            final picked = await showDateRangePicker(
                              context: context,
                              firstDate: DateTime(2020),
                              lastDate: DateTime.now(),
                              initialDateRange: _dateRange ??
                                  DateTimeRange(
                                    start: DateTime.now()
                                        .subtract(const Duration(days: 30)),
                                    end: DateTime.now(),
                                  ),
                              builder: (ctx, child) => Theme(
                                data: Theme.of(ctx).copyWith(
                                  colorScheme: const ColorScheme.dark(
                                    primary: AppColors.primary,
                                    surface: AppColors.card,
                                  ),
                                ),
                                child: child!,
                              ),
                            );
                            if (picked != null)
                              setState(() => _dateRange = picked);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: AppColors.primary.withOpacity(0.15)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.date_range_rounded,
                                    size: 18, color: AppColors.primary),
                                const SizedBox(width: 8),
                                Text('$_startDate  \u2192  $_endDate',
                                    style: const TextStyle(
                                        fontSize: 13,
                                        color: AppColors.textPrimary)),
                              ],
                            ),
                          ),
                        ),
                        // All Time button
                        GestureDetector(
                          onTap: () => setState(() {
                            _allTime = !_allTime;
                            if (_allTime) _dateRange = null;
                          }),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: _allTime
                                  ? AppColors.primary
                                  : AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: _allTime
                                      ? AppColors.primary
                                      : AppColors.primary.withOpacity(0.15)),
                            ),
                            child: Text('All Time',
                                style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: _allTime
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                    color: _allTime
                                        ? Colors.white
                                        : AppColors.textMuted)),
                          ),
                        ),
                        // Category filter
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceLight,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: AppColors.primary.withOpacity(0.15)),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              hint: const Text('All Categories',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: AppColors.textMuted)),
                              value: _selectedCategory,
                              dropdownColor: AppColors.card,
                              style: const TextStyle(
                                  color: AppColors.textPrimary, fontSize: 13),
                              items: [
                                const DropdownMenuItem(
                                    value: null, child: Text('All Categories')),
                                ...categories.map((c) =>
                                    DropdownMenuItem(value: c, child: Text(c))),
                              ],
                              onChanged: (v) =>
                                  setState(() => _selectedCategory = v),
                            ),
                          ),
                        ),
                        // Clear filters
                        if (_dateRange != null ||
                            _selectedCategory != null ||
                            _selectedProduct != null ||
                            _allTime)
                          TextButton.icon(
                            onPressed: () => setState(() {
                              _dateRange = null;
                              _selectedCategory = null;
                              _selectedProduct = null;
                              _allTime = false;
                            }),
                            icon: const Icon(Icons.clear_rounded, size: 16),
                            label: const Text('Clear',
                                style: TextStyle(fontSize: 13)),
                          ),
                      ],
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 200.ms),
            ),
          ),

          // Report Cards
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final cardWidth = constraints.maxWidth > 600
                      ? (constraints.maxWidth - 16) / 2
                      : constraints.maxWidth;
                  return Wrap(
                    spacing: 16,
                    runSpacing: 16,
                    children: [
                      _reportCard(
                          'Sales Report',
                          'Revenue, orders, trends by category & product',
                          Icons.trending_up_rounded,
                          AppColors.primary,
                          'sales',
                          cardWidth),
                      _reportCard(
                          'Inventory Report',
                          'Stock levels, alerts, and valuations',
                          Icons.inventory_2_rounded,
                          AppColors.accent,
                          'inventory',
                          cardWidth),
                      _reportCard(
                          'Customer Report',
                          'Churn risk, RFM analysis, top customers',
                          Icons.people_alt_rounded,
                          AppColors.success,
                          'customer',
                          cardWidth),
                      _reportCard(
                          'Forecast Report',
                          'Demand predictions per product',
                          Icons.analytics_rounded,
                          AppColors.warning,
                          'forecast',
                          cardWidth),
                    ]
                        .asMap()
                        .entries
                        .map((e) => e.value
                            .animate()
                            .fadeIn(delay: Duration(milliseconds: 100 * e.key)))
                        .toList(),
                  );
                },
              ),
            ),
          ),

          // Regional Data
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 0),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Regional Performance',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 16),
                    ...dash.regionalData.map((r) {
                      final maxRev = dash.regionalData.isNotEmpty
                          ? (dash.regionalData[0]['revenue'] as num).toDouble()
                          : 1.0;
                      final rev = (r['revenue'] as num).toDouble();
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          children: [
                            SizedBox(
                                width: 80,
                                child: Text(r['region'] ?? '',
                                    style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.textPrimary))),
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(
                                  value: maxRev > 0 ? rev / maxRev : 0,
                                  backgroundColor: AppColors.surfaceLight,
                                  valueColor: AlwaysStoppedAnimation(
                                      AppColors.chartColors[
                                          dash.regionalData.indexOf(r) %
                                              AppColors.chartColors.length]),
                                  minHeight: 20,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            SizedBox(
                                width: 100,
                                child: Text(
                                    '${auth.currencySymbol}${(rev).toStringAsFixed(0)}',
                                    style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.textPrimary),
                                    textAlign: TextAlign.right)),
                          ],
                        ),
                      );
                    }),
                    if (dash.regionalData.isEmpty)
                      const Center(
                          child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Text('No regional data',
                                  style:
                                      TextStyle(color: AppColors.textMuted)))),
                  ],
                ),
              ).animate().fadeIn(delay: 500.ms),
            ),
          ),

          // Category Revenue Table
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Category Revenue',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 16),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          minWidth: MediaQuery.of(context).size.width - 48,
                        ),
                        child: DataTable(
                          headingRowColor:
                              WidgetStateProperty.all(AppColors.surfaceLight),
                          columnSpacing: 16,
                          columns: const [
                            DataColumn(
                                label: Text('Category',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600))),
                            DataColumn(
                                label: Text('Revenue',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                            DataColumn(
                                label: Text('Qty',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                            DataColumn(
                                label: Text('Share',
                                    style:
                                        TextStyle(fontWeight: FontWeight.w600)),
                                numeric: true),
                          ],
                          rows: dash.categoryBreakdown
                              .map((c) => DataRow(cells: [
                                    DataCell(
                                      SizedBox(
                                        width: 120,
                                        child: Text(c['category'] ?? '',
                                            style: const TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis),
                                      ),
                                    ),
                                    DataCell(Text(
                                        '${auth.currencySymbol}${((c['revenue'] as num).toInt())}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 13))),
                                    DataCell(Text('${c['quantity']}',
                                        style: const TextStyle(fontSize: 13))),
                                    DataCell(Text(
                                        '${(c['percentage'] as num).toStringAsFixed(1)}%',
                                        style: TextStyle(
                                            color: AppColors.accent,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 13))),
                                  ]))
                              .toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 600.ms),
            ),
          ),
        ],
      ),
    );
  }

  Widget _reportCard(String title, String subtitle, IconData icon, Color color,
      String type, double width) {
    final isDownloading = _downloading == type;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: isDownloading ? null : () => _downloadReport(type),
      child: Container(
        width: width,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.15)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12)),
                  child: Icon(icon, color: color, size: 22),
                ),
                const Spacer(),
                if (isDownloading)
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: color))
                else
                  Icon(Icons.download_rounded, color: color, size: 22),
              ],
            ),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary)),
            const SizedBox(height: 4),
            Text(subtitle,
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8)),
              child: Text(
                  isDownloading ? 'Generating...' : 'Click to download PDF',
                  style: TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w600, color: color)),
            ),
          ],
        ),
      ),
    );
  }
}
