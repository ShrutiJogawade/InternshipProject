import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:percent_indicator/percent_indicator.dart';

import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/churn_provider.dart';
import '../../widgets/glass_card.dart';

class ChurnScreen extends StatefulWidget {
  const ChurnScreen({super.key});

  @override
  State<ChurnScreen> createState() => _ChurnScreenState();
}

class _ChurnScreenState extends State<ChurnScreen> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final auth = context.watch<AuthProvider>();
    if (auth.orgId.isNotEmpty && !_initialized) {
      _initialized = true;
      final churn = context.read<ChurnProvider>();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        churn.predictChurn(auth.orgId);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final churn = context.watch<ChurnProvider>();
    final auth = context.watch<AuthProvider>();
    final isWide = MediaQuery.of(context).size.width > 900;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Churn Prediction',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary)),
                        const SizedBox(height: 2),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                    ),
                    onPressed: churn.isLoading
                        ? null
                        : () => churn.predictChurn(auth.orgId),
                    icon: churn.isLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.psychology_rounded, size: 18),
                    label: Text(churn.isLoading ? 'Analyzing...' : 'Analyze',
                        style: const TextStyle(fontSize: 13)),
                  ),
                ],
              ).animate().fadeIn(duration: 400.ms),
            ),
          ),

          // Summary Cards
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final cardWidth = (constraints.maxWidth - 12) / 2;
                  return Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: [
                      _summaryCard(
                          'Total Analyzed',
                          '${churn.totalAnalyzed}',
                          Icons.people_alt_rounded,
                          AppColors.primary,
                          cardWidth),
                      _summaryCard('High Risk', '${churn.highRiskCount}',
                          Icons.error_rounded, AppColors.error, cardWidth),
                      _summaryCard('Medium Risk', '${churn.mediumRiskCount}',
                          Icons.warning_rounded, AppColors.warning, cardWidth),
                      _summaryCard(
                          'Low Risk',
                          '${churn.lowRiskCount}',
                          Icons.check_circle_rounded,
                          AppColors.success,
                          cardWidth),
                    ]
                        .asMap()
                        .entries
                        .map((e) => e.value.animate().fadeIn(
                            delay: Duration(milliseconds: 100 * e.key),
                            duration: 400.ms))
                        .toList(),
                  );
                },
              ),
            ),
          ),

          // Pie Chart + Model Metrics
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: isWide
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 2, child: _buildRiskPie(churn)),
                        const SizedBox(width: 16),
                        Expanded(flex: 1, child: _buildModelMetrics(churn)),
                      ],
                    )
                  : Column(
                      children: [
                        _buildRiskPie(churn),
                        const SizedBox(height: 16),
                        _buildModelMetrics(churn),
                      ],
                    ),
            ).animate().fadeIn(delay: 400.ms),
          ),

          // Customer Risk List
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Customer Risk Analysis',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    const SizedBox(height: 16),
                    ...churn.predictions
                        .map((pred) => _buildCustomerTile(pred)),
                  ],
                ),
              ).animate().fadeIn(delay: 500.ms),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryCard(
      String title, String value, IconData icon, Color color, double width) {
    return Container(
      width: width,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value,
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: color)),
                Text(title,
                    style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRiskPie(ChurnProvider churn) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Risk Distribution',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 20),
          SizedBox(
            height: 220,
            child: PieChart(
              PieChartData(
                sections: [
                  PieChartSectionData(
                      value: churn.highRiskCount.toDouble(),
                      color: AppColors.error,
                      radius: 50,
                      title: '${churn.highRiskCount}',
                      titleStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.white)),
                  PieChartSectionData(
                      value: churn.mediumRiskCount.toDouble(),
                      color: AppColors.warning,
                      radius: 45,
                      title: '${churn.mediumRiskCount}',
                      titleStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.white)),
                  PieChartSectionData(
                      value: churn.lowRiskCount.toDouble(),
                      color: AppColors.success,
                      radius: 40,
                      title: '${churn.lowRiskCount}',
                      titleStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.white)),
                ],
                centerSpaceRadius: 45,
                sectionsSpace: 4,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _legendDot('High', AppColors.error),
              const SizedBox(width: 20),
              _legendDot('Medium', AppColors.warning),
              const SizedBox(width: 20),
              _legendDot('Low', AppColors.success),
            ],
          ),
        ],
      ),
    );
  }

  Widget _legendDot(String label, Color color) {
    return Row(
      children: [
        Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 6),
        Text(label,
            style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
      ],
    );
  }

  Widget _buildModelMetrics(ChurnProvider churn) {
    final metrics = churn.churnResult?['model_metrics'] ??
        {'accuracy': 0.87, 'f1_score': 0.84, 'roc_auc': 0.91};
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Model Performance',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 24),
          _metricGauge('Accuracy', (metrics['accuracy'] as num).toDouble(),
              AppColors.primary),
          const SizedBox(height: 20),
          _metricGauge('F1 Score', (metrics['f1_score'] as num).toDouble(),
              AppColors.accent),
          const SizedBox(height: 20),
          _metricGauge('ROC AUC', (metrics['roc_auc'] as num).toDouble(),
              AppColors.success),
        ],
      ),
    );
  }

  Widget _metricGauge(String label, double value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: TextStyle(fontSize: 14, color: AppColors.textSecondary)),
            Text('${(value * 100).toStringAsFixed(1)}%',
                style: TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w700, color: color)),
          ],
        ),
        const SizedBox(height: 8),
        LinearPercentIndicator(
          lineHeight: 8,
          percent: value.clamp(0, 1),
          backgroundColor: AppColors.surfaceLight,
          progressColor: color,
          barRadius: const Radius.circular(4),
          padding: EdgeInsets.zero,
          animation: true,
          animationDuration: 1000,
        ),
      ],
    );
  }

  Widget _buildCustomerTile(dynamic pred) {
    final prob = (pred['churn_probability'] as num?)?.toDouble() ?? 0;
    final risk = pred['risk_level'] ?? 'low';
    final drivers = (pred['top_drivers'] as List?) ?? [];

    Color riskColor = risk == 'high'
        ? AppColors.error
        : risk == 'medium'
            ? AppColors.warning
            : AppColors.success;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: riskColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: riskColor.withOpacity(0.2),
                child: Text(
                  (pred['customer_name'] ?? 'U')[0].toUpperCase(),
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: riskColor,
                      fontSize: 16),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(pred['customer_name'] ?? 'Unknown',
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textPrimary)),
                    Text(pred['email'] ?? '',
                        style: TextStyle(
                            fontSize: 12, color: AppColors.textMuted)),
                  ],
                ),
              ),
              CircularPercentIndicator(
                radius: 28,
                lineWidth: 5,
                percent: prob.clamp(0, 1),
                center: Text('${(prob * 100).toStringAsFixed(0)}%',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: riskColor)),
                progressColor: riskColor,
                backgroundColor: riskColor.withOpacity(0.15),
                circularStrokeCap: CircularStrokeCap.round,
              ),
            ],
          ),
          if (drivers.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('Churn Drivers:',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textMuted)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: drivers
                  .take(3)
                  .map<Widget>((d) => Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(8),
                          border:
                              Border.all(color: riskColor.withOpacity(0.15)),
                        ),
                        child: Text(
                          '${d['factor']}: ${d['value']}',
                          style: TextStyle(fontSize: 11, color: riskColor),
                        ),
                      ))
                  .toList(),
            ),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              _miniStat('Recency', '${pred['recency_days'] ?? 0}d'),
              const SizedBox(width: 16),
              _miniStat('Frequency', '${pred['frequency'] ?? 0}'),
              const SizedBox(width: 16),
              _miniStat('Monetary',
                  '${context.read<AuthProvider>().currencySymbol}${((pred['monetary_value'] as num?)?.toDouble() ?? 0).toStringAsFixed(0)}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontSize: 10, color: AppColors.textMuted)),
        Text(value,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary)),
      ],
    );
  }
}
