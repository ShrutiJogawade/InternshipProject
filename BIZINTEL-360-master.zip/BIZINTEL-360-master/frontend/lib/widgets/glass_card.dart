import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? color;
  final bool glowBorder;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.color,
    this.glowBorder = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: color ?? AppColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: glowBorder
              ? AppColors.primary.withOpacity(0.25)
              : AppColors.primary.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
          if (glowBorder)
            BoxShadow(
              color: AppColors.primary.withOpacity(0.06),
              blurRadius: 40,
              spreadRadius: 2,
            ),
        ],
      ),
      child: child,
    );
  }
}
