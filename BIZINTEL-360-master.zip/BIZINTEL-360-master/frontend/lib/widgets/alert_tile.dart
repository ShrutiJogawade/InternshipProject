import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class AlertTile extends StatelessWidget {
  final Map<String, dynamic> alert;
  const AlertTile({super.key, required this.alert});

  @override
  Widget build(BuildContext context) {
    final type = alert['alert_type'] ?? '';
    final severity = alert['severity'] ?? 'medium';
    final productName = alert['products']?['name'] ?? alert['product_name'] ?? alert['sku_id'] ?? '';
    final stock = alert['current_stock'] ?? 0;
    final message = alert['message'] ?? '';

    Color color;
    IconData icon;
    switch (severity) {
      case 'critical':
        color = AppColors.error;
        icon = Icons.error_rounded;
        break;
      case 'high':
        color = const Color(0xFFFF6B6B);
        icon = Icons.warning_rounded;
        break;
      case 'medium':
        color = AppColors.warning;
        icon = Icons.info_rounded;
        break;
      default:
        color = AppColors.info;
        icon = Icons.inventory_2_rounded;
    }

    if (type == 'overstock') {
      color = AppColors.info;
      icon = Icons.trending_up_rounded;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  productName,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  type == 'out_of_stock'
                      ? 'OUT OF STOCK'
                      : type == 'overstock'
                          ? 'Overstock: $stock units'
                          : 'Low: $stock units remaining',
                  style: TextStyle(fontSize: 12, color: color),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              severity.toUpperCase(),
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: color, letterSpacing: 0.5),
            ),
          ),
        ],
      ),
    );
  }
}
