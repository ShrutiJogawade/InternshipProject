import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8000/api';

  static final SupabaseClient supabase = Supabase.instance.client;

  static String? get _token => supabase.auth.currentSession?.accessToken;

  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  // ============================================
  // AUTH
  // ============================================

  static Future<AuthResponse> signUp({
    required String email,
    required String password,
    required String fullName,
    String? companyName,
  }) async {
    // Call our backend register endpoint which auto-confirms email
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
          'full_name': fullName,
          'company_name': companyName ?? '',
          'role': 'sales_manager',
        }),
      );

      if (response.statusCode == 200) {
        // Backend registered + auto-confirmed, now sign in via Supabase client
        final signInResponse = await supabase.auth.signInWithPassword(
          email: email,
          password: password,
        );
        return signInResponse;
      } else {
        // Fallback: try direct Supabase signup
        final directResponse = await supabase.auth.signUp(
          email: email,
          password: password,
          data: {
            'full_name': fullName,
            'company_name': companyName ?? '',
          },
        );
        return directResponse;
      }
    } catch (e) {
      // Fallback: try direct Supabase signup
      final directResponse = await supabase.auth.signUp(
        email: email,
        password: password,
        data: {
          'full_name': fullName,
          'company_name': companyName ?? '',
        },
      );
      return directResponse;
    }
  }

  static Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    final response = await supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );
    return response;
  }

  static Future<void> signOut() async {
    await supabase.auth.signOut();
  }

  static User? get currentUser => supabase.auth.currentUser;

  static Future<Map<String, dynamic>?> getMe() async {
    if (_token == null) return null;
    final response = await http.get(
      Uri.parse('$baseUrl/auth/me'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    return null;
  }

  // ============================================
  // DASHBOARD
  // ============================================

  static Future<Map<String, dynamic>> getDashboardOverview({
    required String orgId,
    String period = '30d',
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard/overview?org_id=$orgId&period=$period'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load dashboard: ${response.statusCode}');
  }

  static Future<Map<String, dynamic>> getKPIs({
    required String orgId,
    String period = '30d',
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard/kpis?org_id=$orgId&period=$period'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load KPIs');
  }

  // ============================================
  // FORECASTING
  // ============================================

  static Future<Map<String, dynamic>> runForecast({
    required String orgId,
    String forecastType = 'sku',
    int horizonDays = 30,
    List<String>? skuIds,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/forecast/run'),
      headers: _headers,
      body: json.encode({
        'org_id': orgId,
        'forecast_type': forecastType,
        'horizon_days': horizonDays,
        if (skuIds != null) 'sku_ids': skuIds,
      }),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Forecast failed: ${response.statusCode}');
  }

  static Future<Map<String, dynamic>> getForecastBySku({
    required String orgId,
    required String skuId,
    int horizon = 30,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/forecast/$skuId?org_id=$orgId&horizon=$horizon'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load forecast');
  }

  static Future<Map<String, dynamic>> getForecastByCategory({
    required String orgId,
    required String categoryName,
    int horizon = 30,
  }) async {
    final response = await http.get(
      Uri.parse(
          '$baseUrl/forecast/category/$categoryName?org_id=$orgId&horizon=$horizon'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load category forecast');
  }

  // ============================================
  // CHURN
  // ============================================

  static Future<Map<String, dynamic>> predictChurn({
    required String orgId,
    List<String>? customerIds,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/churn/predict'),
      headers: _headers,
      body: json.encode({
        'org_id': orgId,
        if (customerIds != null) 'customer_ids': customerIds,
      }),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Churn prediction failed');
  }

  static Future<Map<String, dynamic>> getTopRiskCustomers({
    required String orgId,
    int limit = 10,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/churn/top-risk?org_id=$orgId&limit=$limit'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load churn data');
  }

  static Future<Map<String, dynamic>> getChurnSummary({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/churn/summary?org_id=$orgId'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load churn summary');
  }

  // ============================================
  // INVENTORY
  // ============================================

  static Future<Map<String, dynamic>> getStockAlerts({
    required String orgId,
    String? alertType,
    bool resolved = false,
  }) async {
    var url = '$baseUrl/inventory/alerts?org_id=$orgId&resolved=$resolved';
    if (alertType != null) url += '&alert_type=$alertType';

    final response = await http.get(Uri.parse(url), headers: _headers);
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load alerts');
  }

  static Future<Map<String, dynamic>> getInventoryHealth({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/inventory/health?org_id=$orgId'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to load inventory');
  }

  static Future<Map<String, dynamic>> updateInventory({
    required String orgId,
    required String skuId,
    required int newStock,
    String changeType = 'adjustment',
    String? reason,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/inventory/update'),
      headers: _headers,
      body: json.encode({
        'org_id': orgId,
        'sku_id': skuId,
        'new_stock': newStock,
        'change_type': changeType,
        'change_reason': reason,
      }),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to update inventory');
  }

  // ============================================
  // CHAT
  // ============================================

  static Future<Map<String, dynamic>> sendChatMessage({
    required String orgId,
    required String message,
    String? sessionId,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/chat/message'),
      headers: _headers,
      body: json.encode({
        'org_id': orgId,
        'message': message,
        if (sessionId != null) 'session_id': sessionId,
      }),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Chat failed');
  }

  static Future<List<dynamic>> getChatSessions({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/chat/sessions?org_id=$orgId'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['sessions'] ?? [];
    }
    throw Exception('Failed to load sessions');
  }

  // ============================================
  // INTEGRATIONS
  // ============================================

  static Future<Map<String, dynamic>> connectShopify({
    required String orgId,
    required String storeUrl,
    required String apiKey,
    required String apiSecret,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/integrations/shopify/connect'),
      headers: _headers,
      body: json.encode({
        'org_id': orgId,
        'store_url': storeUrl,
        'api_key': apiKey,
        'api_secret': apiSecret,
      }),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Shopify connection failed');
  }

  static Future<Map<String, dynamic>> syncShopify({
    required String orgId,
    String syncType = 'full',
  }) async {
    final response = await http.post(
      Uri.parse(
          '$baseUrl/integrations/shopify/sync?org_id=$orgId&sync_type=$syncType'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Shopify sync failed');
  }

  // ============================================
  // ORG SETTINGS
  // ============================================

  static Future<Map<String, dynamic>> getOrgSettings({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/dashboard/org-settings?org_id=$orgId'),
      headers: _headers,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    // Return defaults on failure
    return {
      'currency_symbol': '₹',
      'currency_code': 'INR',
      'country': 'IN',
      'settings': {},
    };
  }

  // ============================================
  // DIRECT SUPABASE QUERIES (for real-time)
  // ============================================

  static Future<List<Map<String, dynamic>>> getProducts(String orgId) async {
    final response = await supabase
        .from('products')
        .select('*, categories(name)')
        .eq('org_id', orgId)
        .eq('is_active', true)
        .order('name');
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<List<Map<String, dynamic>>> getCustomers(String orgId) async {
    final response = await supabase
        .from('customers')
        .select()
        .eq('org_id', orgId)
        .order('total_spent', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<List<Map<String, dynamic>>> getOrders(String orgId,
      {int limit = 50}) async {
    final response = await supabase
        .from('orders')
        .select('*, customers(name, email)')
        .eq('org_id', orgId)
        .order('order_date', ascending: false)
        .limit(limit);
    return List<Map<String, dynamic>>.from(response);
  }

  static Future<Map<String, dynamic>?> getUserProfile() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    final response =
        await supabase.from('profiles').select().eq('id', user.id).single();
    return response;
  }

  // ============================================
  // CURRENCY / ORG SETTINGS UPDATE
  // ============================================

  static Future<Map<String, dynamic>> updateOrgSettings({
    required String orgId,
    required Map<String, dynamic> settings,
  }) async {
    final response = await http.put(
      Uri.parse('$baseUrl/dashboard/org-settings?org_id=$orgId'),
      headers: _headers,
      body: json.encode(settings),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    throw Exception('Failed to update settings');
  }

  // ============================================
  // PDF REPORTS
  // ============================================

  static Future<List<int>> downloadSalesReport({
    required String orgId,
    String? startDate,
    String? endDate,
    String? category,
    String? product,
  }) async {
    var url = '$baseUrl/reports/sales?org_id=$orgId&format=pdf';
    if (startDate != null) url += '&start_date=$startDate';
    if (endDate != null) url += '&end_date=$endDate';
    if (category != null) url += '&category=$category';
    if (product != null) url += '&product=$product';

    final response = await http.get(Uri.parse(url), headers: _headers);
    if (response.statusCode == 200) return response.bodyBytes;
    throw Exception('Failed to generate sales report');
  }

  static Future<List<int>> downloadInventoryReport({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/reports/inventory?org_id=$orgId&format=pdf'),
      headers: _headers,
    );
    if (response.statusCode == 200) return response.bodyBytes;
    throw Exception('Failed to generate inventory report');
  }

  static Future<List<int>> downloadCustomerReport({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/reports/customers?org_id=$orgId&format=pdf'),
      headers: _headers,
    );
    if (response.statusCode == 200) return response.bodyBytes;
    throw Exception('Failed to generate customer report');
  }

  static Future<List<int>> downloadForecastReport({
    required String orgId,
  }) async {
    final response = await http.get(
      Uri.parse('$baseUrl/reports/forecast?org_id=$orgId&format=pdf'),
      headers: _headers,
    );
    if (response.statusCode == 200) return response.bodyBytes;
    throw Exception('Failed to generate forecast report');
  }

  static Future<Map<String, dynamic>?> getUserOrganization() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    final response = await supabase
        .from('org_members')
        .select(
            'org_id, role, organizations(id, name, slug, platform, settings)')
        .eq('user_id', user.id)
        .limit(1);

    if (response.isNotEmpty) {
      return response[0]['organizations'];
    }
    return null;
  }
}
