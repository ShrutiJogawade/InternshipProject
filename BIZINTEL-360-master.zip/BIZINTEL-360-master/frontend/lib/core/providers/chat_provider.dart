import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ChatMessage {
  final String content;
  final bool isUser;
  final Map<String, dynamic>? chartData;
  final List<String>? suggestions;
  final DateTime timestamp;

  ChatMessage({
    required this.content,
    required this.isUser,
    this.chartData,
    this.suggestions,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class ChatProvider extends ChangeNotifier {
  final List<ChatMessage> _messages = [];
  String? _sessionId;
  bool _isLoading = false;
  String? _error;

  List<ChatMessage> get messages => _messages;
  String? get sessionId => _sessionId;
  bool get isLoading => _isLoading;
  String? get error => _error;

  ChatProvider() {
    // Add welcome message
    _messages.add(ChatMessage(
      content: '''👋 **Welcome to BizIntel 360 AI Assistant!**

I can help you with:
- 📊 Sales & revenue insights
- 🔮 Demand forecasting 
- 👥 Customer churn analysis
- 📦 Inventory & stock alerts
- 📈 Business recommendations

What would you like to know?''',
      isUser: false,
      suggestions: [
        'Show me stock alerts',
        'Who are the high-risk customers?',
        'What\'s our sales forecast?',
        'Show revenue summary',
      ],
    ));
  }

  Future<void> sendMessage(String message, String orgId) async {
    // Add user message
    _messages.add(ChatMessage(content: message, isUser: true));
    _isLoading = true;
    notifyListeners();

    try {
      final response = await ApiService.sendChatMessage(
        orgId: orgId,
        message: message,
        sessionId: _sessionId,
      );

      _sessionId = response['session_id'];

      _messages.add(ChatMessage(
        content: response['response'] ?? 'Sorry, I could not process that.',
        isUser: false,
        chartData: response['chart_data'],
        suggestions: response['suggestions'] != null
            ? List<String>.from(response['suggestions'])
            : null,
      ));

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _messages.add(ChatMessage(
        content:
            '**Connection error.** Could not reach the server. Please check that the backend is running and try again.\n\nError: ${e.toString()}',
        isUser: false,
        suggestions: [
          'Retry',
          'Show stock alerts',
          'Revenue summary',
        ],
      ));
      notifyListeners();
    }
  }

  void clearMessages() {
    _messages.clear();
    _sessionId = null;
    _messages.add(ChatMessage(
      content: '👋 Chat cleared. How can I help you?',
      isUser: false,
      suggestions: [
        'Show dashboard overview',
        'Stock alerts',
        'Revenue summary'
      ],
    ));
    notifyListeners();
  }
}
