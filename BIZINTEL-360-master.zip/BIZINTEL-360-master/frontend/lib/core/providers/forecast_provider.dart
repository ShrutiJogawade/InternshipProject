import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ForecastProvider extends ChangeNotifier {
  Map<String, dynamic>? _forecastResult;
  List<dynamic> _predictions = [];
  bool _isLoading = false;
  String? _error;
  String _forecastType = 'sku';
  int _horizonDays = 30;

  Map<String, dynamic>? get forecastResult => _forecastResult;
  List<dynamic> get predictions => _predictions;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String get forecastType => _forecastType;
  int get horizonDays => _horizonDays;

  void setForecastType(String type) {
    _forecastType = type;
    notifyListeners();
  }

  void setHorizonDays(int days) {
    _horizonDays = days;
    notifyListeners();
  }

  Future<void> runForecast(String orgId, {List<String>? skuIds}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _forecastResult = await ApiService.runForecast(
        orgId: orgId,
        forecastType: _forecastType,
        horizonDays: _horizonDays,
        skuIds: skuIds,
      );
      _predictions = _forecastResult?['predictions'] ?? [];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadSkuForecast(String orgId, String skuId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final data = await ApiService.getForecastBySku(
        orgId: orgId,
        skuId: skuId,
        horizon: _horizonDays,
      );
      _predictions = data['predictions'] ?? [];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
}
