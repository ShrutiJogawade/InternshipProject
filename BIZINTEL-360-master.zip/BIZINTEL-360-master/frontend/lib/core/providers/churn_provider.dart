import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ChurnProvider extends ChangeNotifier {
  Map<String, dynamic>? _churnResult;
  List<dynamic> _predictions = [];
  Map<String, dynamic>? _summary;
  bool _isLoading = false;
  String? _error;

  Map<String, dynamic>? get churnResult => _churnResult;
  List<dynamic> get predictions => _predictions;
  Map<String, dynamic>? get summary => _summary;
  bool get isLoading => _isLoading;
  String? get error => _error;

  int get highRiskCount =>
      _churnResult?['high_risk'] ?? _summary?['high_risk'] ?? 0;
  int get mediumRiskCount =>
      _churnResult?['medium_risk'] ?? _summary?['medium_risk'] ?? 0;
  int get lowRiskCount =>
      _churnResult?['low_risk'] ?? _summary?['low_risk'] ?? 0;
  int get totalAnalyzed =>
      _churnResult?['total_customers'] ?? _summary?['total_analyzed'] ?? 0;

  Future<void> predictChurn(String orgId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _churnResult = await ApiService.predictChurn(orgId: orgId);
      _predictions = _churnResult?['predictions'] ?? [];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadTopRisks(String orgId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final data = await ApiService.getTopRiskCustomers(orgId: orgId);
      _predictions = data['top_risk_customers'] ?? [];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadSummary(String orgId) async {
    try {
      _summary = await ApiService.getChurnSummary(orgId: orgId);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
}
