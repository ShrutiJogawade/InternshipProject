import 'package:flutter/material.dart';
import '../services/api_service.dart';

class InventoryProvider extends ChangeNotifier {
  Map<String, dynamic>? _inventoryHealth;
  List<dynamic> _items = [];
  Map<String, dynamic>? _summary;
  List<dynamic> _alerts = [];
  bool _isLoading = false;
  String? _error;

  Map<String, dynamic>? get inventoryHealth => _inventoryHealth;
  List<dynamic> get items => _items;
  Map<String, dynamic>? get summary => _summary;
  List<dynamic> get alerts => _alerts;
  bool get isLoading => _isLoading;
  String? get error => _error;

  int get totalSkus => _summary?['total_skus'] ?? 0;
  int get healthyCount => _summary?['healthy'] ?? 0;
  int get lowStockCount => _summary?['low_stock'] ?? 0;
  int get criticalCount => _summary?['critical'] ?? 0;
  int get outOfStockCount => _summary?['out_of_stock'] ?? 0;
  int get overstockCount => _summary?['overstock'] ?? 0;
  double get totalValue => (_summary?['total_value'] ?? 0).toDouble();

  Future<void> loadInventory(String orgId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _inventoryHealth = await ApiService.getInventoryHealth(orgId: orgId);
      _items = _inventoryHealth?['items'] ?? [];
      _summary = _inventoryHealth?['summary'];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadAlerts(String orgId) async {
    try {
      final data = await ApiService.getStockAlerts(orgId: orgId);
      _alerts = data['alerts'] ?? [];
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateStock(String orgId, String skuId, int newStock) async {
    try {
      await ApiService.updateInventory(
        orgId: orgId,
        skuId: skuId,
        newStock: newStock,
      );
      await loadInventory(orgId);
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
}
