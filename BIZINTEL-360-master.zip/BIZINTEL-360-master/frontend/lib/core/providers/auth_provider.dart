import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  User? _user;
  Map<String, dynamic>? _profile;
  Map<String, dynamic>? _organization;
  Map<String, dynamic>? _orgSettings;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  Map<String, dynamic>? get profile => _profile;
  Map<String, dynamic>? get organization => _organization;
  Map<String, dynamic>? get orgSettings => _orgSettings;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;
  String? get error => _error;
  String get orgId => _organization?['id'] ?? '';
  String get userName => _profile?['full_name'] ?? _user?.email ?? 'User';
  String get userRole => _profile?['role'] ?? 'sales_manager';
  String get currencySymbol => _orgSettings?['currency_symbol'] ?? '₹';
  String get currencyCode => _orgSettings?['currency_code'] ?? 'INR';
  String get orgName => _organization?['name'] ?? '';

  AuthProvider() {
    _init();
  }

  void _init() {
    _user = ApiService.currentUser;
    if (_user != null) {
      _loadProfile();
    }

    Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      _user = data.session?.user;
      if (_user != null) {
        _loadProfile();
      } else {
        _profile = null;
        _organization = null;
      }
      notifyListeners();
    });
  }

  Future<void> _loadProfile() async {
    try {
      // Use backend /api/auth/me which uses service key (bypasses RLS)
      final me = await ApiService.getMe();
      if (me != null) {
        _profile = me['profile'] as Map<String, dynamic>?;
        final orgs = me['organizations'] as List<dynamic>?;
        if (orgs != null && orgs.isNotEmpty) {
          _organization = orgs[0] as Map<String, dynamic>;
        }
      } else {
        // Fallback to direct Supabase queries
        _profile = await ApiService.getUserProfile();
        _organization = await ApiService.getUserOrganization();
      }
      // Load org settings (currency, etc.) from backend
      if (_organization != null && _organization!['id'] != null) {
        try {
          _orgSettings = await ApiService.getOrgSettings(
            orgId: _organization!['id'],
          );
        } catch (_) {
          _orgSettings = {'currency_symbol': '₹', 'currency_code': 'INR'};
        }
      }
      notifyListeners();
    } catch (e) {
      print('Error loading profile: $e');
    }
  }

  Future<bool> signUp({
    required String email,
    required String password,
    required String fullName,
    String? companyName,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await ApiService.signUp(
        email: email,
        password: password,
        fullName: fullName,
        companyName: companyName,
      );

      _user = response.user;

      // Auto sign-in after registration (email is auto-confirmed by backend)
      if (_user != null) {
        try {
          final signInResponse = await ApiService.signIn(
            email: email,
            password: password,
          );
          _user = signInResponse.user;
        } catch (_) {
          // If auto-sign-in fails, user can manually sign in
        }
      }

      if (_user != null) {
        await _loadProfile();
      }

      _isLoading = false;
      notifyListeners();
      return _user != null;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signIn({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await ApiService.signIn(
        email: email,
        password: password,
      );

      _user = response.user;
      if (_user != null) {
        await _loadProfile();
      }

      _isLoading = false;
      notifyListeners();
      return _user != null;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateCurrency(String currencyCode) async {
    try {
      await ApiService.updateOrgSettings(
        orgId: orgId,
        settings: {'currency': currencyCode},
      );
      // Reload org settings to pick up new symbol
      _orgSettings = await ApiService.getOrgSettings(orgId: orgId);
      notifyListeners();
      return true;
    } catch (e) {
      print('Error updating currency: $e');
      return false;
    }
  }

  Future<void> signOut() async {
    await ApiService.signOut();
    _user = null;
    _profile = null;
    _organization = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
