import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DashboardProvider extends ChangeNotifier {
  Map<String, dynamic>? _dashboardData;
  Map<String, dynamic>? _kpis;
  bool _isLoading = false;
  String? _error;
  String _selectedPeriod = '30d';

  Map<String, dynamic>? get dashboardData => _dashboardData;
  Map<String, dynamic>? get kpis => _kpis;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String get selectedPeriod => _selectedPeriod;

  // KPI getters with defaults
  double get totalRevenue => _kpiDouble('total_revenue');
  int get totalOrders => _kpiInt('total_orders');
  double get avgOrderValue => _kpiDouble('avg_order_value');
  int get totalCustomers => _kpiInt('total_customers');
  int get activeCustomers => _kpiInt('active_customers');
  double get churnRate => _kpiDouble('churn_rate');
  int get lowStockCount => _kpiInt('low_stock_count');
  int get overstockCount => _kpiInt('overstock_count');
  int get highRiskCustomers => _kpiInt('high_risk_customers');

  List<dynamic> get salesChartDates =>
      _dashboardData?['sales_chart']?['dates'] ?? [];
  List<dynamic> get salesChartRevenue =>
      _dashboardData?['sales_chart']?['revenue'] ?? [];
  List<dynamic> get salesChartOrders =>
      _dashboardData?['sales_chart']?['orders'] ?? [];
  List<dynamic> get categoryBreakdown =>
      _dashboardData?['category_breakdown'] ?? [];
  List<dynamic> get recentAlerts => _dashboardData?['recent_alerts'] ?? [];
  List<dynamic> get topChurnRisks => _dashboardData?['top_churn_risks'] ?? [];
  List<dynamic> get topProducts => _dashboardData?['top_products'] ?? [];
  List<dynamic> get regionalData => _dashboardData?['regional_data'] ?? [];

  double _kpiDouble(String key) {
    final val = _kpis?[key] ?? _dashboardData?['kpis']?[key];
    if (val == null) return 0.0;
    return (val is num)
        ? val.toDouble()
        : double.tryParse(val.toString()) ?? 0.0;
  }

  int _kpiInt(String key) {
    final val = _kpis?[key] ?? _dashboardData?['kpis']?[key];
    if (val == null) return 0;
    return (val is num) ? val.toInt() : int.tryParse(val.toString()) ?? 0;
  }

  void setPeriod(String period) {
    _selectedPeriod = period;
    notifyListeners();
  }

  Future<void> loadDashboard(String orgId, {String? period}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _dashboardData = await ApiService.getDashboardOverview(
        orgId: orgId,
        period: period ?? _selectedPeriod,
      );
      _kpis = _dashboardData?['kpis'];
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }
}
